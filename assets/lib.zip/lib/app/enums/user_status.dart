enum UserStatus {
  VERIFIED,
  UNVERIFIED,
  NONE
}