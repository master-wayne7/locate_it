enum LocationType {
  PICKUP,
  DESTINATION,
  HOME,
  WORK,
  NONE,
}