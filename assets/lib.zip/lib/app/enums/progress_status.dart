enum ProgressStatus {
  LOADING,
  ERROR,
  SUCCESS
}