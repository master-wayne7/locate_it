enum ExtraTripEvents {
  PENDING,
  ACCEPTED,
  RUNNING,
  COMPLETED,
  RATINGS,
}