enum NotiType {
  CAMPAIGN,
  PROMO
}