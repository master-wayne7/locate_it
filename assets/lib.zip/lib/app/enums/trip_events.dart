enum TripEvents {
  PENDING,
  ACCEPTED,
  RUNNING
}