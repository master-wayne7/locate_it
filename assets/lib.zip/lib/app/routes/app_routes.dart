part of 'app_pages.dart';

abstract class Routes {
  Routes._();

  static const DASHBOARD = _Paths.DASHBOARD;
  static const SPLASH_SCREEN = _Paths.SPLASH_SCREEN;
  static const ONBOARDING_SCREEN = _Paths.ONBOARDING_SCREEN;
  static const AUTH = _Paths.AUTH;
  static const PHONE_LOGIN = _Paths.PHONE_LOGIN;
  static const OTP = _Paths.OTP;
  static const SIGNUP = _Paths.SIGNUP;
  static const PROFILE_EDIT = _Paths.PROFILE_EDIT;
  static const BOOKING = _Paths.BOOKING;
  static const TRIP = _Paths.TRIP;
  static const RATINGS = _Paths.RATINGS;
  static const PAYMENT_OPTIONS = _Paths.PAYMENT_OPTIONS;
  static const DOCUMENT = _Paths.DOCUMENT;
  static const NOTIFICATIONS = _Paths.NOTIFICATIONS;
  static const EXTRA_TRIP = _Paths.EXTRA_TRIP;
  static const HISTORY_DETAIL = _Paths.HISTORY_DETAIL;
  static const TEST = _Paths.TEST;
}

abstract class _Paths {
  static const DASHBOARD = '/dashboard';
  static const SPLASH_SCREEN = '/splashScreen';
  static const RATINGS = '/ratings';
  static const ONBOARDING_SCREEN = '/onboarding';
  static const AUTH = '/auth';
  static const PHONE_LOGIN = '/phone_login';
  static const OTP = '/otp';
  static const SIGNUP = '/signup';
  static const PROFILE_EDIT = '/profileEdit';
  static const BOOKING = '/booking';
  static const TRIP = '/trip';
  static const PAYMENT_OPTIONS = '/payment-options';
  static const DOCUMENT = '/document';
  static const NOTIFICATIONS = '/notifications';
  static const EXTRA_TRIP = '/extra-trip';
  static const HISTORY_DETAIL = '/history-detail';
  static const TEST = '/test';
}
