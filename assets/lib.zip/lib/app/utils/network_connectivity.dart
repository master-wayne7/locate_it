import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:overlay_support/overlay_support.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/utils/restart_app.dart';
import 'package:puryaideu/app/widgets/custom_button.dart';
import 'package:puryaideu/main.dart';
// import 'package:restart_app/restart_app.dart';

class NetworkConnectivity {
  static void showTopSnackBar(
      BuildContext context,
      String message,
      Color color,
      ) =>
      showSimpleNotification(
        Text('Internet Connectivity Update'),
        subtitle: Text(message),
        background: color,
      );
}

class InternetDialog extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () => Future.value(false),
      child: AlertDialog(

        shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.all(Radius.circular(10.0))),
        contentPadding: EdgeInsets.only(top: 10.0),
        content: Container(
          width: Get.width,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              SizedBox(height: 16),
              SvgPicture.asset(
                'svg_assets/internet.svg',
                height: Get.height * 0.25,
              ),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  'Internet connection unavailable',
                  style: Get.textTheme.headline6.copyWith(fontSize: getResponsiveFont(16)),
                  textAlign: TextAlign.left,
                ),
              ),
              SizedBox(height: 16),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 16),
                child: Text(
                  "Please check your internet connection and try again.",
                  style: Get.textTheme.bodyText2,
                  textAlign: TextAlign.left,
                ),
              ),
              SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                      child: Container(
                        decoration: BoxDecoration(
                          borderRadius:
                          BorderRadius.only(bottomLeft: Radius.circular(10)),
                        ),
                        child: CustomButton(
                          onPressed: () {
                            // Restart.restartApp();
                          },
                          text: 'Refresh',
                          backgroundColor: Get.theme.primaryColor
                        ),
                      )),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}