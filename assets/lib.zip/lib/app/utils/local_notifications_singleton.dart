import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class LocalNotificationPluginSingleton {
  LocalNotificationPluginSingleton._privateConstructor();

  static final LocalNotificationPluginSingleton _instance =
  LocalNotificationPluginSingleton._privateConstructor();

  static LocalNotificationPluginSingleton get instance => _instance;

  FlutterLocalNotificationsPlugin _localNotificationsPlugin;

  FlutterLocalNotificationsPlugin get localNotificationsPlugin {
    if (_localNotificationsPlugin == null) {
      _localNotificationsPlugin = FlutterLocalNotificationsPlugin();
    }
    return _localNotificationsPlugin;
  }

  AndroidNotificationChannel _channel;

  AndroidNotificationChannel get channel {
    if (_channel == null) {
      _channel = AndroidNotificationChannel(
        'high_importance_channel', // id
        'High Importance Notification', // title
        'This channel is used for important notifications.', // description
        importance: Importance.high,
        playSound: true,
      );
    }
    return _channel;
  }
}
