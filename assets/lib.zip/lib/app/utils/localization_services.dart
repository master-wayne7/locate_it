import 'dart:ui';

import 'package:get/get.dart';
import 'package:get/get_navigation/src/root/internacionalization.dart';
import 'package:puryaideu/app/data/repositories/user_repository.dart';
import 'package:puryaideu/generated/locales.g.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LocalizationService extends Translations {
  // Default locale
  static final locale = Locale('en' ,'US');
  static final fallbackLocale = Locale('en' ,'US');


  static final langs = [
    'English',
    'Nepali',
  ];

  static final locales = [
    Locale('en', 'US'),
    Locale('ne', 'NP'),
  ];

  @override
  Map<String, Map<String, String>> get keys => AppTranslation.translations;

  // Gets locale from language, and updates the locale
  void changeLocale(String lang) {
    final locale = _getLocaleFromLanguage(lang);
    Get.updateLocale(locale);

  }

  // Finds language in `langs` list and returns it as Locale
  Locale _getLocaleFromLanguage(String lang) {
    for (int i = 0; i < langs.length; i++) {
      if (lang == langs[i]) return locales[i];
    }
    return Get.locale;
  }

  Future<Locale> getLocale() async{
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    UserRepository userRepository = UserRepository(prefs: sharedPreferences);
    int index = await userRepository.getLanguageIndex();
    if(index == null) {
      index = 0;
    }
    return locales[index];
  }
}