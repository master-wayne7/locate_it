import 'package:flutter/material.dart';
import 'package:get/get.dart';

final kThemeData = ThemeData().copyWith(
  // primaryColor: Color(0xffEB2027),
  // accentColor: Color(0xff2E368F),
  primaryColor: Color.fromRGBO(225, 89, 89, 1),
  accentColor: Color(0xff3f48cc),
  appBarTheme: AppBarTheme(
    iconTheme: IconThemeData(
      color: Color(0xffEB2027),
    ),
  ),
  textTheme: TextTheme().copyWith(
    bodyText2: TextStyle(
      fontFamily: 'Poppins',
      fontSize: getResponsiveFont(14),
      color: Colors.black,
    ),
    headline5: TextStyle(
      fontFamily: 'Poppins',
      fontSize: getResponsiveFont(16),
      fontWeight: FontWeight.w500,
      color: Colors.black,
    ),
    headline6:  TextStyle(
      fontFamily: 'Poppins',
      fontSize: getResponsiveFont(20),
      fontWeight: FontWeight.w700,
      color: Colors.black,
    ),
  ),
);

double getResponsiveFont(double fontSize) {
  double widthInDp = Get.width;
  double physicalPixelWidth = Get.width * Get.pixelRatio;
  double dpi = ((physicalPixelWidth / widthInDp) * 160) - 5;

  if (dpi <= 120) {
    // print("It is ldpi");
    return 0.25 * fontSize;
  } else if (dpi <= 160) {
    // print("It is mdpi");
    return (1 / 3) * fontSize;
  } else if (dpi <= 240) {
    // print("It is hdpi");
    return 0.5 * fontSize;
  } else if (dpi <= 320) {
    // print("It is xhdpi");
    return 0.75 * fontSize;
  } else if (dpi <= 480) {
    // print("It is xxhdpi");
    return 1.0 * fontSize;
  } else if (dpi <= 600) {
    // print("It is xxxdpi");
    return (4 / 3) * fontSize;
  } else {
    // print("It is nodpi");
    return 1.5 * fontSize;
  }
}
