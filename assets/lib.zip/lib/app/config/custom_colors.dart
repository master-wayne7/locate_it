import 'package:flutter/material.dart';

const kGreyColor = Color(0xffa8a8a8);
const kLightBlack = Color(0xff474747);
const kOtpInputFieldFillColor = Color(0xffe9e9e9);
const redColor = Color(0xffF53649);
const greenColor = Color(0xff20BD87);