const String API_KEY = 'AIzaSyDBm6mwigSesFoEw7fa1eoe9RohWkKYb50';
const String CLIENT_ID = "JB0BBQ4aD0UqIThFJwAKBgAXEUkEGQUBBAwdOgABHD4DChwUAB0R";
const String SECRET_ID = "BhwIWQQADhIYSxILExMcAgFXFhcOBwAKBgAXEQ==";
const String BASE_URL = 'https://puryaideuv2.letitgrownepal.com';
//const String BASE_URL = 'http://1cff-27-34-12-128.ngrok.io';
const String ALTERNATIVE_URL = 'http://nepaligrains.com';
const PROFILE_IMAGE_BASE_URL = 'https://puryaideu.letitgrownepal.com/storage/images/profile/';
