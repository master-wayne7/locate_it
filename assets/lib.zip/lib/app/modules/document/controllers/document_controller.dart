import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:dio/dio.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/data/models/emergency_contacts.dart';
import 'package:puryaideu/app/data/repositories/profile_repository.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';

class DocumentController extends GetxController {
  //TODO: Implement DocumentController

  final count = 0.obs;
  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => count.value++;

  final driverFormList = [].obs;

  final totalContacts = 0.obs;

  String errorMessage = '';

  String authError;

  List<EmergencyContacts> extraDriverList = [];

  Future<bool> addEmergencyContacts() async {

    for (EmergencyContactsForm driverForm in driverFormList) {
      String phone = driverForm.phoneController.text;
      String name = driverForm.firstNameController.text;

      EmergencyContacts extraDriver = EmergencyContacts(
          name: name,
          contact: phone);

      //extraDriverList.add(extraDriver.phone);
      extraDriverList.add(extraDriver);
    }

    final status =
    await ProfileRepository.sendEmergencyContacts(extraDriverList)
        .catchError((error) {
      if(error.toString().toLowerCase().contains('full header')){
        authError = 'Internet failed to establish proper connection. Try again.';
      }else{
        authError = 'Internet failed to establish proper connection. Try again.';
      }
    });
    if(status != null){
      return true;
    }
    return false;


  }


bool gotoNextPage() {
    bool gotError = false;
    if (driverFormList.length > 0) {
      for (EmergencyContactsForm driverForm in driverFormList) {
        String name = driverForm.firstNameController.text;
        // String lastName = driverForm.lastNameController.text;
        String phone = driverForm.phoneController.text;
        if (name.length < 1) {
          errorMessage = 'Please enter first name.';
          gotError = true;
        }
        // else if (lastName.length < 1) {
        //   errorMessage = 'Please enter last name.';
        //   gotError = true;
        //   break;
        // } else
        else if (phone.length != 10 ) {
          errorMessage = 'Please enter a valid phone number.';
          gotError = true;
          break;
        } else {
          gotError = false;
          continue;
        }
      }
      if (gotError) {
        CustomSnackbar.showCustomSnackBar(message: errorMessage);
        return false;
      }
      return true;
      // updateMapEvent(MapEvents.PAYMENT);
    }
    return true;
  }

  addForm() {
    if ((driverFormList.length + totalContacts.value) >= 3) {
      CustomSnackbar.showCustomSnackBar(
          message: 'You can add 3 emergency contacts at most.');
      return;
    }
    TextEditingController firstNameController = TextEditingController();
    TextEditingController lastNameController = TextEditingController();
    TextEditingController phoneController = TextEditingController();
    FocusNode firstNameNode = FocusNode();
    FocusNode lastNameNode = FocusNode();
    FocusNode phoneNode = FocusNode();
    EmergencyContactsForm driverForm = EmergencyContactsForm(
        firstNameNode: firstNameNode,
        lastNameNode: lastNameNode,
        phoneNode: phoneNode,
        firstNameController: firstNameController,
        lastNameController: lastNameController,
        phoneController: phoneController);
    driverFormList.add(driverForm);
  }

  removeForm(int index) {
    driverFormList.removeAt(index);
  }
}
