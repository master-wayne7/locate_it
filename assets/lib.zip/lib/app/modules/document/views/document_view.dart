import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/data/models/emergency_contacts.dart';
import 'package:puryaideu/app/modules/profile/controllers/profile_controller.dart';
import 'package:puryaideu/app/widgets/custom_button.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:puryaideu/app/widgets/custom_text_input_field.dart';
import 'package:puryaideu/generated/locales.g.dart';

import '../controllers/document_controller.dart';

class DocumentView extends StatefulWidget {
  const DocumentView({Key key}) : super(key: key);

  @override
  _DocumentViewState createState() => _DocumentViewState();
}

class _DocumentViewState extends State<DocumentView> {
  DocumentController controller = Get.find();
  ProfileController profileController = Get.find();
  List<DocumentView> drivers = [];
  FocusNode phoneNode = FocusNode();
  TextEditingController phoneController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // appBar: AppBar(
      //   backgroundColor: Get.theme.primaryColor,
      //   title: Text(
      //     'Emergency Contacts'.tr,
      //     style: Get.textTheme.headline5.copyWith(
      //       color: Colors.white,
      //       fontSize: getResponsiveFont(20),
      //       fontWeight: FontWeight.bold,
      //       fontFamily: 'Roboto',
      //     ),
      //   ),
      //   actions: <Widget>[
      //     IconButton(
      //       onPressed: () {
      //         controller.addForm();
      //       },
      //       icon: Icon(Icons.add, color: Colors.white),
      //     ),
      //   ],
      //   centerTitle: true,
      // ),
      body: SafeArea(
        child: Stack(
            children: [
        Column(
        children: [
        Container(
        margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            GestureDetector(
                onTap: () {
                  Get.back();
                },
                child: Icon(Icons.arrow_back_ios)),
            SizedBox(width: 16),
            Text(
              "Emergency Contacts",
              style: Get.textTheme.headline6,
            ),
            Expanded(child: SizedBox()),
            IconButton(
              onPressed: () {
                controller.addForm();
              },
              icon: Icon(Icons.add, color: Colors.black),
            ),
          ],
        ),
      ),
      Obx(() =>
      profileController.emergencyContacts.length == 0 ? Container(

      ) : Expanded(
        flex: profileController.emergencyContacts.length == 2 ? 3: profileController.emergencyContacts.length > 2 ? 1: 2,
        child: Column(
          children: [
            // Container(
            //   color: Get.theme.primaryColor,
            //   child: Row(
            //     mainAxisAlignment: MainAxisAlignment.spaceBetween,
            //     children: [
            //       Container(),
            //       Text(
            //         'Existing Details'.tr,
            //         style: Get.textTheme.headline5.copyWith(
            //           color: Colors.white,
            //         ),
            //       ),
            //       IconButton(
            //           onPressed: (){},
            //           icon: Icon(
            //             Icons.delete,
            //             color: Colors.transparent,
            //           )),
            //     ],
            //   ),
            // ),
            Expanded(
              child: ListView.builder(
                itemCount: profileController.emergencyContacts.length,
                itemBuilder: (context, index) {
                  controller.extraDriverList.add(profileController.emergencyContacts[index]);
                  controller.totalContacts.value++;
                  return ExistingContactDetail(
                    name: profileController.emergencyContacts[index].name.toString(),
                    phoneNumber: profileController
                        .emergencyContacts[index].contact.toString(),
                  );
                },
              ),
            ),
          ],
        ),
        ),
      )
        ,
        SizedBox(height:8),
        Expanded(
          flex: profileController.emergencyContacts.length == 2 ? 2: profileController.emergencyContacts.length > 2 ? 0 : 3,
          child: Container(
            child: Obx(() =>
            controller.driverFormList.length == 0
                ? profileController.emergencyContacts.length > 2 ? Container(): Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Center(
                child: Text(
                  'You can add emergency contacts'.tr,
                  textAlign: TextAlign.center,
                ),
              ),
            )
                : GetBuilder<DocumentController>(
              builder: (myController) =>
                  ListView.builder(
                    itemCount: controller.driverFormList.length,
                    itemBuilder: (context, index) {
                      return EmergencyContactsTile(
                        firstNameNode: controller
                            .driverFormList[index].firstNameNode,
                        lastNameNode: controller
                            .driverFormList[index].lastNameNode,
                        phoneNode: controller
                            .driverFormList[index].phoneNode,
                        lastNameController: controller
                            .driverFormList[index].lastNameController,
                        phoneController: controller
                            .driverFormList[index].phoneController,
                        firstNameController: controller
                            .driverFormList[index]
                            .firstNameController,
                        onRemove: () => controller.removeForm(index),
                      );
                    },
                  ),
            )),
          ),
        ),
        SizedBox(height: Get.height * 0.1),
        ],
      ),
        Positioned(
            bottom: 16,
            right: 16,
            left: 16,
            child: Container(
                width: Get.width * 1,
                child: Obx(() =>
                    CustomButton(
                        backgroundColor: controller.driverFormList.length > 0
                            ? Get.theme.primaryColor
                            : Colors.grey,
                        text: 'Submit',
                        onPressed: () async {
                          final response = await controller.gotoNextPage();
                          if (response) {
                            // CustomSnackbar.showCustomSnackBar(message: 'Success');

                            final status = await controller
                                .addEmergencyContacts();
                            if (status) {
                              Get.back();
                              CustomSnackbar.showCustomSnackBar(
                                  message: 'Emergency contacts are added successfully.');
                              profileController.getEmergencyContacts();
                            } else {
                              CustomSnackbar.showCustomSnackBar(
                                  message: 'Internet failed to establish proper connection. Please try again later.');
                            }
                          } else {

                          }
                        }),
                ))),
        ],
      ),
    ),);
  }
}

class EmergencyContactsTile extends StatefulWidget {
  EmergencyContactsTile({
    @required this.firstNameController,
    @required this.lastNameController,
    @required this.phoneController,
    @required this.onRemove,
    @required this.firstNameNode,
    @required this.lastNameNode,
    @required this.phoneNode,
  });

  final TextEditingController firstNameController;
  final TextEditingController lastNameController;
  final TextEditingController phoneController;
  final FocusNode firstNameNode;
  final FocusNode lastNameNode;
  final FocusNode phoneNode;
  final Function onRemove;

  @override
  _EmergencyContactsTileState createState() => _EmergencyContactsTileState();
}

class _EmergencyContactsTileState extends State<EmergencyContactsTile> {
  FocusNode focusNode;

  @override
  Widget build(BuildContext context) {
    focusNode = FocusScope.of(context);
    return Card(
      margin: EdgeInsets.all(8),
      child: Container(
        color: Colors.white,
        child: Column(
          children: [
            Container(
              color: Get.theme.primaryColor,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(),
                  Text(
                    'Contact Details'.tr,
                    style: Get.textTheme.headline5.copyWith(
                      color: Colors.white,
                    ),
                  ),
                  IconButton(
                      onPressed: widget.onRemove,
                      icon: Icon(
                        Icons.delete,
                        color: Colors.white,
                      )),
                ],
              ),
            ),
            SizedBox(height: 8),
            Container(
              padding: EdgeInsets.symmetric(horizontal: 8),
              child: Column(
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: CustomTextInputField(
                          textController: widget.firstNameController,
                          focusNode: widget.firstNameNode,
                          label: 'Full Name'.tr,
                          onSubmit: (_) =>
                              focusNode.requestFocus(widget.phoneNode),
                        ),
                      ),
                      // SizedBox(width: 8),
                      // Expanded(
                      //   child: CustomTextInputField(
                      //     textController: widget.lastNameController,
                      //     label: 'Last Name'.tr,
                      //     onSubmit: (_) =>
                      //         focusNode.requestFocus(widget.phoneNode),
                      //     focusNode: widget.lastNameNode,
                      //   ),
                      // ),
                    ],
                  ),
                  SizedBox(height: 16),
                  CustomTextInputField(
                    inputType: TextInputType.phone,
                    textController: widget.phoneController,
                    label: 'Contact Number'.tr,
                    onSubmit: (_) => focusNode.unfocus(),
                    focusNode: widget.phoneNode,
                  ),
                  SizedBox(
                    height: 8,
                  ),
                  SizedBox(height: 16),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ExistingContactDetail extends StatefulWidget {
  ExistingContactDetail({
    @required this.phoneNumber,
    @required this.name
  });

  final String phoneNumber;
  final String name;

  @override
  _ExistingContactDetailState createState() => _ExistingContactDetailState();
}

class _ExistingContactDetailState extends State<ExistingContactDetail> {
  FocusNode focusNode;

  @override
  Widget build(BuildContext context) {
    focusNode = FocusScope.of(context);
    return Card(
      margin: EdgeInsets.symmetric(horizontal:8, vertical: 8),
      child: Container(
        color: Colors.white,
        child: Column(
          children: [
            Container(
              color: Get.theme.primaryColor,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(),
                  Text(
                    'Existing Details'.tr,
                    style: Get.textTheme.headline5.copyWith(
                      color: Colors.white,
                    ),
                  ),
                  IconButton(
                      onPressed: (){},
                      icon: Icon(
                        Icons.delete,
                        color: Colors.transparent,
                      )),
                ],
              ),
            ),
            SizedBox(height: 8),
            Container(
              padding: EdgeInsets.only(left: 16, right: 16, top: 16),
              child: CustomTextInputField(
                  label: widget.name,
                  enabled: false
              ),
            ),
            Container(
              padding: EdgeInsets.only(left: 16, right: 16, top: 16),
              child: CustomTextInputField(
                inputType: TextInputType.phone,
                label: widget.phoneNumber,
                enabled: false
              ),
            ),
            SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}
