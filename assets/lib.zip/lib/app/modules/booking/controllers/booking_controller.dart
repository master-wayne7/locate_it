import 'dart:core';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:puryaideu/app/data/models/available_rider.dart';
import 'package:puryaideu/app/data/models/booking.dart';
import 'package:puryaideu/app/data/models/distance.dart';
import 'package:puryaideu/app/data/models/estimated_price.dart';
import 'package:puryaideu/app/data/models/place.dart';
import 'package:puryaideu/app/data/models/prediction.dart';
import 'package:puryaideu/app/data/network/location_request.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/data/repositories/booking_repository.dart';
import 'package:puryaideu/app/data/repositories/google_repository.dart';
import 'package:puryaideu/app/data/repositories/rider_repository.dart';
import 'package:puryaideu/app/data/repositories/user_repository.dart';
import 'package:puryaideu/app/data/services/location_address.dart';
import 'package:puryaideu/app/data/services/location_fetcher.dart';
import 'package:puryaideu/app/enums/location_type.dart';
import 'package:puryaideu/app/enums/map_events.dart';
import 'package:puryaideu/app/enums/ride_type.dart';
import 'package:puryaideu/app/modules/booking/model/booking_request_model.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'booking_map_controller.dart';

class BookingController extends GetxController {
  BookingMapController _bookingMapController;
  final _currentLocation = LatLng(27.6867784, 85.3041796).obs;
  LatLng pickUpLocation;
  LatLng destinationLocation;
  String currentPlaceName;
  String pickupName;
  String destinationName;
  TextEditingController promoController = TextEditingController();

  final carPricesBreakdown = PriceBreakdown().obs;
  final bikePricesBreakdown = PriceBreakdown().obs;
  final safariPricesBreakdown = PriceBreakdown().obs;
  final foodDeliveryPricesBreakdown = PriceBreakdown().obs;
  final courierPricesBreakdown = PriceBreakdown().obs;

  final requestRideButton = true.obs;
  final searchByPinButton = true.obs;

  // final focusedNode = FocusNode().obs;
  final mapEvents = MapEvents.NONE.obs;
  final _searchByPin = false.obs;
  final _locationName = ''.obs;
  final locationType = LocationType.NONE.obs;
  final _predictionList = [].obs;
  final _lastLocation = LatLng(27.6867784, 85.3041796).obs;
  TextEditingController pickupInputController = TextEditingController();
  TextEditingController destinationInputController = TextEditingController();
  String errorMessage;
  final input = ''.obs;
  DistanceDTO _distanceDTO;
  final editSavedAddress = false.obs;
  String rideDistance = '';

  final _selectedRideType = RideType.BIKE.obs;
  String rideDuration = '';

  final promotionVoucherId = 0.obs;

  double carPrice;
  double bikePrice;
  double citySafariPrice;
  double foodDeliveryPrice;
  double courierPrice;

  double originalCarPrice;
  double originalBikePrice;
  double originalCitySafariPrice;
  double originalFoodDeliveryPrice;
  double originalCourierPrice;

  int bookingId;
  Booking booking;

  //Home and Work Addresses
  LatLng homeLocation;
  LatLng workLocation;
  String homeName = '';
  String workName = '';
  LatLng locationPlaceHolder;
  final nameHolder = ''.obs;

  final extraBookingList = [].obs;

  final rebookedList = [].obs;

  bool get searchByPin => _searchByPin.value;

  LatLng get currentLocation => _currentLocation.value;

  String get locationName => _locationName.value;

  List get predictionList => _predictionList;

  LatLng get lastLocation => _lastLocation.value;

  RideType get selectedRideType => _selectedRideType.value;

  updateLastLocation(LatLng location) => _lastLocation.value = location;

  @override
  void onInit() {
    _currentLocation.value = SessionManager.instance.currentLocation;
    super.onInit();
  }

  @override
  void onReady() {
    _bookingMapController = Get.find();
    LocationAddress.getAddressFromCoordinates(currentLocation).then((name) {
      currentPlaceName = name;
      pickupInputController.text = currentPlaceName;
    });
    if (mapEvents.value == MapEvents.REBOOKED) {
      print('Reached here');
      print(rebookedList[2]);
      setCoordinatesOnMapRebooked();
    }
    super.onReady();
  }

  @override
  void onClose() {}

  moveToCurrentLocation() async {
    _bookingMapController.moveCameraToLocation(currentLocation, zoomLevel: 20);
    final _location = await LocationFetcher.determinePosition();
    _currentLocation.value = _location;
    LocationAddress.getAddressFromCoordinates(currentLocation).then((name) {
      currentPlaceName = name;
      pickupInputController.text = currentPlaceName;
    });
  }

  Future<bool> saveHomeAndWorkLocaton() async {
    // showProgressBar();
    // if (locationType.value == LocationType.HOME) {
    //   SessionManager.instance.setHomeLocation(locationPlaceHolder);
    //   SessionManager.instance.setHome(nameHolder.value);
    // } else {
    //   SessionManager.instance.setWorkLocation(locationPlaceHolder);
    //   SessionManager.instance.setWork(nameHolder.value);
    // }

    final response = await LocationRequest.updateUserHomeAndWorkLocation()
        .catchError((error) {
      errorMessage = error;
    });
    if (response == null) {
      if (locationType.value == LocationType.HOME) {
        SessionManager.instance.setHomeLocation(homeLocation);
        SessionManager.instance.setHome(homeName);
      } else {
        SessionManager.instance.setWorkLocation(workLocation);
        SessionManager.instance.setWork(workName);
      }
      // hideProgressBar();
      return false;
    }
    // hideProgressBar();
    return true;
  }

  void addHomeAndWorkTask(LocationType type) {
    locationType.value = type;
    _searchByPin.value = true;
    moveToCurrentLocation();
  }

  void setLocationToHolder(
      LocationType locationDataType, LocationType fieldType) {
    print('Home location is ${homeLocation}');
    print('Work location is ${workLocation}');
    if (locationDataType == LocationType.HOME) {
      locationPlaceHolder = homeLocation;
      nameHolder.value = homeName;
    } else {
      locationPlaceHolder = workLocation;
      nameHolder.value = workName;
    }
  }

  void setHomeAndWorkAddress() {
    print('SET HOME AND WORK ADDRES');
    homeLocation = SessionManager.instance.homeLocation;
    homeName = SessionManager.instance.home;
    workName = SessionManager.instance.work;
    workLocation = SessionManager.instance.workLocation;
    print(SessionManager.instance.homeLocation);
    print(SessionManager.instance.home);
    print(SessionManager.instance.work);
    print(SessionManager.instance.workLocation);
  }

  setHomeLocation() {
    homeLocation = lastLocation;
    homeName = locationName;
    SessionManager.instance.setHomeLocation(homeLocation);
    SessionManager.instance.setHome(homeName);
  }

  setWorkLocation() {
    workLocation = lastLocation;
    workName = locationName;
    SessionManager.instance.setWorkLocation(workLocation);
    SessionManager.instance.setWork(workName);
  }

  // void setPickupControllerValue() {
  //   pickUpLocation = currentLocation;
  //   pickupName = currentPlaceName;
  //   if (pickupPlaceName.value == '') {
  //     pickupInputController.text = currentPlaceName.value;
  //   } else {
  //     pickupInputController.text = pickupPlaceName.value;
  //   }
  // }

  updatePredictionList(List<Prediction> list) => _predictionList.value = list;

  getPredictions(String keyword) async {
    print('I am in predictioni list===');
    input.value = keyword;
    debounce(input, (_) async {
      if (input.value.length > 2) {
        final list = await GoogleRepository.getAutoCompletePlaces(input.value)
            .catchError((error) {
          errorMessage = "Predictions are unavailable. Please try again!";
        });
        if (list == null) {
          CustomSnackbar.showCustomSnackBar(
              message: 'Server error: Something went wrong. Please try again!');
          return;
        }
        updatePredictionList(list);
      } else {
        _predictionList.value = [];
      }
    }, time: Duration(seconds: 1));
  }

  void searchByPinTask(LocationType type) {
    _bookingMapController.clearMap();
    resetData();
    mapEvents.value = MapEvents.NONE;
    _searchByPin.value = true;
    locationType.value = type;

    if (type == LocationType.PICKUP) {
      (pickUpLocation != null)
          ? _bookingMapController.moveCameraToLocation(pickUpLocation)
          : moveToCurrentLocation();
    } else if (type == LocationType.WORK) {
      (workLocation != null)
          ? _bookingMapController.moveCameraToLocation(workLocation)
          : moveToCurrentLocation();
    } else if (type == LocationType.HOME) {
      (homeLocation != null)
          ? _bookingMapController.moveCameraToLocation(homeLocation)
          : moveToCurrentLocation();
    } else {
      (destinationLocation != null)
          ? _bookingMapController.moveCameraToLocation(destinationLocation)
          : moveToCurrentLocation();
    }
  }

  resetData() {
    _predictionList.value = [];
    _searchByPin.value = false;
    destinationInputController.text = '';
    mapEvents.value = MapEvents.NONE;
  }

  updateLastLocationName(String name) => _locationName.value = name;

  Future<bool> fetchLatLngFromId(String placeId, LocationType type) async {
    Place placeDetail =
        await GoogleRepository.getPlaceDetailById(placeId).catchError((error) {
      errorMessage = "Location services are unavailable. Please try again!";
    });

    if (placeDetail == null) {
      return false;
    }
    LatLng latLng = LatLng(
        placeDetail.geometry.location.lat, placeDetail.geometry.location.lng);
    updateLastLocation(latLng);
    locationType.value = type;
    return true;
  }

  void showOnMap() {
    _bookingMapController.clearMap();
    _searchByPin.value = true;
    _predictionList.value = [];
    _bookingMapController.moveCameraToLocation(lastLocation);
  }

  setPickupLocation() {
    pickUpLocation = lastLocation;
    pickupName = locationName;
    pickupInputController.text = pickupName;
    if (destinationLocation != null) {
      setCoordinatesOnMap();
    }
  }

  void addDestinationLocation() {
    destinationLocation = lastLocation;
    destinationName = locationName;
    destinationInputController.text = destinationName;
    if (pickUpLocation == null) {
      pickUpLocation = currentLocation;
      pickupName = currentPlaceName;
    }
    setCoordinatesOnMap();
  }

  void setCoordinatesOnMap() async {
    pickupInputController.text = pickupName;
    destinationInputController.text = destinationName;
    DistanceDTO distanceDTO =
        await GoogleRepository.getDistanceBetweenCoordinates(
                pickUpLocation, destinationLocation)
            .catchError((error) {
      errorMessage = "Location services are unavailable. Please try again!";
    });
    if (distanceDTO == null) {
      CustomSnackbar.showCustomSnackBar(message: errorMessage);
      _bookingMapController.clearMap();
      moveToCurrentLocation();
      return;
    }
    _distanceDTO = distanceDTO;
    // pickupName = _distanceDTO.originAddresses[0];
    // destinationName = _distanceDTO.destinationAddresses[0];
    var distanceInMeter = _distanceDTO.rows[0].elements[0].distance.value;
    var durationTime = _distanceDTO.rows[0].elements[0].duration.value;
    String str = distanceInMeter.toString();
    // var arr = str.split(' ');
    rideDistance = str;
    rideDuration = durationTime.toString();
    final response = await BookingRepository.getEstimatedPrice(
            pickUpLocation, rideDistance, rideDuration)
        .catchError((error) {
      errorMessage = "Internet connection error.";
    });
    print("response is ============== $response");
    if (response == null) {
      CustomSnackbar.showCustomSnackBar(message: errorMessage);
      return;
    }
    // carPrice = 200.0;
    // bikePrice = 150.0;
    // citySafariPrice = 175.0;
    carPrice = response[1].priceBreakdown.totalPrice;
    bikePrice = response[0].priceBreakdown.totalPrice;
    citySafariPrice = response[2].priceBreakdown.totalPrice;
    foodDeliveryPrice = response[4].priceBreakdown.totalPrice;
    courierPrice = response[5].priceBreakdown.totalPrice;

    originalCarPrice = response[1].priceBreakdown.originalPrice;
    originalBikePrice = response[0].priceBreakdown.originalPrice;
    originalCitySafariPrice = response[2].priceBreakdown.originalPrice;
    originalFoodDeliveryPrice = response[4].priceBreakdown.originalPrice;
    originalCourierPrice = response[5].priceBreakdown.originalPrice;

    print('Original price: $originalCarPrice');
    print('Original price: $originalBikePrice');
    print('Original price: $originalCitySafariPrice');

    bikePricesBreakdown.value = response[0].priceBreakdown;
    carPricesBreakdown.value = response[1].priceBreakdown;
    safariPricesBreakdown.value = response[2].priceBreakdown;
    foodDeliveryPricesBreakdown.value = response[4].priceBreakdown;
    courierPricesBreakdown.value = response[5].priceBreakdown;

    promotionVoucherId.value =
        response[1].priceBreakdown.promotionVoucherId == null
            ? 0
            : response[1].priceBreakdown.promotionVoucherId;
    print('Promotion Voucher ID: $promotionVoucherId');

    mapEvents.value = MapEvents.DESTINATION_SELECTED;
    vehicleIconsOnMap();
    _bookingMapController.makeRoute(
        pickUpLocation,
        destinationLocation,
        SessionManager.instance.pickupIcon,
        SessionManager.instance.destinationIcon, originTap: () {
      searchByPinTask(LocationType.PICKUP);
    }, destinationTap: () {
      searchByPinTask(LocationType.DESTINATION);
    });
    _searchByPin.value = false;
  }

  void getEstimatedPrice() async {
    pickupInputController.text = pickupName;
    destinationInputController.text = destinationName;
    DistanceDTO distanceDTO =
        await GoogleRepository.getDistanceBetweenCoordinates(
                pickUpLocation, destinationLocation)
            .catchError((error) {
      errorMessage = "Location services are unavailable. Please try again!";
    });
    if (distanceDTO == null) {
      CustomSnackbar.showCustomSnackBar(message: errorMessage);
      _bookingMapController.clearMap();
      moveToCurrentLocation();
      return;
    }
    _distanceDTO = distanceDTO;
    // pickupName = _distanceDTO.originAddresses[0];
    // destinationName = _distanceDTO.destinationAddresses[0];
    var distanceInMeter = _distanceDTO.rows[0].elements[0].distance.value;
    var durationTime = _distanceDTO.rows[0].elements[0].duration.value;
    String str = distanceInMeter.toString();
    // var arr = str.split(' ');
    rideDistance = str;
    rideDuration = durationTime.toString();
    final response = await BookingRepository.getEstimatedPrice(
            pickUpLocation, rideDistance, rideDuration)
        .catchError((error) {
      errorMessage = "Internet connection error.";
    });
    print("response is ============== $response");
    if (response == null) {
      CustomSnackbar.showCustomSnackBar(message: errorMessage);
      return;
    }
    // carPrice = 200.0;
    // bikePrice = 150.0;
    // citySafariPrice = 175.0;
    carPrice = response[1].priceBreakdown.totalPrice;
    bikePrice = response[0].priceBreakdown.totalPrice;
    citySafariPrice = response[2].priceBreakdown.totalPrice;
    foodDeliveryPrice = response[4].priceBreakdown.totalPrice;
    courierPrice = response[5].priceBreakdown.totalPrice;

    originalCarPrice = response[1].priceBreakdown.originalPrice;
    originalBikePrice = response[0].priceBreakdown.originalPrice;
    originalCitySafariPrice = response[2].priceBreakdown.originalPrice;
    originalFoodDeliveryPrice = response[4].priceBreakdown.originalPrice;
    originalCourierPrice = response[5].priceBreakdown.originalPrice;

    print('Original price: $originalCarPrice');
    print('Original price: $originalBikePrice');
    print('Original price: $originalCitySafariPrice');

    bikePricesBreakdown.value = response[0].priceBreakdown;
    carPricesBreakdown.value = response[1].priceBreakdown;
    safariPricesBreakdown.value = response[2].priceBreakdown;
    foodDeliveryPricesBreakdown.value = response[4].priceBreakdown;
    courierPricesBreakdown.value = response[5].priceBreakdown;

    promotionVoucherId.value =
        response[1].priceBreakdown.promotionVoucherId == null
            ? 0
            : response[1].priceBreakdown.promotionVoucherId;
    print('Promotion Voucher ID: $promotionVoucherId');
    update();
  }

  void vehicleIconsOnMap() {
    final icon = selectedRideType == RideType.CAR
        ? SessionManager.instance.carIcon
        : selectedRideType == RideType.BIKE
            ? SessionManager.instance.bikeIcon
            : selectedRideType == RideType.AMBULANCE
                ? SessionManager.instance.ambulanceIcon
                : selectedRideType == RideType.COURIER
                    ? SessionManager.instance.medicalIcon
                    : SessionManager.instance.foodIcon;

    _bookingMapController.displayVehicleOnMap(icon);
  }

  void setCoordinatesOnMapRebooked() async {
    pickupInputController.text = rebookedList[1];
    pickupName = rebookedList[1];
    pickUpLocation = rebookedList[3];
    destinationLocation = rebookedList[4];
    destinationName = rebookedList[2];
    destinationInputController.text = rebookedList[2];
    DistanceDTO distanceDTO =
        await GoogleRepository.getDistanceBetweenCoordinates(
                rebookedList[3], rebookedList[4])
            .catchError((error) {
      errorMessage = "Location services are unavailable. Please try again!";
    });
    print("Distance dtos is === $distanceDTO");
    if (distanceDTO == null) {
      CustomSnackbar.showCustomSnackBar(message: errorMessage);
      _bookingMapController.clearMap();
      moveToCurrentLocation();
      return;
    }
    _distanceDTO = distanceDTO;
    // pickupName = _distanceDTO.originAddresses[0];
    // destinationName = _distanceDTO.destinationAddresses[0];
    var distanceInMeter = _distanceDTO.rows[0].elements[0].distance.value;
    var durationTime = _distanceDTO.rows[0].elements[0].duration.value;
    String str = distanceInMeter.toString();
    // var arr = str.split(' ');
    rideDistance = str;
    rideDuration = durationTime.toString();
    final response = await BookingRepository.getEstimatedPrice(
            pickUpLocation, rideDistance, rideDuration)
        .catchError((error) {
      errorMessage = "Internet connection error.";
    });
    print("response is ============== $response");
    if (response == null) {
      CustomSnackbar.showCustomSnackBar(message: errorMessage);
      return;
    }
    // carPrice = 200.0;
    // bikePrice = 150.0;
    // citySafariPrice = 175.0;
    carPrice = response[1].priceBreakdown.totalPrice;
    bikePrice = response[0].priceBreakdown.totalPrice;
    citySafariPrice = response[2].priceBreakdown.totalPrice;
    foodDeliveryPrice = response[4].priceBreakdown.totalPrice;
    courierPrice = response[5].priceBreakdown.totalPrice;

    bikePricesBreakdown.value = response[0].priceBreakdown;
    carPricesBreakdown.value = response[1].priceBreakdown;
    safariPricesBreakdown.value = response[2].priceBreakdown;
    foodDeliveryPricesBreakdown.value = response[4].priceBreakdown;
    courierPricesBreakdown.value = response[5].priceBreakdown;
    print("Base fare is: $carPricesBreakdown.value.baseFare");
    mapEvents.value = MapEvents.DESTINATION_SELECTED;
    _bookingMapController.makeRoute(
        pickUpLocation,
        destinationLocation,
        SessionManager.instance.pickupIcon,
        SessionManager.instance.destinationIcon, originTap: () {
      searchByPinTask(LocationType.PICKUP);
    }, destinationTap: () {
      searchByPinTask(LocationType.DESTINATION);
    });
    _searchByPin.value = false;
  }

  void setSelectedRideType(type) => _selectedRideType.value = type;

  bool handleBackButton() {
    bool goBack = false;
    if (mapEvents.value == MapEvents.DESTINATION_SELECTED) {
      mapEvents.value = MapEvents.NONE;
      resetMap();
      vehicleIconsOnMap();
    } else if (mapEvents.value == MapEvents.REBOOKED) {
      goBack = true;
      mapEvents.value = MapEvents.NONE;
    } else {
      if (_searchByPin.value) {
        resetMap();
        vehicleIconsOnMap();
      } else {
        goBack = true;
      }
    }

    return goBack;
  }

  String handleBackButtonRebooked() {
    String goBack = "false";
    if (mapEvents.value == MapEvents.DESTINATION_SELECTED) {
      mapEvents.value = MapEvents.NONE;
      resetMap();
      vehicleIconsOnMap();
    } else if (mapEvents.value == MapEvents.REBOOKED) {
      goBack = "rebooked";
      mapEvents.value = MapEvents.NONE;
    } else {
      if (_searchByPin.value) {
        resetMap();
        vehicleIconsOnMap();
      } else {
        goBack = "true";
      }
    }

    return goBack;
  }

  resetMap() {
    _bookingMapController.clearMap();
    pickUpLocation = null;
    destinationLocation = null;
    destinationName = '';
    destinationInputController.text = '';
    _searchByPin.value = false;
    moveToCurrentLocation();
  }

  Future<bool> bookRide() async {
    BookingRequestModel bookingRequestModel = BookingRequestModel(
        origin: pickupName.contains('Search')
            ? await LocationAddress.getPlace(LatLng(
            pickUpLocation.latitude,
            pickUpLocation.longitude)): pickupName,
        destination: selectedRideType == RideType.AMBULANCE
            ? pickupName
            : destinationName.contains('Search')
                ? await LocationAddress.getPlace(LatLng(
                    destinationLocation.latitude,
                    destinationLocation.longitude))
                : destinationName,
        distance: selectedRideType == RideType.AMBULANCE
            ? 0
            : int.parse(rideDistance),
        duration: selectedRideType == RideType.AMBULANCE
            ? 0
            : int.parse(rideDuration),
        latitudeOrigin:
            double.parse((pickUpLocation.latitude).toStringAsFixed(10)),
        longitudeOrigin:
            double.parse((pickUpLocation.longitude).toStringAsFixed(10)),
        latitudeDestination: selectedRideType == RideType.AMBULANCE
            ? double.parse((pickUpLocation.latitude).toStringAsFixed(10))
            : double.parse((destinationLocation.latitude).toStringAsFixed(10)),
        longitudeDestination: selectedRideType == RideType.AMBULANCE
            ? double.parse((pickUpLocation.longitude).toStringAsFixed(10))
            : double.parse((destinationLocation.longitude).toStringAsFixed(10)),
        price: selectedRideType == RideType.BIKE
            ? bikePrice
            : selectedRideType == RideType.CAR
                ? carPrice
                : selectedRideType == RideType.CITY_SAFARI
                    ? citySafariPrice
                    : selectedRideType == RideType.FOOD_DELIVERY
                        ? foodDeliveryPrice
                        : selectedRideType == RideType.COURIER
                            ? courierPrice
                            : selectedRideType == RideType.AMBULANCE
                                ? 0.0
                                : bikePrice,
        vehicleType: selectedRideType == RideType.BIKE
            ? 1
            : selectedRideType == RideType.CAR
                ? 2
                : selectedRideType == RideType.CITY_SAFARI
                    ? 3
                    : selectedRideType == RideType.AMBULANCE
                        ? 4
                        : selectedRideType == RideType.FOOD_DELIVERY
                            ? 5
                            : selectedRideType == RideType.COURIER
                                ? 6
                                : 1,
        voucherId:
            promotionVoucherId.value == 0 ? null : promotionVoucherId.value);

    var response = await BookingRepository.bookRide(bookingRequestModel)
        .catchError((error) {
      errorMessage =
          "Booking service is currently unavailable. Please try again!";
    });

    print('Response is $response');
    // print(response);
    print(errorMessage);
    if (response == null) {
      return false;
    }

    //
    // bookingId = response.id;
    booking = response;
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    UserRepository userRepository = UserRepository(prefs: sharedPreferences);
    userRepository.setSosId('no');
    return true;
    //
    // return response == null ? false : true;
  }

  Future<bool> getBookingDetail() async {
    final response =
        await BookingRepository.getBookingById(bookingId).catchError((error) {
      errorMessage = "Booking details are unavailable. Please try again!";
    });

    if (response == null) {
      return false;
    }
    booking = response;
    return true;
  }

  Future<bool> getActiveBookingDetail() async {
    final response =
        await BookingRepository.getActiveBooking().catchError((error) {
      errorMessage = "No active booking found.";
    });

    if (response == null) {
      return false;
    }
    booking = response;
    return true;
  }

  Future<List<AvailableRider>> fetchAvailableRiders() async {
    int vehicleTypeId = selectedRideType == RideType.BIKE
        ? 1
        : selectedRideType == RideType.CAR
            ? 2
            : selectedRideType == RideType.CITY_SAFARI
                ? 3
                : selectedRideType == RideType.AMBULANCE
                    ? 4
                    : 1;
    final status =
        await RiderRepository.getAvailableRiders(currentLocation, vehicleTypeId)
            .catchError((error) {
      errorMessage = "No available riders. Please try again!";
    });

    print('Available riders status $status');

    if (status == null) {
      //CustomSnackbar.showCustomSnackBar(message: errorMessage);
      return null;
    }
    return status;
  }

  Future<List<AvailableRider>> fetchAvailableRidersforStartUp() async {
    int vehicleTypeId = selectedRideType == RideType.BIKE
        ? 1
        : selectedRideType == RideType.CAR
            ? 2
            : selectedRideType == RideType.CITY_SAFARI
                ? 3
                : selectedRideType == RideType.AMBULANCE
                    ? 4
                    : 1;
    final status =
        await RiderRepository.getAvailableRiders(currentLocation, vehicleTypeId)
            .catchError((error) {
      errorMessage = "No available riders. Please try again!";
    });

    print('Available riders status $status');

    if (status == null) {
      //CustomSnackbar.showCustomSnackBar(message: errorMessage);
      return null;
    }
    return status;
  }
}
