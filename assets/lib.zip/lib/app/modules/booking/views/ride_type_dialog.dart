import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/data/repositories/user_repository.dart';
import 'package:puryaideu/app/enums/ride_type.dart';
import 'package:puryaideu/app/modules/booking/controllers/booking_controller.dart';
import 'package:puryaideu/app/modules/booking/controllers/booking_map_controller.dart';
import 'package:puryaideu/app/modules/extra_trip/views/dialogs/cancel_dialog.dart';
import 'package:puryaideu/app/modules/splash/controllers/all_data_controller.dart';
import 'package:puryaideu/app/routes/app_pages.dart';
import 'package:puryaideu/app/widgets/add_promo_button.dart';
import 'package:puryaideu/app/widgets/banner.dart' as ban;
import 'package:puryaideu/app/widgets/current_location_button.dart';
import 'package:puryaideu/app/widgets/custom_button.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:puryaideu/app/widgets/sliding_up_panel.dart';
import 'package:puryaideu/generated/locales.g.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shimmer/shimmer.dart';

import 'location_icon_tile.dart';
import 'user_location_input_screen.dart';

class RideTypeDialog extends GetView<BookingController> {
  BookingMapController mapController = Get.find();

  @override
  Widget build(BuildContext context) {
    return Stack(children: [
      (controller.selectedRideType != RideType.CAR &&
              controller.selectedRideType != RideType.BIKE &&
              controller.selectedRideType != RideType.CITY_SAFARI)
          ? Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Column(children: [
                Container(
                  color: Colors.white,
                  child: Column(
                    children: [
                      Row(
                        children: [
                          controller.selectedRideType == RideType.COURIER
                              ? Expanded(
                                  child: Obx(
                                    () => ExtraVehicleCard(
                                      imageUrl: 'assets/delivery.png',
                                      onTap: () {
                                        controller
                                            .setSelectedRideType(RideType.COURIER);
                                      },
                                      isSelected: controller.selectedRideType ==
                                              RideType.COURIER
                                          ? true
                                          : false,
                                      price:
                                          '${LocaleKeys.units_rs.tr} ${controller.courierPrice}',
                                      vehicleType: "Pickup Truck".tr,
                                    ),
                                  ),
                                )
                              : Container(),
                          controller.selectedRideType == RideType.FOOD_DELIVERY
                              ? Expanded(
                                  child: Obx(
                                    () => ExtraVehicleCard(
                                      imageUrl: 'assets/food_truck.png',
                                      onTap: () {
                                        controller
                                            .setSelectedRideType(RideType.FOOD_DELIVERY);
                                      },
                                      isSelected: controller.selectedRideType ==
                                              RideType.FOOD_DELIVERY
                                          ? true
                                          : false,
                                      price:
                                          '${LocaleKeys.units_rs.tr} ${controller.foodDeliveryPrice}',
                                      vehicleType: "Food Delivery".tr,
                                    ),
                                  ),
                                )
                              : Container(),
                          controller.selectedRideType == RideType.AMBULANCE
                              ? Expanded(
                                  child: Obx(
                                    () => ExtraVehicleCard(
                                      imageUrl: 'assets/new_ambulance.png',
                                      onTap: () {
                                        controller.setSelectedRideType(
                                            RideType.AMBULANCE);
                                      },
                                      banner: true,
                                      isSelected: controller.selectedRideType ==
                                              RideType.AMBULANCE
                                          ? true
                                          : false,
                                      price: 'No app charges*',
                                      vehicleType: "Ambulance".tr,
                                    ),
                                  ),
                                )
                              : Container(),
                        ],
                      ),
                      controller.selectedRideType != RideType.AMBULANCE
                          ? GestureDetector(
                        onTap: () async {
                          await buildShowGeneralDialog(context);
                        },
                            child: Container(
                              color: Colors.white,
                              child: Row(

                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Expanded(child: SizedBox()),
                                    Icon(Icons.verified_user,
                                        color: Colors.green, size: 18),
                                    Text(
                                      'Rides are insured for a safer experience.',
                                      style: Get.textTheme.headline6.copyWith(
                                          color: Colors.grey[600],
                                          fontSize: 12,
                                          fontWeight: FontWeight.w500),
                                    ),
                                    Icon(Icons.info_rounded,
                                        color: Colors.green, size: 18),
                                    Expanded(child: SizedBox()),
                                  ],
                                ),
                            ),
                          )
                          : Container(),
                    ],
                  ),
                ),
                Container(
                    color: Colors.white,
                    width: Get.width,
                    padding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
                    child: Obx(
                      () => controller.requestRideButton.value
                          ? CustomButton(
                              backgroundColor:
                                  controller.requestRideButton.value
                                      ? Get.theme.primaryColor
                                      : Colors.grey,
                              onPressed: controller.requestRideButton.value
                                  ? () async {
                                      controller.requestRideButton.value =
                                          false;
                                      // if (controller.selectedRideType ==
                                      //     RideType.AMBULANCE) {
                                        controller.requestRideButton
                                            .value = false;
                                        final status =
                                        await controller.bookRide();

                                        Future.delayed(
                                            Duration(seconds: 3))
                                            .then((value) async {
                                          controller.requestRideButton
                                              .value = true;
                                        });
                                        if (status) {
                                          //final response = await controller.getBookingDetail();
                                          // final response = await controller.getActiveBookingDetail();
                                          SessionManager.instance
                                              .setVoucherCode(null);
                                          controller.promotionVoucherId
                                              .value = 0;
                                          final response = true;
                                          if (response) {
                                            Get.offNamed(Routes.TRIP,
                                                arguments:
                                                controller.booking);
                                          } else {
                                            CustomSnackbar
                                                .showCustomSnackBar(
                                                message: controller
                                                    .errorMessage);
                                          }
                                        } else {
                                          CustomSnackbar.showCustomSnackBar(
                                              message:
                                              "Booking services are unavailable.");
                                        }
                                      // } else
                                        // final status =
                                        // await controller.bookRide();
                                      //   controller.extraBookingList.value = [];
                                      // controller.extraBookingList
                                      //     .add(controller.selectedRideType);
                                      // controller.selectedRideType ==
                                      //         RideType.AMBULANCE
                                      //     ? controller.extraBookingList.add(0.0)
                                      //     : controller.extraBookingList
                                      //         .add(controller.bikePrice);
                                      // controller.extraBookingList.add(
                                      //     controller.pickUpLocation.latitude);
                                      // controller.extraBookingList.add(
                                      //     controller.pickUpLocation.longitude);
                                      // controller.extraBookingList.add(controller
                                      //     .destinationLocation.latitude);
                                      // controller.extraBookingList.add(controller
                                      //     .destinationLocation.longitude);
                                      // controller.extraBookingList
                                      //     .add(controller.pickupName);
                                      // controller.extraBookingList
                                      //     .add(controller.destinationName);
                                      // controller.extraBookingList
                                      //     .add(controller.rideDistance);
                                      // print(controller.extraBookingList);
                                      // final status = true;
                                      // if (status) {
                                      //   final response = true;
                                      //   if (response) {
                                      //     Get.offNamed(Routes.EXTRA_TRIP,
                                      //         arguments:
                                      //             controller.extraBookingList);
                                      //   } else {
                                      //     CustomSnackbar.showCustomSnackBar(
                                      //         message: controller.errorMessage);
                                      //   }
                                      // } else {
                                      //   CustomSnackbar.showCustomSnackBar(
                                      //       message:
                                      //           "Booking services are unavailable.");
                                      // }
                                      controller.requestRideButton.value = true;
                                    }
                                  : null,
                              text: "Request Service".tr)
                          : Shimmer.fromColors(
                              baseColor: Color(0xffeeeff3),
                              highlightColor: Colors.white,
                              enabled: true,
                              child: CustomButton(
                                  backgroundColor:
                                      controller.requestRideButton.value
                                          ? Get.theme.primaryColor
                                          : Colors.grey,
                                  onPressed: () async {}

                                  // final status = await controller.bookRide();
                                  // if (status) {
                                  //   //final response = await controller.getBookingDetail();
                                  //   // final response = await controller.getActiveBookingDetail();
                                  //  final response = true;
                                  //   if (response) {
                                  //     Get.offNamed(Routes.TRIP,
                                  //         arguments: controller.booking);
                                  //   } else {
                                  //     CustomSnackbar.showCustomSnackBar(
                                  //         message: controller.errorMessage);
                                  //   }
                                  // } else {
                                  //   CustomSnackbar.showCustomSnackBar(
                                  //       message: "Booking services are unavailable.");
                                  // }

                                  ,
                                  text: LocaleKeys.buttons_request_ride.tr),
                            ),
                    )),
              ]))
          : Stack(
              children: [
                Positioned(
                    bottom: 0,
                    left: 0,
                    right: 0,
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Container(),
                            Column(
                              children: [
                                InsuranceButton(
                                  onPressed: () =>
                                      controller.moveToCurrentLocation(),
                                ),
                                AddPromoButtonRideType(
                                  onPressed: () =>
                                      controller.moveToCurrentLocation(),
                                ),
                                CurrentLocationButton(
                                  onPressed: () =>
                                      controller.moveToCurrentLocation(),
                                ),
                              ],
                            ),
                          ],
                        ),
                        Obx(() => controller.requestRideButton.value
                            ? Container(
                                color: Colors.white,
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Obx(
                                            () => VehicleCard(
                                              isDiscounted: controller
                                                          .promotionVoucherId
                                                          .value ==
                                                      0
                                                  ? false
                                                  : controller.promotionVoucherId
                                                              .value ==
                                                          null
                                                      ? false
                                                      : true,
                                              originalPrice:
                                                  '${controller.originalBikePrice}',
                                              imageUrl: 'assets/bike.png',
                                              onTap: () {
                                                mapController
                                                    .removeVehicleIcons();
                                                controller.setSelectedRideType(
                                                    RideType.BIKE);
                                                mapController
                                                    .displayVehicleOnMap(
                                                        SessionManager
                                                            .instance.bikeIcon);
                                              },
                                              moreInfo: () async {
                                                await buildMoreVehicleDetails(
                                                    context, RideType.BIKE);
                                              },
                                              isSelected:
                                                  controller.selectedRideType ==
                                                          RideType.BIKE
                                                      ? true
                                                      : false,
                                              price: '${controller.bikePrice}',
                                              vehicleType: LocaleKeys
                                                  .vehicle_type_bike.tr,
                                            ),
                                          ),
                                        ),
                                        SizedBox(width: 16),
                                        Expanded(
                                          child: Obx(
                                            () => VehicleCard(
                                              isDiscounted: controller
                                                          .promotionVoucherId
                                                          .value ==
                                                      0
                                                  ? false
                                                  : true,
                                              originalPrice:
                                                  '${controller.originalCarPrice}',
                                              imageUrl: 'assets/car.png',
                                              onTap: () {
                                                mapController
                                                    .removeVehicleIcons();
                                                controller.setSelectedRideType(
                                                    RideType.CAR);
                                                mapController
                                                    .displayVehicleOnMap(
                                                        SessionManager
                                                            .instance.carIcon);
                                              },
                                              moreInfo: () async {
                                                await buildMoreVehicleDetails(
                                                    context, RideType.CAR);
                                              },
                                              isSelected:
                                                  controller.selectedRideType ==
                                                          RideType.CAR
                                                      ? true
                                                      : false,
                                              price: '${controller.carPrice}',
                                              vehicleType: LocaleKeys
                                                  .vehicle_type_taxi.tr,
                                            ),
                                          ),
                                        ),
                                        SizedBox(width: 16),
                                        Expanded(
                                          child: Obx(
                                            () => VehicleCard(
                                              isDiscounted: controller
                                                          .promotionVoucherId
                                                          .value ==
                                                      0
                                                  ? false
                                                  : true,
                                              originalPrice:
                                                  '${controller.originalCitySafariPrice}',
                                              imageUrl: 'assets/tuk-tuk.png',
                                              onTap: () async {
                                                SharedPreferences
                                                    sharedPreferences =
                                                    await SharedPreferences
                                                        .getInstance();
                                                UserRepository userRepository =
                                                    UserRepository(
                                                        prefs:
                                                            sharedPreferences);

                                                bool citySafariArea =
                                                    await userRepository
                                                        .isCitySafariRegion();
                                                if (!citySafariArea) {
                                                  mapController
                                                      .removeVehicleIcons();
                                                  controller
                                                      .setSelectedRideType(
                                                          RideType.CITY_SAFARI);
                                                  mapController
                                                      .displayVehicleOnMap(
                                                          SessionManager
                                                              .instance
                                                              .citySafariIcon);
                                                } else {
                                                  CustomSnackbar.showCustomSnackBar(
                                                      message:
                                                          'City safari is not available in this region.');
                                                }
                                              },
                                              moreInfo: () async {
                                                await buildMoreVehicleDetails(
                                                    context,
                                                    RideType.CITY_SAFARI);
                                              },
                                              isSelected:
                                                  controller.selectedRideType ==
                                                          RideType.CITY_SAFARI
                                                      ? true
                                                      : false,
                                              price:
                                                  '${controller.citySafariPrice}',
                                              vehicleType: LocaleKeys
                                                  .vehicle_type_city_safari.tr,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    GestureDetector(
                                      onTap: () async {
                                        await buildShowGeneralDialog(context);
                                      },
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.center,
                                        children: [
                                          Icon(Icons.verified_user,
                                              color: Colors.green, size: 18),
                                          Text(
                                            'Rides are insured for a safer experience.',
                                            style: Get.textTheme.headline6
                                                .copyWith(
                                                    color: Colors.grey[600],
                                                    fontSize: 12,
                                                    fontWeight:
                                                        FontWeight.w500),
                                          ),
                                          Icon(Icons.info_rounded,
                                              color: Colors.green, size: 18),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              )
                            : Container(
                                color: Colors.white,
                                child: Column(
                                  children: [
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Obx(
                                            () => VehicleCard(
                                              isDiscounted: false,
                                              //originalPrice: '${controller.originalBikePrice}',
                                              imageUrl: 'assets/bike.png',
                                              onTap: () {},
                                              isSelected:
                                                  controller.selectedRideType ==
                                                          RideType.BIKE
                                                      ? true
                                                      : false,
                                              price: '${controller.bikePrice}',
                                              vehicleType: LocaleKeys
                                                  .vehicle_type_bike.tr,
                                              moreInfo: () async {
                                                await buildMoreVehicleDetails(
                                                    context, RideType.BIKE);
                                              },
                                            ),
                                          ),
                                        ),
                                        SizedBox(width: 16),
                                        Expanded(
                                          child: Obx(
                                            () => VehicleCard(
                                              isDiscounted: false,
                                              //originalPrice: '${controller.originalCarPrice}',
                                              imageUrl: 'assets/car.png',
                                              onTap: () {},
                                              isSelected:
                                                  controller.selectedRideType ==
                                                          RideType.CAR
                                                      ? true
                                                      : false,
                                              price: '${controller.carPrice}',
                                              vehicleType: LocaleKeys
                                                  .vehicle_type_taxi.tr,
                                            ),
                                          ),
                                        ),
                                        SizedBox(width: 16),
                                        Expanded(
                                          child: Obx(
                                            () => VehicleCard(
                                              isDiscounted: false,
                                              //originalPrice: '${controller.originalCitySafariPrice}',
                                              imageUrl: 'assets/tuk-tuk.png',
                                              onTap: () {},
                                              isSelected:
                                                  controller.selectedRideType ==
                                                          RideType.CITY_SAFARI
                                                      ? true
                                                      : false,
                                              price:
                                                  '${controller.citySafariPrice}',
                                              vehicleType: LocaleKeys
                                                  .vehicle_type_city_safari.tr,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.center,
                                      children: [
                                        Expanded(child: SizedBox()),
                                        Icon(Icons.verified_user,
                                            color: Colors.green, size: 18),
                                        Text(
                                          'Rides are insured for a safer experience.',
                                          style: Get.textTheme.headline6
                                              .copyWith(
                                                  color: Colors.grey[600],
                                                  fontSize: 12,
                                                  fontWeight: FontWeight.w500),
                                        ),
                                        Icon(Icons.info_rounded,
                                            color: Colors.green, size: 18),
                                        Expanded(child: SizedBox()),
                                      ],
                                    ),
                                  ],
                                ),
                              )),
                        Container(
                            color: Colors.white,
                            width: Get.width,
                            padding: EdgeInsets.symmetric(
                                horizontal: 8, vertical: 8),
                            child: Obx(
                              () => controller.requestRideButton.value
                                  ? CustomButton(
                                      backgroundColor:
                                          controller.requestRideButton.value
                                              ? Get.theme.primaryColor
                                              : Colors.grey,
                                      onPressed: controller
                                              .requestRideButton.value
                                          ? () async {
                                              controller.requestRideButton
                                                  .value = false;
                                              final status =
                                                  await controller.bookRide();

                                              Future.delayed(
                                                      Duration(seconds: 3))
                                                  .then((value) async {
                                                controller.requestRideButton
                                                    .value = true;
                                              });
                                              if (status) {
                                                //final response = await controller.getBookingDetail();
                                                // final response = await controller.getActiveBookingDetail();
                                                SessionManager.instance
                                                    .setVoucherCode(null);
                                                controller.promotionVoucherId
                                                    .value = 0;
                                                final response = true;
                                                if (response) {
                                                  Get.offNamed(Routes.TRIP,
                                                      arguments:
                                                          controller.booking);
                                                } else {
                                                  CustomSnackbar
                                                      .showCustomSnackBar(
                                                          message: controller
                                                              .errorMessage);
                                                }
                                              } else {
                                                CustomSnackbar.showCustomSnackBar(
                                                    message:
                                                        "Booking services are unavailable.");
                                              }
                                            }
                                          : null,
                                      text: LocaleKeys.buttons_request_ride.tr)
                                  : Shimmer.fromColors(
                                      baseColor: Colors.white,
                                      highlightColor: Get.theme.primaryColor
                                          .withOpacity(0.4),
                                      enabled: true,
                                      child: CustomButton(
                                          backgroundColor:
                                              controller.requestRideButton.value
                                                  ? Get.theme.primaryColor
                                                  : Colors.grey,
                                          onPressed: () {},
                                          text: LocaleKeys
                                              .buttons_request_ride.tr),
                                    ),
                            )),
                      ],
                    )),
              ],
            )
    ]);
  }
}

class VehicleCard extends StatelessWidget {
  final String imageUrl;
  final String vehicleType;
  final String price;
  final Function onTap;
  final Color textColor;
  final bool isSelected;
  final Function moreInfo;
  final bool isDiscounted;
  final String originalPrice;

  VehicleCard(
      {this.imageUrl,
      this.textColor = const Color.fromRGBO(225, 89, 89, 1),
      this.vehicleType,
      this.price,
      this.isSelected,
      this.moreInfo = null,
      this.isDiscounted = false,
      this.originalPrice = '',
      this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        color: Colors.white,
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
          decoration: isSelected
              ? BoxDecoration(color: Colors.white, boxShadow: [
                  BoxShadow(
                      color: Colors.black.withOpacity(0.2),
                      blurRadius: 8,
                      spreadRadius: 1),
                ])
              : BoxDecoration(),
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Column(
            children: [
              Image.asset(
                imageUrl,
                height: 70,
                width: 70,
                fit: BoxFit.fill,
              ),
              SizedBox(width: 16),
              // isSelected
              //     ? Row(
              //         mainAxisAlignment: MainAxisAlignment.center,
              //         children: [
              //           Text(vehicleType,
              //               maxLines: 1,
              //               overflow: TextOverflow.ellipsis,
              //               style: Get.textTheme.headline5.copyWith(
              //                 fontSize: isSelected
              //                     ? getResponsiveFont(15)
              //                     : getResponsiveFont(14),
              //                 fontWeight: isSelected
              //                     ? FontWeight.w600
              //                     : FontWeight.w400,
              //                 color: isSelected
              //                     ? Colors.grey[700]
              //                     : Colors.grey[600],
              //               )),
              //           SizedBox(width: 2),
              //           GestureDetector(
              //             onTap: moreInfo,
              //             child: Icon(Icons.info_outlined,
              //                 color: Colors.grey[700], size: 14),
              //           ),
              //         ],
              //       )
              //     :
            Text(vehicleType,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: Get.textTheme.headline5.copyWith(
                        fontSize: isSelected
                            ? getResponsiveFont(15)
                            : getResponsiveFont(14),
                        fontWeight:
                            isSelected ? FontWeight.w600 : FontWeight.w400,
                        color: isSelected ? Colors.grey[700] : Colors.grey[600],
                      )),
              price == "Rs. null" || price == "null"
                  ? Shimmer.fromColors(
                      baseColor: Color(0xffeeeff3),
                      highlightColor: Colors.white,
                      enabled: true,
                      child: Column(
                        children: [
                          Container(
                            width: 50,
                            height: 12,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                            ),
                          ),
                        ],
                      ))
                  : isDiscounted
                      ? Text.rich(
                          TextSpan(
                            children: <TextSpan>[
                              new TextSpan(
                                  text:
                                      '${LocaleKeys.units_rs.tr} $originalPrice',
                                  style: Get.textTheme.bodyText2.copyWith(
                                    decoration: TextDecoration.lineThrough,
                                    fontSize: isSelected
                                        ? getResponsiveFont(14)
                                        : getResponsiveFont(12),
                                    fontWeight: isSelected
                                        ? FontWeight.w600
                                        : FontWeight.w400,
                                    color: isSelected
                                        ? Colors.grey[700]
                                        : Colors.grey[600],
                                  )),
                              new TextSpan(
                                  text: '\n $price',
                                  style: Get.textTheme.bodyText2.copyWith(
                                    fontSize: isSelected
                                        ? getResponsiveFont(14)
                                        : getResponsiveFont(12),
                                    fontWeight: isSelected
                                        ? FontWeight.w600
                                        : FontWeight.w400,
                                    color: isSelected
                                        ? Colors.grey[700]
                                        : Colors.grey[600],
                                  )),
                            ],
                          ),
                        )
                      : Text('${LocaleKeys.units_rs.tr} $price',
                          style: Get.textTheme.bodyText2.copyWith(
                            fontSize: isSelected
                                ? getResponsiveFont(14)
                                : getResponsiveFont(12),
                            fontWeight:
                                isSelected ? FontWeight.w600 : FontWeight.w400,
                            color: isSelected
                                ? Colors.grey[700]
                                : Colors.grey[600],
                          )),
            ],
          ),
        ),
      ),
    );
  }
}

class ExtraVehicleCard extends StatelessWidget {
  final String imageUrl;
  final String vehicleType;
  final String price;
  final Function onTap;
  final Color textColor;
  final bool banner;
  final bool isSelected;

  ExtraVehicleCard(
      {this.imageUrl,
      this.textColor = const Color.fromRGBO(225, 89, 89, 1),
      this.vehicleType,
      this.price,
      this.banner = false,
      this.isSelected,
      this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: banner
          ? ClipRect(
              child: ban.BannerApp(
                layoutDirection: TextDirection.ltr,
                color: Get.theme.primaryColor,
                message: "Emergency",
                textStyle: Get.textTheme.headline5.copyWith(
                    color: Colors.white,
                    fontSize: getResponsiveFont(12),
                    fontWeight: FontWeight.w600),
                location: ban.BannerLocation.topEnd,
                child: Container(
                  decoration: isSelected
                      ? BoxDecoration(color: Colors.white, boxShadow: [
                          BoxShadow(
                              color: Colors.black.withOpacity(0.2),
                              blurRadius: 8,
                              spreadRadius: 1),
                        ])
                      : BoxDecoration(),
                  padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    children: [
                      Expanded(child: SizedBox()),
                      Image.asset(
                        imageUrl,
                        height: 120,
                        width: 120,
                        fit: BoxFit.fill,
                      ),
                      Expanded(child: SizedBox(width: 16)),
                      Column(
                        children: [
                          Text(vehicleType,
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: Get.textTheme.headline5.copyWith(
                                fontSize: isSelected
                                    ? getResponsiveFont(22)
                                    : getResponsiveFont(14),
                                fontWeight: isSelected
                                    ? FontWeight.w600
                                    : FontWeight.w400,
                                color: isSelected
                                    ? Colors.grey[700]
                                    : Colors.grey[600],
                              )),
                          SizedBox(height: 8),
                          Text(price,
                              style: Get.textTheme.bodyText2.copyWith(
                                fontSize: isSelected
                                    ? getResponsiveFont(20)
                                    : getResponsiveFont(12),
                                fontWeight: isSelected
                                    ? FontWeight.w600
                                    : FontWeight.w400,
                                color: isSelected
                                    ? Colors.grey[700]
                                    : Colors.grey[600],
                              )),
                        ],
                      ),
                      Expanded(child: SizedBox(width: 16)),
                    ],
                  ),
                ),
              ),
            )
          : Container(
              decoration: isSelected
                  ? BoxDecoration(color: Colors.white, boxShadow: [
                      BoxShadow(
                          color: Colors.black.withOpacity(0.2),
                          blurRadius: 8,
                          spreadRadius: 1),
                    ])
                  : BoxDecoration(),
              padding: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
              child: Row(
                children: [
                  Expanded(child: SizedBox()),
                  Image.asset(
                    imageUrl,
                    height: 120,
                    width: 120,
                    fit: BoxFit.fill,
                  ),
                  Expanded(child: SizedBox(width: 16)),
                  Column(
                    children: [
                      Text(vehicleType,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: Get.textTheme.headline5.copyWith(
                            fontSize: isSelected
                                ? getResponsiveFont(22)
                                : getResponsiveFont(14),
                            fontWeight:
                                isSelected ? FontWeight.w600 : FontWeight.w400,
                            color: isSelected
                                ? Colors.grey[700]
                                : Colors.grey[600],
                          )),
                      SizedBox(height: 8),
                      Text(price,
                          style: Get.textTheme.bodyText2.copyWith(
                            fontSize: isSelected
                                ? getResponsiveFont(20)
                                : getResponsiveFont(12),
                            fontWeight:
                                isSelected ? FontWeight.w600 : FontWeight.w400,
                            color: isSelected
                                ? Colors.grey[700]
                                : Colors.grey[600],
                          )),
                    ],
                  ),
                  Expanded(child: SizedBox(width: 16)),
                ],
              ),
            ),
    );
  }
}

buildShowGeneralDialog(BuildContext context) async {
  showGeneralDialog(
      barrierColor: Colors.black.withOpacity(0.5),
      transitionBuilder: (context, a1, a2, widget) {
        final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
        return Transform(
          transform: Matrix4.translationValues(
              curvedValue * 1, -curvedValue * 100, 0.0),
          child: Opacity(
            opacity: a1.value,
            child: Stack(
              children: [
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                      // height: Get.height * 0.3,
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(color: Colors.white),
                      child: SingleChildScrollView(
                        physics: NeverScrollableScrollPhysics(),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Center(
                              child: SvgPicture.asset(
                                'svg_assets/insurance.svg',
                                height: Get.height * 0.22,
                                width: Get.width * 0.2,
                                fit: BoxFit.contain,
                              ),
                            ),
                            SizedBox(height: getResponsiveFont(4)),
                            Text(
                              'Welfare Fund',
                              style: Get.textTheme.bodyText2.copyWith(
                                color: Colors.grey[800],
                                fontWeight: FontWeight.w500,
                                fontSize: getResponsiveFont(20),
                              ),
                            ),
                            // SizedBox(height: getResponsiveFont(4)),
                            // RichText(
                            //     text: TextSpan(
                            //         text: 'Get coverage with only ',
                            //         style: Get.textTheme.headline6.copyWith(
                            //             color: Colors.grey[800],
                            //             fontFamily: 'Poppins',
                            //             fontWeight: FontWeight.w400,
                            //             fontSize: getResponsiveFont(16)),
                            //         children: [
                            //       TextSpan(
                            //           text: 'Rs. 0/ride',
                            //           style: TextStyle(
                            //               color: Colors.grey[800],
                            //               fontWeight: FontWeight.w600,
                            //               fontSize: getResponsiveFont(16))),
                            //     ])),
                            SizedBox(height: getResponsiveFont(4)),
                            RichText(
                                text: TextSpan(
                                    text: 'Accidental death coverage up to ',
                                    style: Get.textTheme.headline6.copyWith(
                                        color: Colors.grey[600],
                                        fontWeight: FontWeight.w500,
                                        fontSize: getResponsiveFont(14)),
                                    children: [
                                  TextSpan(
                                      text: 'NPR 1,00,000',
                                      style: TextStyle(
                                          color: Colors.grey[800],
                                          fontWeight: FontWeight.w600,
                                          fontSize: getResponsiveFont(14))),
                                ])),
                            SizedBox(height: getResponsiveFont(2)),
                            RichText(
                                text: TextSpan(
                                    text: 'Hospitalization coverage up to ',
                                    style: Get.textTheme.headline6.copyWith(
                                        color: Colors.grey[600],
                                        fontWeight: FontWeight.w500,
                                        fontSize: getResponsiveFont(14)),
                                    children: [
                                  TextSpan(
                                      text: 'NPR 25,000',
                                      style: TextStyle(
                                          color: Colors.grey[800],
                                          fontWeight: FontWeight.w600,
                                          fontSize: getResponsiveFont(14))),
                                ])),
                            // SizedBox(height: getResponsiveFont(8)),
                            // Text(
                            //   'Learn More',
                            //   style: Get.textTheme.bodyText2.copyWith(
                            //     color: Get.theme.primaryColor,
                            //     fontWeight: FontWeight.w500,
                            //     fontSize: getResponsiveFont(14),
                            //   ),
                            // ),
                            SizedBox(height: getResponsiveFont(8)),
                            Container(
                              height: Get.height * 0.06,
                              width: Get.width,
                              decoration: BoxDecoration(color: Colors.white),
                              child: CustomButton(
                                text: 'GOT IT'.tr,
                                backgroundColor: Get.theme.primaryColor,
                                onPressed: () async {
                                  Navigator.pop(context);
                                },
                              ),
                            ),
                          ],
                        ),
                      )),
                ),
              ],
            ),
          ),
        );
      },
      transitionDuration: Duration(milliseconds: 330),
      barrierDismissible: true,
      barrierLabel: '',
      context: context,
      pageBuilder: (context, animation1, animation2) {});
}

buildMoreVehicleDetails(
  BuildContext context,
  RideType type,
) async {
  BookingController controller = Get.find();
  showGeneralDialog(
      barrierColor: Colors.black.withOpacity(0.5),
      transitionBuilder: (context, a1, a2, widget) {
        final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
        return Transform(
          transform: Matrix4.translationValues(
              curvedValue * 1, -curvedValue * 100, 0.0),
          child: Opacity(
            opacity: a1.value,
            child: Stack(
              children: [
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                      // height: Get.height * 0.3,
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(color: Colors.white),
                      child: SingleChildScrollView(
                        physics: NeverScrollableScrollPhysics(),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Center(
                              child: Image.asset(
                                type == RideType.BIKE
                                    ? 'assets/bike.png'
                                    : type == RideType.CAR
                                        ? 'assets/car.png'
                                        : 'assets/city_safari.png',
                                height: Get.height * 0.12,
                                fit: BoxFit.contain,
                              ),
                            ),
                            SizedBox(height: getResponsiveFont(4)),
                            Text(
                              type == RideType.BIKE
                                  ? 'Bike'
                                  : type == RideType.CAR
                                      ? 'Car'
                                      : 'City Safari',
                              style: Get.textTheme.bodyText2.copyWith(
                                color: Colors.grey[800],
                                fontWeight: FontWeight.w500,
                                fontSize: getResponsiveFont(20),
                              ),
                            ),
                            SizedBox(height: getResponsiveFont(4)),
                            Text(
                              type == RideType.BIKE
                                  ? 'Quickest way of individual commute and our most affordable option. Wear a mask, stay safe.'
                                  : type == RideType.CAR
                                      ? 'Our economical cars can host up to 4 people and is perfect for your daily commute.'
                                      : 'Our safari can host up to 6 people and is perfect for your family commute.',
                              style: Get.textTheme.bodyText2.copyWith(
                                color: Colors.grey[500],
                                fontWeight: FontWeight.w500,
                                fontSize: getResponsiveFont(12),
                              ),
                              textAlign: TextAlign.justify,
                            ),
                            SizedBox(height: getResponsiveFont(4)),
                            Row(children: [
                              Text(
                                'Base fare',
                                style: Get.textTheme.bodyText2.copyWith(
                                  color: Colors.grey[800],
                                  fontWeight: FontWeight.w500,
                                  fontSize: getResponsiveFont(14),
                                ),
                              ),
                              Expanded(child: SizedBox()),
                              Text(
                                type == RideType.BIKE
                                    ? controller
                                        .bikePricesBreakdown.value.baseFare
                                        .toString()
                                    : type == RideType.CAR
                                        ? controller
                                            .carPricesBreakdown.value.baseFare
                                            .toString()
                                        : controller.safariPricesBreakdown.value
                                            .baseFare
                                            .toString(),
                                style: Get.textTheme.bodyText2.copyWith(
                                  color: Colors.grey[800],
                                  fontWeight: FontWeight.w500,
                                  fontSize: getResponsiveFont(14),
                                ),
                              ),
                            ]),
                            SizedBox(height: getResponsiveFont(4)),
                            Row(children: [
                              Text(
                                'Per Kilometer',
                                style: Get.textTheme.bodyText2.copyWith(
                                  color: Colors.grey[800],
                                  fontWeight: FontWeight.w500,
                                  fontSize: getResponsiveFont(14),
                                ),
                              ),
                              Expanded(child: SizedBox()),
                              Text(
                                type == RideType.BIKE
                                    ? controller
                                        .bikePricesBreakdown.value.pricePerKm
                                        .toString()
                                    : type == RideType.CAR
                                        ? controller
                                            .carPricesBreakdown.value.pricePerKm
                                            .toString()
                                        : controller.safariPricesBreakdown.value
                                            .pricePerKm
                                            .toString(),
                                style: Get.textTheme.bodyText2.copyWith(
                                  color: Colors.grey[800],
                                  fontWeight: FontWeight.w500,
                                  fontSize: getResponsiveFont(14),
                                ),
                              ),
                            ]),
                            SizedBox(height: getResponsiveFont(4)),
                            Row(children: [
                              Text(
                                'Per Minute',
                                style: Get.textTheme.bodyText2.copyWith(
                                  color: Colors.grey[800],
                                  fontWeight: FontWeight.w500,
                                  fontSize: getResponsiveFont(14),
                                ),
                              ),
                              Expanded(child: SizedBox()),
                              Text(
                                type == RideType.BIKE
                                    ? controller
                                        .bikePricesBreakdown.value.pricePerMin
                                        .toString()
                                    : type == RideType.CAR
                                        ? controller.carPricesBreakdown.value
                                            .pricePerMin
                                            .toString()
                                        : controller.safariPricesBreakdown.value
                                            .pricePerMin
                                            .toString(),
                                style: Get.textTheme.bodyText2.copyWith(
                                  color: Colors.grey[800],
                                  fontWeight: FontWeight.w500,
                                  fontSize: getResponsiveFont(14),
                                ),
                              ),
                            ]),
                            SizedBox(height: getResponsiveFont(4)),
                            Row(children: [
                              Text(
                                'Minimum fare',
                                style: Get.textTheme.bodyText2.copyWith(
                                  color: Colors.grey[800],
                                  fontWeight: FontWeight.w500,
                                  fontSize: getResponsiveFont(14),
                                ),
                              ),
                              Expanded(child: SizedBox()),
                              Text(
                                type == RideType.BIKE
                                    ? controller
                                        .bikePricesBreakdown.value.minimumCharge
                                        .toString()
                                    : type == RideType.CAR
                                        ? controller.carPricesBreakdown.value
                                            .minimumCharge
                                            .toString()
                                        : controller.safariPricesBreakdown.value
                                            .minimumCharge
                                            .toString(),
                                style: Get.textTheme.bodyText2.copyWith(
                                  color: Colors.grey[800],
                                  fontWeight: FontWeight.w500,
                                  fontSize: getResponsiveFont(14),
                                ),
                              ),
                            ]),
                            SizedBox(height: getResponsiveFont(4)),
                            Text(
                              'Your fare will be the price presented before the trip or based on rates above and other applicable surcharges and adjustments.',
                              style: Get.textTheme.bodyText2.copyWith(
                                color: Colors.grey[500],
                                fontWeight: FontWeight.w500,
                                fontSize: getResponsiveFont(12),
                              ),
                              textAlign: TextAlign.justify,
                            ),
                            SizedBox(height: getResponsiveFont(8)),
                            Container(
                              height: Get.height * 0.06,
                              width: Get.width,
                              decoration: BoxDecoration(color: Colors.white),
                              child: CustomButton(
                                text: 'I UNDERSTAND'.tr,
                                backgroundColor: Get.theme.primaryColor,
                                onPressed: () async {
                                  Navigator.pop(context);
                                },
                              ),
                            ),
                          ],
                        ),
                      )),
                ),
              ],
            ),
          ),
        );
      },
      transitionDuration: Duration(milliseconds: 330),
      barrierDismissible: true,
      barrierLabel: '',
      context: context,
      pageBuilder: (context, animation1, animation2) {});
}

class AddPromoButtonRideType extends StatelessWidget {
  final TextEditingController reasonController;
  final FocusNode pickUpNode = FocusNode();

  final Function onPressed;

  AddPromoButtonRideType({this.onPressed, this.reasonController});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(),
        Padding(
          padding: const EdgeInsets.only(right: 16, bottom: 16),
          child: CircleAvatar(
            backgroundColor: Colors.white,
            child: IconButton(
                icon: Icon(Icons.card_giftcard, color: Colors.green),
                onPressed: () async => buildPromoAdderRideType(
                    context, reasonController, pickUpNode)),
          ),
        ),
      ],
    );
  }
}

buildPromoAdderRideType(BuildContext context,
    TextEditingController promoController, FocusNode focusNode) async {
  final AllDataController dataController = Get.put(AllDataController());
  final BookingController controller = Get.find();
  //final node = FocusScope.of(context);
  showGeneralDialog(
      barrierColor: Colors.black.withOpacity(0.5),
      transitionBuilder: (context, a1, a2, widget) {
        final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
        return Transform(
          transform: Matrix4.translationValues(
              curvedValue * 1, -curvedValue * 100, 0.0),
          child: Opacity(
            opacity: a1.value,
            child: Stack(
              children: [
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Padding(
                    padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom),
                    child: Card(
                      child: Container(
                          // height: Get.height * 0.3,
                          padding: EdgeInsets.all(16),
                          decoration: BoxDecoration(color: Colors.white),
                          child: SingleChildScrollView(
                            physics: NeverScrollableScrollPhysics(),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                SizedBox(height: getResponsiveFont(4)),
                                Text(
                                  'Add Promo code:',
                                  style: Get.textTheme.bodyText2.copyWith(
                                    color: Colors.grey[800],
                                    fontWeight: FontWeight.w500,
                                    fontSize: getResponsiveFont(20),
                                  ),
                                ),
                                Center(
                                  child: SvgPicture.asset(
                                    'svg_assets/promo.svg',
                                    height: Get.height * 0.15,
                                    width: Get.width * 0.2,
                                    fit: BoxFit.contain,
                                  ),
                                ),
                                Container(
                                  // height: Get.height * 0.06,
                                  child: TextField(
                                    controller: dataController.promoController,
                                    textAlign: TextAlign.left,
                                    // autofocus: true,
                                    style: Get.textTheme.headline5.copyWith(
                                        fontFamily: 'Roboto',
                                        fontSize: getResponsiveFont(18),
                                        color: Colors.grey[800]),
                                    maxLines: 1,
                                    decoration: InputDecoration(
                                      contentPadding: EdgeInsets.fromLTRB(
                                          10.0, 10.0, 20.0, 10.0),
                                      hintStyle: Get.textTheme.headline5
                                          .copyWith(
                                              fontSize: getResponsiveFont(18),
                                              fontFamily: 'Roboto',
                                              color: Colors.grey[600]),
                                      hintText: 'Enter promo code'.tr,
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(
                                            width: 1, color: Colors.grey[600]),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(
                                            width: 1, color: Colors.grey[600]),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(
                                            width: 1, color: Colors.grey[600]),
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(height: getResponsiveFont(8)),
                                Row(
                                  children: [
                                    Expanded(
                                      child: Container(
                                        height: Get.height * 0.06,
                                        decoration:
                                            BoxDecoration(color: Colors.white),
                                        child: CustomButton(
                                          radius: 7,
                                          textColor: Colors.grey[800],
                                          text: 'Cancel'.tr,
                                          backgroundColor: Colors.blueGrey[50],
                                          onPressed: () async {
                                            Navigator.pop(context);
                                          },
                                        ),
                                      ),
                                    ),
                                    SizedBox(width: 16),
                                    Expanded(
                                      child: Container(
                                        height: Get.height * 0.06,
                                        decoration:
                                            BoxDecoration(color: Colors.white),
                                        child: CustomButton(
                                          radius: 7,
                                          text: 'Apply'.tr,
                                          backgroundColor:
                                              Get.theme.primaryColor,
                                          onPressed: () async {
                                            Loader.show(context);
                                            final status = await dataController
                                                .checkPromoCode(dataController
                                                    .promoController.text);
                                            print('Status is $status ');
                                            if (status) {
                                              SessionManager.instance
                                                  .setVoucherCode(dataController
                                                      .promoController.text);
                                              await controller
                                                  .getEstimatedPrice();
                                              dataController
                                                  .promoController.text = '';
                                              Navigator.pop(context);
                                              Loader.hide();
                                              CustomSnackbar.showCustomSnackBar(
                                                  message:
                                                      'Promo code successfully added.');
                                            } else {
                                              PromoCodeInvalid.show(context);
                                              Loader.hide();
                                              CustomSnackbar.showCustomSnackBar(
                                                message:
                                                    'Promo code is invalid.',
                                              );
                                              Future.delayed(Duration(
                                                      milliseconds: 1500))
                                                  .then((_) =>
                                                      PromoCodeInvalid.hide());
                                            }
                                          },
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          )),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
      transitionDuration: Duration(milliseconds: 330),
      barrierDismissible: true,
      barrierLabel: '',
      context: context,
      pageBuilder: (context, animation1, animation2) {});
}
