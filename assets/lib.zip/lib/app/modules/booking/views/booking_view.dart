import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:puryaideu/app/enums/map_events.dart';
import 'package:puryaideu/app/enums/ride_type.dart';
import 'package:puryaideu/app/modules/booking/views/search_by_pin.dart';

import '../controllers/booking_controller.dart';
import 'main_drawer.dart';
import 'manual_search.dart';
import 'map_container.dart';
import 'nav_settings.dart';

class BookingView extends GetView<BookingController> {
  final _scaffoldKey = GlobalKey<ScaffoldState>();

  Future<bool> onWillPop() async {
    final status = controller.handleBackButtonRebooked();
    if(status == "true"){
      return false;
    }else if(status == "rebooked"){
      Get.back();
      return true;
    }
    return false;
  }


  initBooking() {
    final type = Get.arguments;
    if(type.length == 1) {
      print('type is=== $type');
      controller.setSelectedRideType(type[0]);
    }else{
      controller.mapEvents.value = MapEvents.REBOOKED;
      controller.rebookedList.value = type;
      controller.setSelectedRideType(type[0]);
    }

  }

  @override
  Widget build(BuildContext context) {
    initBooking();
    return WillPopScope(
      onWillPop: onWillPop,
      child: Scaffold(
        // key: _scaffoldKey,
        // endDrawer: MainDrawer(),
        body: SafeArea(
          child: Stack(
            children: [
              MapContainer(),
              // Positioned(
              //   right: 0,
              //   top: 16,
              //   child: NavSettings(
              //     onTap: () {
              //       _scaffoldKey.currentState.openEndDrawer();
              //     },
              //   ),
              // ),
              Obx(() =>
                  controller.searchByPin ? SearchByPin() : ManualSearch()),
              Positioned(
                top: 16,
                left: 16,
                child: InkWell(
                  onTap: () {
                    final status = controller.handleBackButtonRebooked();
                    if(status == "true")
                      Get.back();
                    if(status == "rebooked")
                      {
                        Get.back();
                        Get.back();
                      }
                  },
                  child: Container(
                    padding: EdgeInsets.all(12),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(30),
                      color: Colors.white,
                    ),
                    child: Icon(Icons.arrow_back),
                  ),
                ),
              ),
              // CustomProgressBar(),
            ],
          ),
        ),
      ),
    );
  }
}
