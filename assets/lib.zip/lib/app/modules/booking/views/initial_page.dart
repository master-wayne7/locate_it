import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/enums/location_type.dart';
import 'package:puryaideu/app/enums/ride_type.dart';
import 'package:puryaideu/app/modules/booking/controllers/booking_controller.dart';
import 'package:puryaideu/app/widgets/add_promo_button.dart';
import 'package:puryaideu/app/widgets/current_location_button.dart';

import 'initial_dialog_card.dart';
import 'user_location_input_screen.dart';

class InitialMapPage extends GetView<BookingController> {

  final FocusNode pickUpNode = FocusNode();

  @override
  Widget build(BuildContext context) {
    return Positioned(
      bottom: 0,
      left: 0,
      right: 0,
      child: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onVerticalDragUpdate: (details) {
          int sensitivity = 8;
          if (details.delta.dy > sensitivity) {
            // Down Swipe
          } else if (details.delta.dy < -sensitivity) {
            // Up Swipe
            Get.to(UserLocationInputScreen(),
                transition: Transition.downToUp,
                duration: Duration(milliseconds: 500),
                curve: Curves.decelerate);
          }
        },
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(),
                controller.selectedRideType != RideType.AMBULANCE
                    ? Column(
                  children: [
                    InsuranceButton(
                      onPressed: () => controller.moveToCurrentLocation(),
                    ),
                    AddPromoButton(
                      //onPressed: () => controller.moveToCurrentLocation(),
                      reasonController: controller.promoController,
                      //pickUpNode: pickUpNode,
                    ),
                    CurrentLocationButton(
                      onPressed: () => controller.moveToCurrentLocation(),
                    ),
                  ],
                ) : Container(),
              ],
            ),
            InitialDialogCard(
              onTap: () {
                if(controller.selectedRideType == RideType.AMBULANCE){
                  controller.searchByPinTask(LocationType.PICKUP);
                }else
                Get.to(UserLocationInputScreen(),
                    transition: Transition.downToUp,
                    duration: Duration(milliseconds: 500),
                    curve: Curves.decelerate);
              },
            ),
          ],
        ),
      ),
    );
  }
}
