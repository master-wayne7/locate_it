import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/enums/location_type.dart';
import 'package:puryaideu/app/enums/ride_type.dart';
import 'package:puryaideu/app/modules/booking/controllers/booking_controller.dart';
import 'package:puryaideu/app/modules/booking/views/user_location_input_screen.dart';
import 'package:puryaideu/app/widgets/current_location_button.dart';
import 'package:puryaideu/app/widgets/custom_button.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:puryaideu/app/widgets/location_text.dart';
import 'package:puryaideu/generated/locales.g.dart';
import 'package:shimmer/shimmer.dart';

class SearchByPin extends GetView<BookingController> {
  @override
  Widget build(BuildContext context) {
    return Obx(
      () => Stack(
        children: [
          // Positioned(
          //   top: Get.height * 0.1,
          //   left: 16,
          //   right: 16,
          //   child: LocationText(
          //     text: controller.locationName,
          //   ),
          // ),
          Center(
            child: Container(
              padding: EdgeInsets.only(
                bottom: 30,
              ),
              child: Image.asset(
                'assets/pin.png',
                height: 40,
                width: 40,
              ),
            ),
          ),
          Positioned(
            bottom: 0,
            child: Container(
              width: Get.width,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  CurrentLocationButton(
                    onPressed: () {
                      controller.moveToCurrentLocation();
                    },
                  ),
                  Card(
                    margin: EdgeInsets.zero,
                    shape: RoundedRectangleBorder(),
                    child: Container(
                      padding: EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            controller.locationType.value == LocationType.PICKUP
                                ? LocaleKeys.buttons_confirm_pickup.tr
                                : (controller.locationType.value ==
                                        LocationType.DESTINATION
                                    ? LocaleKeys.buttons_confirm_destination.tr
                                    : controller.locationType.value ==
                                                LocationType.HOME &&
                                            controller.editSavedAddress.value
                                        ? LocaleKeys.buttons_set_home.tr
                                        : controller.locationType.value ==
                                                    LocationType.WORK &&
                                                controller
                                                    .editSavedAddress.value
                                            ? LocaleKeys.buttons_set_work.tr
                                            : controller.locationType.value ==
                                                    LocationType.WORK
                                                ? LocaleKeys
                                                    .buttons_confirm_destination
                                                    .tr
                                                : LocaleKeys
                                                    .buttons_confirm_destination
                                                    .tr),
                            style: Get.textTheme.headline6.copyWith(
                                color: Get.theme.primaryColor,
                                fontSize: getResponsiveFont(20),
                                fontWeight: FontWeight.w600),
                          ),
                          SizedBox(height: 16),
                          Container(
                            color: Get.theme.primaryColor.withOpacity(0.15),
                            padding: EdgeInsets.symmetric(
                                horizontal: 16, vertical: 8),
                            child: Row(
                              children: [
                                Icon(Icons.location_pin,
                                    color: Get.theme.primaryColor),
                                SizedBox(width: 16),
                                Expanded(
                                  child: Text(
                                    controller.locationName,
                                    maxLines: 1,
                                    style: Get.textTheme.bodyText2.copyWith(
                                        color: Colors.grey[800],
                                        fontSize: getResponsiveFont(15),
                                        fontWeight: FontWeight.w500),
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          SizedBox(height: 16),
                          Obx(() => controller.searchByPinButton.value
                              ? CustomButton(
                                  backgroundColor: Get.theme.primaryColor,
                                  onPressed: () async {
                                    controller.searchByPinButton.value = false;
                                    if (controller.selectedRideType ==
                                        RideType.AMBULANCE) {
                                      controller.setPickupLocation();
                                      controller.addDestinationLocation();
                                    }
                                    print(
                                        'LocationType: ${controller.locationType.value}');
                                    if (controller.locationType.value ==
                                        LocationType.PICKUP) {
                                      controller.setPickupLocation();
                                      if (controller.destinationLocation ==
                                          null) {
                                        Get.to(UserLocationInputScreen());
                                      }
                                    } else if (controller.locationType.value ==
                                        LocationType.HOME) {
                                      if (controller.editSavedAddress.value) {
                                        await controller.setHomeLocation();
                                        final status = await controller
                                            .saveHomeAndWorkLocaton();
                                        if (!status) {
                                          CustomSnackbar.showCustomSnackBar(
                                              message:
                                                  '${controller.errorMessage}');

                                          Get.to(UserLocationInputScreen());
                                        } else {
                                          controller.addDestinationLocation();
                                        }
                                      } else {
                                        controller.addDestinationLocation();
                                      }
                                    } else if (controller.locationType.value ==
                                        LocationType.WORK) {
                                      if (controller.editSavedAddress.value) {
                                        await controller.setWorkLocation();
                                        final status = await controller
                                            .saveHomeAndWorkLocaton();
                                        if (!status) {
                                          CustomSnackbar.showCustomSnackBar(
                                              message:
                                                  '${controller.errorMessage}');
                                        }
                                        Get.to(UserLocationInputScreen());
                                      } else {
                                        controller.addDestinationLocation();
                                      }
                                    } else {
                                      controller.addDestinationLocation();
                                    }
                                    Future.delayed(Duration(seconds: 3))
                                        .then((value) async {
                                      controller.searchByPinButton.value = true;
                                    });
                                  },
                                  text: controller.locationType.value ==
                                          LocationType.PICKUP
                                      ? LocaleKeys.buttons_set_pickup.tr
                                      : (controller.locationType.value ==
                                              LocationType.DESTINATION
                                          ? LocaleKeys
                                              .buttons_set_destination.tr
                                          : controller.locationType.value ==
                                                      LocationType.HOME &&
                                                  controller
                                                      .editSavedAddress.value
                                              ? LocaleKeys.buttons_set_home.tr
                                              : controller.locationType.value ==
                                                          LocationType.WORK &&
                                                      controller
                                                          .editSavedAddress
                                                          .value
                                                  ? LocaleKeys
                                                      .buttons_set_work.tr
                                                  : controller.locationType
                                                              .value ==
                                                          LocationType.WORK
                                                      ? LocaleKeys
                                                          .buttons_set_destination
                                                          .tr
                                                      : LocaleKeys
                                                          .buttons_set_destination
                                                          .tr))
                              : Shimmer.fromColors(
                                  baseColor: Colors.white,
                                  highlightColor:
                                      Get.theme.primaryColor.withOpacity(0.4),
                                  enabled: true,
                                  child: CustomButton(
                                      backgroundColor:
                                          controller.requestRideButton.value
                                              ? Get.theme.primaryColor
                                              : Colors.grey,
                                      onPressed: () {},
                                      text: LocaleKeys.buttons_request_ride.tr),
                                )),
                        ],
                      ),
                    ),
                  ),
                  // Padding(
                  //   padding: EdgeInsets.only(right: 16, left: 16, bottom: 16),
                  //   child: CustomButton(
                  //     backgroundColor: Get.theme.accentColor,
                  //     onPressed: () async {
                  //       if (controller.locationType.value ==
                  //           LocationType.PICKUP) {
                  //         controller.setPickupLocation();
                  //         if (controller.destinationLocation == null) {
                  //           Get.to(UserLocationInputScreen());
                  //         }
                  //       } else if (controller.locationType.value ==
                  //           LocationType.HOME) {
                  //         // final status =
                  //         // await controller.saveHomeAndWorkLocaton();
                  //         // if (!status) {
                  //         //   CustomSnackbar.showCustomSnackBar(
                  //         //       message: '${controller.errorMessage}');
                  //         // }
                  //         Get.to(UserLocationInputScreen());
                  //       } else if (controller.locationType.value ==
                  //           LocationType.WORK) {
                  //         // final status =
                  //         // await controller.saveHomeAndWorkLocaton();
                  //         // if (!status) {
                  //         //   CustomSnackbar.showCustomSnackBar(
                  //         //       message: '${controller.errorMessage}');
                  //         // }
                  //         Get.to(UserLocationInputScreen());
                  //       } else {
                  //         controller.addDestinationLocation();
                  //       }
                  //     },
                  //     text: controller.locationType.value == LocationType.PICKUP
                  //         ? LocaleKeys.buttons_set_pickup.tr
                  //         : (controller.locationType.value ==
                  //                 LocationType.DESTINATION
                  //             ? LocaleKeys.buttons_set_destination.tr
                  //             : controller.locationType.value ==
                  //                     LocationType.HOME
                  //                 ? LocaleKeys.buttons_set_home.tr
                  //                 : LocaleKeys.buttons_set_work.tr),
                  //   ),
                  // ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
