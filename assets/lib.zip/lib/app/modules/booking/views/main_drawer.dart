import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/generated/locales.g.dart';

class MainDrawer extends StatelessWidget {

  final SessionManager _sessionManager = SessionManager.instance;

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Container(
        color: Colors.white,
        child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: <Widget>[
              SizedBox(height: MediaQuery.of(context).padding.top),
              SizedBox(height: 16),
              Center(
                child: ClipRRect(
                    borderRadius: BorderRadius.circular(50),
                    child: CachedNetworkImage(imageUrl: '$BASE_URL/${_sessionManager.user.imagePath}', height: 100, width: 100, fit: BoxFit.cover,)
                ),
              ),
              SizedBox(height: 16),
              Text(
                _sessionManager.user.name,
                style: Get.textTheme.headline6
                    .copyWith(color: Get.theme.accentColor),
              ),
              Text(
                '${LocaleKeys.text_balance.tr}: ${LocaleKeys.units_rs.tr} 100',
                style: Get.textTheme.headline5
                    .copyWith(color: Get.theme.primaryColor),
              ),
              SizedBox(height: 16),
              Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.account_balance_wallet),
                  SizedBox(width: 8),
                  Text(
                    LocaleKeys.text_top_up_balance.tr,
                    style: Get.textTheme.headline5,
                  ),
                ],
              ),
              Expanded(child: Container()),
              Container(
                padding: EdgeInsets.all(16),
                child: Row(
                  children: [
                    Expanded(
                      child: InkWell(
                        onTap: () {},
                        child: Icon(Icons.account_balance_wallet),
                      ),
                    ),
                    Expanded(
                      child: InkWell(
                        child: Container(child: Icon(Icons.history)),
                        onTap: (){
                          // Get.to(HistoryFullScreen());
                        },
                      ),
                    ),
                    Expanded(
                      child: InkWell(child: Icon(Icons.card_giftcard), onTap: (){
                        // Get.to(PromotionScreen());
                      },),
                    ),
                  ],
                ),
              ),
            ]),
      ),
    );
  }
}
