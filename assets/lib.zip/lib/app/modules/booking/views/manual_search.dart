import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/enums/map_events.dart';
import 'package:puryaideu/app/modules/booking/controllers/booking_controller.dart';
import 'package:puryaideu/app/modules/booking/views/initial_page.dart';
import 'package:puryaideu/app/modules/booking/views/ride_type_dialog.dart';

class ManualSearch extends GetView<BookingController> {

  @override
  // ignore: missing_return
  Widget build(BuildContext context) {
    return Obx(
        () {
          switch (controller.mapEvents.value) {
            case MapEvents.NONE:
              break;

            case MapEvents.DESTINATION_SELECTED:
            case MapEvents.REBOOKED:
              return RideTypeDialog();
          }
          return InitialMapPage();
        }
    );
  }
}
