// class BookingRequestModel {
//   BookingRequestModel({
//     this.longitudeOrigin,
//     this.latitudeOrigin,
//     this.longitudeDestination,
//     this.latitudeDestination,
//     this.price,
//     this.origin,
//     this.destination,
//     this.distance,
//     this.duration,
//     this.vehicleType,
//   });
//
//   double longitudeOrigin;
//   double latitudeOrigin;
//   double longitudeDestination;
//   double latitudeDestination;
//   double price;
//   String origin;
//   String destination;
//   int distance;
//   int duration;
//   int vehicleType;
//
//   Map<String, dynamic> toJson() => {
//     "origin": origin,
//     "destination": destination,
//     "passenger_number": 1,
//     "vehicle_type_id": vehicleType,
//     "distance": distance,
//     "duration": duration,
//     "price": price,
//     "location": {
//       "latitude_origin": latitudeOrigin,
//       "longitude_origin": longitudeOrigin,
//       "latitude_destination": latitudeDestination,
//       "longitude_destination": longitudeDestination,
//     }
//   };
//
// }

class BookingRequestModel {
  BookingRequestModel({
    this.longitudeOrigin,
    this.latitudeOrigin,
    this.longitudeDestination,
    this.latitudeDestination,
    this.price,
    this.origin,
    this.destination,
    this.distance,
    this.duration,
    this.vehicleType,
    this.voucherId,
  });

  double longitudeOrigin;
  double latitudeOrigin;
  double longitudeDestination;
  double latitudeDestination;
  double price;
  String origin;
  String destination;
  int distance;
  int duration;
  int vehicleType;
  int voucherId;

  Map<String, dynamic> toJson() => {
    "passenger_number": 1,
    "vehicle_type_id": vehicleType,
    "distance": distance,
    "duration": duration,
    "price": price,
    "location":
    {
      "origin":{
        "name": origin,
        "latitude": latitudeOrigin,
        "longitude": longitudeOrigin
      },
      "destination":{
        "name": destination,
        "latitude": latitudeDestination,
        "longitude": longitudeDestination
      }
    },
    "voucher": voucherId,
  };
}
