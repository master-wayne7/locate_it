class RegisterRequestModel {
  String firstName;
  String lastName;
  String email;
  String phone;
  String gender;
  DateTime dob;
  String googleId;
  String facebookId;
  dynamic profilePic;
  String socialImageUrl;

  RegisterRequestModel({
    this.firstName,
    this.lastName,
    this.email,
    this.phone,
    this.gender,
    this.dob,
    this.profilePic,
    this.googleId,
    this.socialImageUrl,
    this.facebookId,
  });

  Map<String, dynamic> toJson() {
    final data = <String, dynamic>{};
    data['first_name'] = firstName;
    data['last_name'] = lastName;
    data['email'] = email;
    data['phone'] = phone;
    data['gender'] = gender;
    data['dob'] = dob;
    data['image'] = profilePic;
    data['google_id'] = googleId;
    data['facebook_id'] = facebookId;
    data['social_image_url'] = socialImageUrl;
    return data;
  }
}
