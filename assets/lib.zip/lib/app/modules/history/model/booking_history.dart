import 'package:puryaideu/app/data/models/completed_trip.dart';

class BookingHistory {
  BookingHistory({
    this.id,
    this.userId,
    this.riderId,
    this.bookingId,
    this.locationId,
    this.startTime,
    this.endTime,
    this.origin,
    this.destination,
    this.stoppage,
    this.distance,
    this.duration,
    this.passengerNumber,
    this.profileImgUser,
    this.profileImgRider,
    this.status,
    this.price,
    this.paymentType,
    this.cancelledByType,
    this.cancelledById,
    this.cancelMessage,
    this.deletedAt,
    this.createdAt,
    this.updatedAt,
    this.booking,
    this.location,
    this.priceDetail,
  });

  int id;
  int userId;
  int riderId;
  int bookingId;
  int locationId;
  DateTime startTime;
  DateTime endTime;
  String origin;
  String destination;
  dynamic stoppage;
  String distance;
  String duration;
  String passengerNumber;
  dynamic profileImgUser;
  dynamic profileImgRider;
  String status;
  int price;
  String paymentType;
  dynamic cancelledByType;
  dynamic cancelledById;
  dynamic cancelMessage;
  dynamic deletedAt;
  DateTime createdAt;
  DateTime updatedAt;
  Booking booking;
  Location location;
  PriceDetail priceDetail;

  factory BookingHistory.fromJson(Map<String, dynamic> json) => BookingHistory(
    id: json["id"],
    userId: json["user_id"],
    riderId: json["rider_id"] == null ? null : json["rider_id"],
    bookingId: json["booking_id"],
    locationId: json["location_id"],
    startTime: DateTime.parse(json["start_time"]),
    endTime: DateTime.parse(json["end_time"]),
    origin: json["origin"],
    destination: json["destination"],
    stoppage: json["stoppage"],
    distance: json["distance"] is int ? json["distance_km"].toString(): json["distance"],
    duration: json["duration"] is int ? json["duration"].toString(): json["duration"],
    passengerNumber: json["passenger_number"],
    profileImgUser: json["profile_img_user"],
    profileImgRider: json["profile_img_rider"],
    status: json["status"],
    price: json["price"],
    paymentType: json["payment_type"],
    cancelledByType: json["cancelled_by_type"],
    cancelledById: json["cancelled_by_id"],
    cancelMessage: json["cancel_message"],
    deletedAt: json["deleted_at"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
    booking: Booking.fromJson(json["booking"]),
    location: Location.fromJson(json["location"]),
    priceDetail: PriceDetail.fromJson(json["price_detail"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_id": userId,
    "rider_id": riderId == null ? null : riderId,
    "booking_id": bookingId,
    "location_id": locationId,
    "start_time": startTime.toIso8601String(),
    "end_time": endTime.toIso8601String(),
    "origin": origin,
    "destination": destination,
    "stoppage": stoppage,
    "distance": distance,
    "duration": duration,
    "passenger_number": passengerNumber,
    "profile_img_user": profileImgUser,
    "profile_img_rider": profileImgRider,
    "status": status,
    "price": price,
    "payment_type": paymentType,
    "cancelled_by_type": cancelledByType,
    "cancelled_by_id": cancelledById,
    "cancel_message": cancelMessage,
    "deleted_at": deletedAt,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
    "booking": booking.toJson(),
    "location": location.toJson(),
    "price_detail": priceDetail.toJson(),
  };
}

class Booking {
  Booking({
    this.id,
    this.tripId,
    this.stoppage,
    this.userId,
    this.vehicleTypeId,
    this.riderId,
    this.locationId,
    this.startTime,
    this.endTime,
    this.origin,
    this.destination,
    this.distance,
    this.duration,
    this.passengerNumber,
    this.status,
    this.price,
    this.paymentType,
    this.deletedAt,
    this.createdAt,
    this.updatedAt,
    this.statusText,
    this.review,
  });

  int id;
  String tripId;
  dynamic stoppage;
  int userId;
  int vehicleTypeId;
  int riderId;
  int locationId;
  DateTime startTime;
  DateTime endTime;
  String origin;
  String destination;
  int distance;
  int duration;
  int passengerNumber;
  String status;
  int price;
  String paymentType;
  dynamic deletedAt;
  DateTime createdAt;
  DateTime updatedAt;
  String statusText;
  Review review;

  factory Booking.fromJson(Map<String, dynamic> json) => Booking(
    id: json["id"],
    tripId: json["trip_id"],
    stoppage: json["stoppage"],
    userId: json["user_id"],
    vehicleTypeId: json["vehicle_type_id"],
    riderId: json["rider_id"] == null ? null : json["rider_id"],
    locationId: json["location_id"],
    startTime: DateTime.parse(json["start_time"]),
    endTime: DateTime.parse(json["end_time"]),
    origin: json["origin"],
    destination: json["destination"],
    distance: json["distance"],
    duration: json["duration"],
    passengerNumber: json["passenger_number"],
    status: json["status"],
    price: json["price"],
    paymentType: json["payment_type"],
    deletedAt: json["deleted_at"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
    statusText: json["status_text"],
    review: json["review"] == null ? null : Review.fromJson(json["review"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "trip_id": tripId,
    "stoppage": stoppage,
    "user_id": userId,
    "vehicle_type_id": vehicleTypeId,
    "rider_id": riderId == null ? null : riderId,
    "location_id": locationId,
    "start_time": startTime.toIso8601String(),
    "end_time": endTime.toIso8601String(),
    "origin": origin,
    "destination": destination,
    "distance": distance,
    "duration": duration,
    "status": status,
    "price": price,
    "payment_type": paymentType,
    "review": review == null ? null : review.toJson(),
  };
}

class Review {
  Review({
    this.rate
  });

  double rate;

  factory Review.fromJson(Map<String, dynamic> json) => Review(
    rate: json["rate"] == null ? null : json["rate"] is int ? json["rate"].toDouble() : json["rate"]
  );

  Map<String, dynamic> toJson() => {
    "rate": rate == null ? null : rate
  };
}

class Location {
  Location({
    this.origin,
    this.destination,
  });

  LocationDetail origin;
  LocationDetail destination;

  factory Location.fromJson(Map<String, dynamic> json) => Location(
    origin: LocationDetail.fromJson(json["origin"]),
    destination: LocationDetail.fromJson(json["destination"]),
  );

  Map<String, dynamic> toJson() => {
    "origin": origin.toJson(),
    "destination": destination.toJson(),
  };
}

class LocationDetail {
  LocationDetail({
    this.name,
    this.latitude,
    this.longitude,
  });

  String name;
  double latitude;
  double longitude;

  factory LocationDetail.fromJson(Map<String, dynamic> json) => LocationDetail(
    name: json["name"],
    latitude: json["latitude"].toDouble(),
    longitude: json["longitude"].toDouble(),
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "latitude": latitude,
    "longitude": longitude,
  };
}




// class BookingHistory {
//   BookingHistory({
//     this.id,
//     this.userId,
//     this.riderId,
//     this.bookingId,
//     this.locationId,
//     this.startTime,
//     this.endTime,
//     this.origin,
//     this.destination,
//     this.stoppage,
//     this.distance,
//     this.duration,
//     this.passengerNumber,
//     this.profileImgUser,
//     this.profileImgRider,
//     this.status,
//     this.price,
//     this.paymentType,
//     this.cancelledByType,
//     this.cancelledById,
//     this.cancelMessage,
//     this.deletedAt,
//     this.createdAt,
//     this.updatedAt,
//     this.location,
//     this.rider,
//     this.review,
//   });
//
//   int id;
//   int userId;
//   dynamic riderId;
//   int bookingId;
//   int locationId;
//   DateTime startTime;
//   DateTime endTime;
//   String origin;
//   String destination;
//   dynamic stoppage;
//   String distance;
//   String duration;
//   String passengerNumber;
//   dynamic profileImgUser;
//   dynamic profileImgRider;
//   String status;
//   int price;
//   String paymentType;
//   dynamic cancelledByType;
//   dynamic cancelledById;
//   dynamic cancelMessage;
//   dynamic deletedAt;
//   DateTime createdAt;
//   DateTime updatedAt;
//   Location location;
//   dynamic rider;
//   Review review;
//
//   factory BookingHistory.fromJson(Map<String, dynamic> json) => BookingHistory(
//     id: json["id"],
//     userId: json["user_id"],
//     riderId: json["rider_id"],
//     bookingId: json["booking_id"],
//     locationId: json["location_id"],
//     startTime: DateTime.parse(json["start_time"]),
//     endTime: DateTime.parse(json["end_time"]),
//     origin: json["origin"],
//     destination: json["destination"],
//     stoppage: json["stoppage"],
//     distance: json["distance"],
//     duration: json["duration"],
//     passengerNumber: json["passenger_number"],
//     profileImgUser: json["profile_img_user"],
//     profileImgRider: json["profile_img_rider"],
//     status: json["status"],
//     price: json["price"],
//     paymentType: json["payment_type"],
//     cancelledByType: json["cancelled_by_type"],
//     cancelledById: json["cancelled_by_id"],
//     cancelMessage: json["cancel_message"],
//     deletedAt: json["deleted_at"],
//     createdAt: DateTime.parse(json["created_at"]),
//     updatedAt: DateTime.parse(json["updated_at"]),
//     location: Location.fromJson(json["location"]),
//     rider: json["rider"],
//     review: json["review"] == null? null : Review.fromJson(json["review"]),
//   );
//
//   Map<String, dynamic> toJson() => {
//     "id": id,
//     "user_id": userId,
//     "rider_id": riderId,
//     "booking_id": bookingId,
//     "location_id": locationId,
//     "start_time": startTime.toIso8601String(),
//     "end_time": endTime.toIso8601String(),
//     "origin": origin,
//     "destination": destination,
//     "stoppage": stoppage,
//     "distance": distance,
//     "duration": duration,
//     "passenger_number": passengerNumber,
//     "profile_img_user": profileImgUser,
//     "profile_img_rider": profileImgRider,
//     "status": status,
//     "price": price,
//     "payment_type": paymentType,
//     "cancelled_by_type": cancelledByType,
//     "cancelled_by_id": cancelledById,
//     "cancel_message": cancelMessage,
//     "deleted_at": deletedAt,
//     "created_at": createdAt.toIso8601String(),
//     "updated_at": updatedAt.toIso8601String(),
//     "location": location.toJson(),
//     "rider": rider,
//     "review": review.toJson(),
//   };
// }
//
// class Location {
//   Location({
//     this.id,
//     this.longitudeOrigin,
//     this.latitudeOrigin,
//     this.longitudeDestination,
//     this.latitudeDestination,
//     this.deletedAt,
//     this.createdAt,
//     this.updatedAt,
//   });
//
//   int id;
//   double longitudeOrigin;
//   double latitudeOrigin;
//   double longitudeDestination;
//   double latitudeDestination;
//   dynamic deletedAt;
//   DateTime createdAt;
//   DateTime updatedAt;
//
//   factory Location.fromJson(Map<String, dynamic> json) => Location(
//     id: json["id"],
//     longitudeOrigin: json["longitude_origin"].toDouble(),
//     latitudeOrigin: json["latitude_origin"].toDouble(),
//     longitudeDestination: json["longitude_destination"].toDouble(),
//     latitudeDestination: json["latitude_destination"].toDouble(),
//     deletedAt: json["deleted_at"],
//     createdAt: DateTime.parse(json["created_at"]),
//     updatedAt: DateTime.parse(json["updated_at"]),
//   );
//
//   Map<String, dynamic> toJson() => {
//     "id": id,
//     "longitude_origin": longitudeOrigin,
//     "latitude_origin": latitudeOrigin,
//     "longitude_destination": longitudeDestination,
//     "latitude_destination": latitudeDestination,
//     "deleted_at": deletedAt,
//     "created_at": createdAt.toIso8601String(),
//     "updated_at": updatedAt.toIso8601String(),
//   };
// }
//
// class Review {
//   Review({
//     this.rate
//   });
//
//   int rate;
//
//   factory Review.fromJson(Map<String, dynamic> json) => Review(
//     rate: json["rate"]
//   );
//
//   Map<String, dynamic> toJson() => {
//     "rate": rate
//   };
// }