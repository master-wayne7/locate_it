

import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/data/models/used_services.dart';
import 'package:puryaideu/app/data/network/constant_headers.dart';
import 'package:puryaideu/app/data/network/network_helper.dart';
import 'package:puryaideu/app/enums/header_type.dart';

class HistoryRequest {
  static Future<dynamic> getRideHistoryList(String vehicle_type_id, String status,int currentPage) async {
    //String url = '$BASE_URL/api/rider/booking/history?page=$currentPage';
    String url = '$BASE_URL/api/user/vehicle_type/$vehicle_type_id/booking/$status/history?page=$currentPage';
    try {
      final response =
      await await NetworkHelper().getRequest(url,
          contentType:
          ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
      print(response.statusCode);
      if (response.statusCode == 200){
        print(response.data);
        final data = response.data['completed_trips']['data'];
        // print(data);

        print('Data is === $data');
        return data;
      } else {
        return response.statusMessage;
      }
    } catch (e) {
      return Future.error(e.toString());
    }
  }

  static Future<List<UsedServices>> getUsedServices() async {
    String url = '$BASE_URL/api/user/customer/services/used';
    try {
      final response =
      await await NetworkHelper().getRequest(url,
          contentType:
          ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
      print(response.statusCode);
      if (response.statusCode == 200){
        final data = response.data;
        List<UsedServices> usedServices = (data['data'] as List)
            .map((i) => UsedServices.fromJson(i))
            .toList();
        return usedServices;
      } else {
        return Future.error('Error'.toString());
      }
    } catch (e) {
      return Future.error(e.toString());
    }
  }

}