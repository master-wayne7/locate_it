import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:puryaideu/app/data/models/history.dart';
import 'package:puryaideu/app/data/models/rider.dart';
import 'package:puryaideu/app/data/models/used_services.dart';
import 'package:puryaideu/app/data/repositories/rider_repository.dart';
import 'package:puryaideu/app/enums/ride_type.dart';
import 'package:puryaideu/app/modules/history/model/booking_history.dart';
import 'package:puryaideu/app/modules/history/model/history_request.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:puryaideu/generated/locales.g.dart';

class HistoryController extends GetxController {

  final rider = Rider().obs;

  final historyPage = false.obs;

  final tabName = [].obs;

  final tabLength = 0.obs;

  final bikeUsed = false.obs;
  final carUsed = false.obs;
  final citySafariUsed = false.obs;
  final ambulanceUsed = false.obs;
  final courierUsed = false.obs;
  final foodDeliveryUsed = false.obs;

  var confirmIndex = 1.obs;
  var cancelledIndex = 1.obs;

  var confirmIndexCar = 1.obs;
  var cancelledIndexCar = 1.obs;

  var confirmIndexSafari = 1.obs;
  var cancelledIndexSafari = 1.obs;

  var confirmIndexAmbulance = 1.obs;
  var cancelledIndexAmbulance = 1.obs;

  var confirmIndexFoodDelivery = 1.obs;
  var cancelledIndexFoodDelivery = 1.obs;

  var confirmIndexCourier = 1.obs;
  var cancelledIndexCourier = 1.obs;

  final bikeCompletedList = [].obs;
  final bikeCancelledList = [].obs;
  final carCompletedList = [].obs;
  final carCancelledList = [].obs;
  final citySafariCompletedList = [].obs;
  final citySafariCancelledList = [].obs;
  final ambulanceCompletedList = [].obs;
  final ambulanceCancelledList = [].obs;
  final foodDeliveryCompletedList = [].obs;
  final foodDeliveryCancelledList = [].obs;
  final courierCompletedList = [].obs;
  final courierCancelledList = [].obs;

  final rideType = RideType.BIKE.obs;

  final bikeCancelStatus = false.obs;
  final carCancelStatus = false.obs;
  final citySafariCancelStatus = false.obs;
  final ambulanceCancelStatus = false.obs;
  final foodDeliveryCancelStatus = false.obs;
  final courierCancelStatus = false.obs;

  final bikeHistory = [].obs;
  final carHistory = [].obs;
  final citySafariHistory = [].obs;
  final ambulanceHistory = [].obs;
  final foodDeliveryHistory = [].obs;
  final courierHistory = [].obs;

  bool returnValueHistory = false;

  final bikeHistoryCompleted = [].obs;
  final bikeHistoryCancelled = [].obs;

  final currentPage = 0.obs;

  final pageController = PageController(initialPage: 0, keepPage: true).obs;





  @override
  void onInit() async{
    final status = await getUserRides();
    if (status) {
      tabBarLength();
    }
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}

  changeBikeCancelStatus() {
    bikeCancelStatus.value = !bikeCancelStatus.value;
    if (bikeCancelStatus.value) {
      bikeHistory.value = bikeCancelledList;
      return;
    }
    bikeHistory.value = bikeCompletedList;
  }

  changeCarCancelStatus() {
    carCancelStatus.value = !carCancelStatus.value;
    if (carCancelStatus.value) {
      carHistory.value = carCancelledList;
      return;
    }
    carHistory.value = carCompletedList;
  }

  changeCitySafariCancelStatus() {
    citySafariCancelStatus.value = !citySafariCancelStatus.value;
    if (citySafariCancelStatus.value) {
      citySafariHistory.value = citySafariCancelledList;
      return;
    }
    citySafariHistory.value = citySafariCancelledList;
  }

  changeAmbulanceCancelStatus() {
    ambulanceCancelStatus.value = !ambulanceCancelStatus.value;
    if (ambulanceCancelStatus.value) {
      ambulanceHistory.value = ambulanceCancelledList;
      return;
    }
    ambulanceHistory.value = ambulanceCompletedList;
  }


  changeFoodDeliveryCancelStatus() {
    foodDeliveryCancelStatus.value = !foodDeliveryCancelStatus.value;
    if (foodDeliveryCancelStatus.value) {
      foodDeliveryHistory.value = foodDeliveryCancelledList;
      return;
    }
    foodDeliveryHistory.value = foodDeliveryCompletedList;
  }

  changeCourierCancelStatus() {
    courierCancelStatus.value = !courierCancelStatus.value;
    if (courierCancelStatus.value) {
      courierHistory.value = courierCancelledList;
      return;
    }
    courierHistory.value = courierCompletedList;
  }

  Future<bool> getUserRides() async {
    final value = await HistoryRequest.getUsedServices().catchError((error) {
      this.errorMessage = "Trip history are unavailable. Please try again!";
    }).then((value) async {
      if (value == null) {
        returnValueHistory = false;
        return returnValueHistory;
      }
      print(
          "Boolean statement is ${value is List<UsedServices> && value.length == 4}");
      if (value is List<UsedServices> && value.length == 6) {
        print(value[0].name);
        bikeUsed.value = value[0].used;
        carUsed.value = value[1].used;
        citySafariUsed.value = value[2].used;
        ambulanceUsed.value = value[3].used;
        foodDeliveryUsed.value = value[4].used;
        courierUsed.value = value[5].used;
        returnValueHistory = true;
        historyPage.value = true;
        return returnValueHistory;
      }
    });
    return returnValueHistory;
  }

  tabBarLength() {
    tabName.value = [];
    tabLength.value = 0;
    if (bikeUsed.value) {
      tabLength.value++;
      tabName.add(LocaleKeys.history_bike.tr);
      getBikeHistoryCompleted();
      getBikeHistoryCancelled();
    }
    if (carUsed.value) {
      tabLength.value++;
      tabName.add(LocaleKeys.history_car.tr);
      getCarHistoryCompleted();
      getCarHistoryCancelled();
    }
    if (citySafariUsed.value) {
      tabLength.value++;
      tabName.add(LocaleKeys.history_city_safari.tr);
      getSafariHistoryCompleted();
      getSafariHistoryCancelled();
    }
    if (ambulanceUsed.value) {
      tabLength.value++;
      tabName.add(LocaleKeys.history_ambulance.tr);
      getAmbulanceHistoryCompleted();
      getAmbulanceHistoryCancelled();
    }
    if (foodDeliveryUsed.value) {
      tabLength.value++;
      tabName.add(LocaleKeys.history_food_delivery.tr);
      getFoodDeliveryHistoryCompleted();
      getFoodDeliveryHistoryCancelled();
    }
    if (courierUsed.value) {
      tabLength.value++;
      // tabName.add(LocaleKeys.history_courier.tr);
      tabName.add('PICKUP TRUCK');
      getCourierHistoryCompleted();
      getCourierHistoryCancelled();
    }
    print('Tab names are: ${tabName}');
    print('Tab length: ${tabLength.value}');
    update();
  }

  String errorMessage = '';

  Future<bool> getRideHistory({bool isRefresh = false}) async {
    getBikeHistoryCompleted();
    getBikeHistoryCancelled();
    getCarHistoryCompleted();
    getCarHistoryCancelled();
    getSafariHistoryCompleted();
    getSafariHistoryCancelled();
  }

  Future<bool> getBikeHistoryCompleted({bool isRefresh = false}) async {
    if (isRefresh) {
      confirmIndex.value = 1;
    }

    final value = await HistoryRequest.getRideHistoryList("1", "completed",  confirmIndex.value)
        .catchError((error) {
      this.errorMessage = "Trip history are unavailable. Please try again!";
    });
    print('Value is === $value');

    if (value == 'Booking record not found' || value == null) {
      if (isRefresh) {
        // vehicleHistory.value = [].obs;
        bikeHistoryCompleted.value = [].obs;
      }
      return false;
    } else if (value.isEmpty)
         {
       return false;
     }
    else {
      //print(value);
      List<BookingHistory> upcomingList =
      (value as List).map((i) => BookingHistory.fromJson(i)).toList();
      //print(upcomingList);
      if (isRefresh) {
        // bikeCompletedList = upcomingList;
        confirmIndex.value = 2;
        bikeHistoryCompleted.value = upcomingList;
      } else {
        confirmIndex++;
        // bikeCompletedList.addAll(upcomingList);
        bikeHistoryCompleted.addAll(upcomingList);
      }

      return true;
    }
  }

  Future<bool> getBikeHistoryCancelled({bool isRefresh = false}) async {
    if (isRefresh) {
      cancelledIndex.value = 1;
    }

    final value = await HistoryRequest.getRideHistoryList("1", "cancelled", cancelledIndex.value)
        .catchError((error) {
      this.errorMessage = "Trip history are unavailable. Please try again!";
    });

    if(value.isEmpty) {
      return false;
    }
    if (value == 'Booking record not found' || value == null) {
      if (isRefresh) {
        // vehicleHistory.value = [].obs;
        bikeCancelledList.value = [];
      }
      return false;
    } else {
      //print(value);
      List<BookingHistory> upcomingList =
      (value as List).map((i) => BookingHistory.fromJson(i)).toList();
      //print(upcomingList);
      if (isRefresh) {
        cancelledIndex.value = 2;
        bikeHistoryCancelled.value = upcomingList;
      } else {
        cancelledIndex++;
        bikeHistoryCancelled.addAll(upcomingList);
      }

      return true;
    }
  }

  Future<bool> getCarHistoryCompleted({bool isRefresh = false}) async {
    if (isRefresh) {
      confirmIndexCar.value = 1;
    }

    final value = await HistoryRequest.getRideHistoryList("2", "completed", confirmIndexCar.value)
        .catchError((error) {
      this.errorMessage = "Trip history are unavailable. Please try again!";
    });
    print('Value is === $value');
    if(value.isEmpty) {
      return false;
    }
    if (value == 'Booking record not found' || value == null) {
      if (isRefresh) {
        // vehicleHistory.value = [].obs;
        carCompletedList.value = [];
      }
      return false;
    } else {
      //print(value);
      List<BookingHistory> upcomingList =
      (value as List).map((i) => BookingHistory.fromJson(i)).toList();
      //print(upcomingList);
      if (isRefresh) {
        carCompletedList.value = upcomingList;
        confirmIndexCar.value = 2;
      } else {
        confirmIndexCar++;
        carCompletedList.addAll(upcomingList);
      }

      return true;
    }
  }

  Future<bool> getCarHistoryCancelled({bool isRefresh = false}) async {
    if (isRefresh) {
      cancelledIndexCar.value = 1;
    }

    final value = await HistoryRequest.getRideHistoryList("2", "cancelled", cancelledIndexCar.value )
        .catchError((error) {
      this.errorMessage = "Trip history are unavailable. Please try again!";
    });

    if(value.isEmpty) {
      return false;
    }
    if (value == 'Booking record not found' || value == null) {
      if (isRefresh) {
        // vehicleHistory.value = [].obs;
        carCancelledList.value = [];
      }
      return false;
    } else {
      //print(value);
      List<BookingHistory> upcomingList =
      (value as List).map((i) => BookingHistory.fromJson(i)).toList();
      //print(upcomingList);
      if (isRefresh) {
        carCancelledList.value = upcomingList;
        cancelledIndexCar.value = 2;
      } else {
        cancelledIndexCar++;
        carCancelledList.addAll(upcomingList);
      }

      return true;
    }
  }

  Future<bool> getSafariHistoryCompleted({bool isRefresh = false}) async {
    if (isRefresh) {
      confirmIndexSafari.value = 1;
    }

    final value = await HistoryRequest.getRideHistoryList("3", "completed", confirmIndexSafari.value)
        .catchError((error) {
      this.errorMessage = "Trip history are unavailable. Please try again!";
    });
    print('Value is === $value');

    if (value == 'Booking record not found' || value == null) {
      if (isRefresh) {
        // vehicleHistory.value = [].obs;
        citySafariCompletedList.value = [];
      }
      return false;
    } else if (value.isEmpty) {
      return false;
    }else {
      //print(value);
      List<BookingHistory> upcomingList =
      (value as List).map((i) => BookingHistory.fromJson(i)).toList();
      //print(upcomingList);
      if (isRefresh) {
        citySafariCompletedList.value = upcomingList;
        confirmIndexSafari.value = 2;
      } else {
        confirmIndexSafari++;
        citySafariCompletedList.addAll(upcomingList);
      }

      return true;
    }
  }

  Future<bool> getSafariHistoryCancelled({bool isRefresh = false}) async {
    if (isRefresh) {
      cancelledIndexSafari.value = 1;
    }

    final value = await HistoryRequest.getRideHistoryList("3", "cancelled", cancelledIndexSafari.value)
        .catchError((error) {
      this.errorMessage = "Trip history are unavailable. Please try again!";
    });
    if(value.isEmpty) {
      return false;
    }
    if (value == 'Booking record not found' || value == null) {
      if (isRefresh) {
        // vehicleHistory.value = [].obs;
        citySafariCancelledList.value = [];
      }
      return false;
    } else {
      //print(value);
      List<BookingHistory> upcomingList =
      (value as List).map((i) => BookingHistory.fromJson(i)).toList();
      //print(upcomingList);
      if (isRefresh) {
        citySafariCancelledList.value = upcomingList;
        cancelledIndexSafari.value = 2;
      } else {
        cancelledIndexSafari++;
        citySafariCancelledList.addAll(upcomingList);
      }

      return true;
    }
  }

  Future<bool> getAmbulanceHistoryCompleted({bool isRefresh = false}) async {
    if (isRefresh) {
      confirmIndexAmbulance.value = 1;
    }

    final value = await HistoryRequest.getRideHistoryList(
        "4", "completed", confirmIndexAmbulance.value)
        .catchError((error) {
      this.errorMessage = "Trip history are unavailable. Please try again!";
    });
    if (value == null) {
      return false;
    }
    print('Value is === $value');
    if (value.isEmpty) {
      return false;
    }
    if (value == 'Booking record not found' || value == null) {
      if (isRefresh) {
        // vehicleHistory.value = [].obs;
        ambulanceCompletedList.value = [].obs;
      }
      return false;
    } else {
      //print(value);
      List<BookingHistory> upcomingList =
      (value as List).map((i) => BookingHistory.fromJson(i)).toList();
      //print(upcomingList);
      if (isRefresh) {
        // bikeCompletedList = upcomingList;
        confirmIndexAmbulance.value = 2;
        ambulanceCompletedList.value = upcomingList;
      } else {
        confirmIndexAmbulance++;
        // bikeCompletedList.addAll(upcomingList);
        ambulanceCompletedList.addAll(upcomingList);
      }

      return true;
    }
  }

  Future<bool> getAmbulanceHistoryCancelled({bool isRefresh = false}) async {
    if (isRefresh) {
      cancelledIndexAmbulance.value = 1;
    }

    final value = await HistoryRequest.getRideHistoryList(
        "4", "cancelled", cancelledIndexAmbulance.value)
        .catchError((error) {
      this.errorMessage = "Trip history are unavailable. Please try again!";
    });
    if (value == null) {
      return false;
    }

    if (value.isEmpty) {
      return false;
    }
    if (value == 'Booking record not found' || value == null) {
      if (isRefresh) {
        // vehicleHistory.value = [].obs;
        bikeCancelledList.value = [];
      }
      return false;
    } else {
      //print(value);
      List<BookingHistory> upcomingList =
      (value as List).map((i) => BookingHistory.fromJson(i)).toList();
      //print(upcomingList);
      if (isRefresh) {
        cancelledIndexAmbulance.value = 2;
        ambulanceCancelledList.value = upcomingList;
      } else {
        cancelledIndexAmbulance++;
        ambulanceCancelledList.addAll(upcomingList);
      }

      return true;
    }
  }

  Future<bool> getFoodDeliveryHistoryCompleted({bool isRefresh = false}) async {
    if (isRefresh) {
      confirmIndexFoodDelivery.value = 1;
    }

    final value = await HistoryRequest.getRideHistoryList(
        "5", "completed", confirmIndexFoodDelivery.value)
        .catchError((error) {
      this.errorMessage = "Trip history are unavailable. Please try again!";
    });
    if (value == null) {
      return false;
    }
    print('Value is === $value');
    if (value.isEmpty) {
      return false;
    }
    if (value == 'Booking record not found' || value == null) {
      if (isRefresh) {
        // vehicleHistory.value = [].obs;
        foodDeliveryCompletedList.value = [].obs;
      }
      return false;
    } else {
      //print(value);
      List<BookingHistory> upcomingList =
      (value as List).map((i) => BookingHistory.fromJson(i)).toList();
      //print(upcomingList);
      if (isRefresh) {
        // bikeCompletedList = upcomingList;
        confirmIndexFoodDelivery.value = 2;
        foodDeliveryCompletedList.value = upcomingList;
      } else {
        confirmIndexFoodDelivery++;
        // bikeCompletedList.addAll(upcomingList);
        foodDeliveryCompletedList.addAll(upcomingList);
      }

      return true;
    }
  }

  Future<bool> getFoodDeliveryHistoryCancelled({bool isRefresh = false}) async {
    if (isRefresh) {
      cancelledIndexFoodDelivery.value = 1;
    }

    final value = await HistoryRequest.getRideHistoryList(
        "5", "cancelled", cancelledIndexFoodDelivery.value)
        .catchError((error) {
      this.errorMessage = "Trip history are unavailable. Please try again!";
    });
    if (value == null) {
      return false;
    }

    if (value.isEmpty) {
      return false;
    }
    if (value == 'Booking record not found' || value == null) {
      if (isRefresh) {
        // vehicleHistory.value = [].obs;
        foodDeliveryCancelledList.value = [];
      }
      return false;
    } else {
      //print(value);
      List<BookingHistory> upcomingList =
      (value as List).map((i) => BookingHistory.fromJson(i)).toList();
      //print(upcomingList);
      if (isRefresh) {
        cancelledIndexFoodDelivery.value = 2;
        foodDeliveryCancelledList.value = upcomingList;
      } else {
        cancelledIndexFoodDelivery++;
        foodDeliveryCancelledList.addAll(upcomingList);
      }

      return true;
    }
  }

  Future<bool> getCourierHistoryCompleted({bool isRefresh = false}) async {
    if (isRefresh) {
      confirmIndexCourier.value = 1;
    }

    final value = await HistoryRequest.getRideHistoryList(
        "6", "completed", confirmIndexCourier.value)
        .catchError((error) {
      this.errorMessage = "Trip history are unavailable. Please try again!";
    });
    if (value == null) {
      return false;
    }
    print('Value is === $value');
    if (value.isEmpty) {
      return false;
    }
    if (value == 'Booking record not found' || value == null) {
      if (isRefresh) {
        // vehicleHistory.value = [].obs;
        courierCompletedList.value = [].obs;
      }
      return false;
    } else {
      //print(value);
      List<BookingHistory> upcomingList =
      (value as List).map((i) => BookingHistory.fromJson(i)).toList();
      //print(upcomingList);
      if (isRefresh) {
        // bikeCompletedList = upcomingList;
        confirmIndexCourier.value = 2;
        courierCompletedList.value = upcomingList;
      } else {
        confirmIndexCourier++;
        // bikeCompletedList.addAll(upcomingList);
        courierCompletedList.addAll(upcomingList);
      }

      return true;
    }
  }

  Future<bool> getCourierHistoryCancelled({bool isRefresh = false}) async {
    if (isRefresh) {
      cancelledIndexCourier.value = 1;
    }

    final value = await HistoryRequest.getRideHistoryList(
        "6", "cancelled", cancelledIndexCourier.value)
        .catchError((error) {
      this.errorMessage = "Trip history are unavailable. Please try again!";
    });
    if (value == null) {
      return false;
    }

    if (value.isEmpty) {
      return false;
    }
    if (value == 'Booking record not found' || value == null) {
      if (isRefresh) {
        // vehicleHistory.value = [].obs;
        courierCancelledList.value = [];
      }
      return false;
    } else {
      //print(value);
      List<BookingHistory> upcomingList =
      (value as List).map((i) => BookingHistory.fromJson(i)).toList();
      //print(upcomingList);
      if (isRefresh) {
        cancelledIndexCourier.value = 2;
        courierCancelledList.value = upcomingList;
      } else {
        cancelledIndexCourier++;
        courierCancelledList.addAll(upcomingList);
      }

      return true;
    }
  }




  Future<bool> getRiderDetail(int id) async {
  print(id);
    final response =
    await RiderRepository.getRiderDetailForHistory(id)
        .catchError((error) {
      errorMessage = "Rider details are unavailable. Please try again!";
    });
    print("response");

    if (response == null) {
      CustomSnackbar.showCustomSnackBar(message: errorMessage);
      return false;
    }
    print('Fetched data===');
    rider.value = response;

    return true;
  }
}
