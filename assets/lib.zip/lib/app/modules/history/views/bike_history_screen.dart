import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:puryaideu/app/config/custom_colors.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/modules/history/controllers/history_controller.dart';
import 'package:puryaideu/app/modules/history_detail/views/history_detail_view.dart';
import 'package:puryaideu/app/widgets/booking_shimmer.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';

import 'history_card.dart';

class BikeHistoryScreen extends StatelessWidget {
  final HistoryController controller = Get.find();
  RefreshController bikeRefreshController =
      RefreshController(initialRefresh: false);

  @override
  Widget build(BuildContext context) {
    return Obx(() => Column(children: [

          Card(
            margin: EdgeInsets.zero,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            child: Container(
              padding: EdgeInsets.all(16),
              child: Row(
                children: [
                  Expanded(child: Text('Show cancelled Rides')),
                  CupertinoSwitch(
                    value: controller.bikeCancelStatus.value,
                    activeColor: Get.theme.accentColor,
                    onChanged: (value) {
                      controller.changeBikeCancelStatus();
                    },
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 0.3),
          Expanded(
              child: SmartRefresher(
                  controller: bikeRefreshController,
                  enablePullDown: true,
                  enablePullUp: true,
                  physics: AlwaysScrollableScrollPhysics(),
                  header: ClassicHeader(
                    refreshStyle: RefreshStyle.Follow,
                    releaseIcon: SizedBox(
                        width: 25.0,
                        height: 25.0,
                        child: const CupertinoActivityIndicator()),
                    failedIcon: Icon(Icons.error, color: Colors.grey),
                    idleIcon: SizedBox(
                        width: 25.0,
                        height: 25.0,
                        child: CupertinoActivityIndicator.partiallyRevealed(
                          progress: 0.4,
                        )),
                    textStyle: Get.textTheme.headline5.copyWith(
                        fontFamily: 'Roboto',
                        color: Get.theme.primaryColor,
                        fontWeight: FontWeight.w500),
                    releaseText: '',
                    idleText: '',
                    failedText: '',
                    completeText: '',
                    refreshingText: '',
                    refreshingIcon: SizedBox(
                        width: 25.0,
                        height: 25.0,
                        child: const CupertinoActivityIndicator()),
                  ),
                  footer: ClassicFooter(
                    // refreshStyle: RefreshStyle.Follow,
                    canLoadingText: '',
                    loadStyle: LoadStyle.ShowWhenLoading,
                    noDataText: '',
                    noMoreIcon: SizedBox(
                        width: 25.0,
                        height: 25.0,
                        child: Icon(FontAwesomeIcons.exclamationCircle,
                            color: redColor)),
                    canLoadingIcon: SizedBox(
                        width: 25.0,
                        height: 25.0,
                        child: const CupertinoActivityIndicator()),
                    failedIcon: Icon(Icons.error, color: Colors.grey),
                    idleIcon: SizedBox(
                        width: 25.0,
                        height: 25.0,
                        child: CupertinoActivityIndicator.partiallyRevealed(
                          progress: 0.4,
                        )),
                    textStyle: Get.textTheme.headline5.copyWith(
                        fontFamily: 'Roboto',
                        color: Get.theme.primaryColor,
                        fontWeight: FontWeight.w500),
                    idleText: '',
                    failedText: '',
                    loadingText: '',
                    loadingIcon: SizedBox(
                        width: 25.0,
                        height: 25.0,
                        child: const CupertinoActivityIndicator()),
                  ),
                  onRefresh: () async {
                    print("${controller.bikeCancelStatus.value} IT IS ");
                    print(controller.bikeCancelStatus.value);
                    if (controller.bikeCancelStatus.value) {
                      final result = await controller.getBikeHistoryCancelled(
                          isRefresh: true);
                      if (result == true) {
                        bikeRefreshController.resetNoData();
                        bikeRefreshController.refreshCompleted();
                      } else {
                        bikeRefreshController.refreshCompleted();
                        bikeRefreshController.printError();
                      }
                    } else {
                      final result = await controller.getBikeHistoryCompleted(
                          isRefresh: true);
                      if (result == true) {
                        bikeRefreshController.resetNoData();
                        bikeRefreshController.refreshCompleted();
                      } else {
                        bikeRefreshController.refreshCompleted();
                        bikeRefreshController.printError();
                      }
                    }
                  },
                  onLoading: () async {
                    print("${controller.bikeCancelStatus.value} IT IS ");
                    if (controller.bikeCancelStatus.value) {
                      final result = await controller.getBikeHistoryCancelled(
                          isRefresh: false);
                      print("Result is $result");
                      if (result) {
                        Future.delayed(const Duration(milliseconds: 1000), () {
                          bikeRefreshController.loadComplete();
                        });
                        print("Load Complete");
                      } else {
                        bikeRefreshController.loadNoData();
                      }
                    } else {
                      final result = await controller.getBikeHistoryCompleted(
                          isRefresh: false);
                      print("Result is $result");
                      if (result) {
                        Future.delayed(const Duration(milliseconds: 1000), () {
                          bikeRefreshController.loadComplete();
                        });
                        print("Load Complete");
                      } else {
                        bikeRefreshController.loadNoData();
                      }
                    }
                    print(
                        "Length is: ${controller.bikeHistoryCompleted.length}");
                  },
                  child: (controller.bikeCancelStatus.value
                              ? controller.bikeHistoryCancelled.length
                              : controller.bikeHistoryCompleted.length) >
                          0
                      ? ListView.builder(
                          scrollDirection: Axis.vertical,
                          shrinkWrap: true,
                          padding: EdgeInsets.symmetric(vertical: 4),
                          physics: AlwaysScrollableScrollPhysics(),
                          itemBuilder: (context, index) {
                            return GestureDetector(
                                onTap: () async {
                                  if (controller.bikeCancelStatus.value) {
                                    final status = true;
                                    await controller.getRiderDetail(controller.bikeHistoryCancelled[index].riderId);
                                    if (status) {
                                      Get.to(() => HistoryDetailView(
                                            rideType: "bike",
                                            rider: controller.rider.value,
                                            booking: controller
                                                .bikeHistoryCancelled[index],
                                          ));
                                    } else {
                                      CustomSnackbar.showCustomSnackBar(
                                        message:
                                            'Trip details currently unavailable. Please try again later.',
                                      );
                                    }
                                  } else {
                                    final status = await controller
                                        .getRiderDetail(controller.bikeHistoryCompleted[index].riderId);
                                    if (status) {
                                      Get.to(() => HistoryDetailView(
                                            rideType: "bike",
                                            rider: controller.rider.value,
                                            booking: controller
                                                .bikeHistoryCompleted[index],
                                          ));
                                    } else {
                                      CustomSnackbar.showCustomSnackBar(
                                        message:
                                            'Trip details currently unavailable. Please try again later.',
                                      );
                                    }
                                  }
                                },
                                child: HistoryCard(controller
                                        .bikeCancelStatus.value
                                    ? controller.bikeHistoryCancelled[index]
                                    : controller.bikeHistoryCompleted[index], controller.bikeCancelStatus.value
                                    ? false
                                    : true));
                          },
                          itemCount: controller.bikeCancelStatus.value
                              ? controller.bikeHistoryCancelled.length
                              : controller.bikeHistoryCompleted.length,
                        )
                      : BookingShimmer()))
        ]));
  }
}

class HistoryTabBar extends StatelessWidget {
  final HistoryController controller = Get.find();

  @override
  Widget build(BuildContext context) {
    return  Obx(() => Container(
      padding: EdgeInsets.only(top: 0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
              decoration: BoxDecoration(
                  color: Colors.white,
                  border: Border.all(color: Colors.black, width: 0.1)),
              child: Row(
                children: [
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        // historyController.updateSelectedBookingPage(
                        //     RideType.BIKE);
                      },
                      child: Container(
                        height: 50,
                        decoration: BoxDecoration(
                            color: controller.currentPage.value == 0
                                ? Get.theme.primaryColor
                                : Colors.white,
                            borderRadius: BorderRadius.circular(0)),
                        padding:
                            EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        child: Center(
                          child: Text(
                            'Bike'.tr,
                            style: Get.textTheme.headline5.copyWith(
                              fontFamily: 'Roboto',
                              fontSize: getResponsiveFont(12),
                              fontWeight: FontWeight.bold,
                              color: controller.currentPage.value == 0
                                  ? Colors.white
                                  : Get.theme.primaryColor,
                            ),
                          ),
                        ),
                      ),
                    ),
                  ),
                  Expanded(
                      child: GestureDetector(
                    onTap: () {
                      // historyController
                      //     .updateSelectedBookingPage(RideType.CAR);
                      // setState(() {});
                    },
                    child: Container(
                      height: 50,
                      decoration: BoxDecoration(
                          color: controller.currentPage.value == 1
                              ? Get.theme.primaryColor
                              : Colors.white,
                          borderRadius: BorderRadius.circular(0)),
                      padding:
                          EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                      child: Center(
                        child: Text(
                          'Car'.tr,
                          style: Get.textTheme.headline5.copyWith(
                            fontSize: getResponsiveFont(12),
                            fontWeight: FontWeight.bold,
                            color: controller.currentPage.value == 1
                                ? Colors.white
                                : Get.theme.primaryColor,
                          ),
                        ),
                      ),
                    ),
                  )),
                  Expanded(
                    child: GestureDetector(
                        onTap: () {
                          // historyController.updateSelectedBookingPage(
                          //     RideType.CITY_SAFARI);
                          // setState(() {});
                        },
                        child: Container(
                          height: 50,
                          decoration: BoxDecoration(
                              color: controller.currentPage.value == 2
                                  ? Get.theme.primaryColor
                                  : Colors.white,
                              borderRadius: BorderRadius.circular(0)),
                          padding:
                              EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                          child: Center(
                            child: Text(
                              'City Safari'.tr,
                              style: Get.textTheme.headline5.copyWith(
                                fontSize: getResponsiveFont(12),
                                fontWeight: FontWeight.bold,
                                color: controller.currentPage.value == 2
                                    ? Colors.white
                                    : Get.theme.primaryColor,
                              ),
                            ),
                          ),
                        )),
                  ),
                ],
              )),
        ],
      ),
    ));
  }
}
