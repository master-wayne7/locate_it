import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/enums/ride_type.dart';
import 'package:puryaideu/app/modules/dashboard/controllers/dashboard_controller.dart';
import 'package:puryaideu/generated/locales.g.dart';

import '../controllers/history_controller.dart';
import 'ambulance_history_view.dart';
import 'bike_history_screen.dart';
import 'car_history_screen.dart';
import 'city_safari_history_screen.dart';
import 'courier_view.dart';
import 'food_delivery_view.dart';
import 'history_shimmer_page.dart';

class HistoryView extends StatefulWidget {
  const HistoryView({Key key}) : super(key: key);

  @override
  _HistoryViewState createState() => _HistoryViewState();
}

class _HistoryViewState extends State<HistoryView> {

  final String id = '/history';
  final HistoryController controller = Get.find();

  final List pageContent = [
    BikeHistoryScreen(),
    CarHistoryScreen(),
    CitySafariHistoryScreen(),
  ];

  @override
  void initState() {
    super.initState();

  }

  @override
  void dispose() {
    super.dispose();
  }

  Widget getTabBar() {
    return TabBar(
        isScrollable: false,
        labelColor: Colors.white,
        labelStyle: Get.textTheme.headline5.copyWith(
            fontFamily: 'Poppins',
            fontSize: getResponsiveFont(15),
            fontWeight: FontWeight.w600),
        unselectedLabelColor: Colors.grey[400],
        indicatorColor: Colors.white,
        tabs: <Widget>[
          Tab(
            child: Align(
              alignment: Alignment.center,
              child: Text(LocaleKeys.history_bike.tr),
            ),
          ),
          Tab(
            child: Align(
              alignment: Alignment.center,
              child: Text(LocaleKeys.history_car.tr),
            ),
          ),
          Tab(
            child: Align(
              alignment: Alignment.center,
              child: Text(LocaleKeys.history_city_safari.tr),
            ),
          ),
        ]);
  }

  Widget getShimmerTabPages() {
    return TabBarView(children: <Widget>[
      HistoryShimmerPage(),
      HistoryShimmerPage(),
      HistoryShimmerPage()
    ]);
  }

  Widget getTabBarPages() {
    return TabBarView(
        children: <Widget>[
          for (var tabName in controller.tabName)
            tabName == LocaleKeys.history_bike.tr
                ? BikeHistoryScreen()
                : tabName == LocaleKeys.history_car.tr
                ? CarHistoryScreen()
                : tabName == LocaleKeys.history_city_safari.tr
                ? CitySafariHistoryScreen()
                : tabName == LocaleKeys.history_ambulance.tr
                ? AmbulanceHistoryScreen()
                : tabName == LocaleKeys.history_food_delivery.tr
                ? FoodDeliveryHistoryScreen()
                : CourierHistoryScreen()
        ]);
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<HistoryController>(
        builder: (myController) => controller.historyPage.value
            ? DefaultTabController(
          length: controller.tabLength.value,
          child: Scaffold(
              backgroundColor: Color(0xffeeeff3),
              appBar: AppBar(
                  systemOverlayStyle: SystemUiOverlayStyle.light,
                  centerTitle: true,
                  backgroundColor: Get.theme.primaryColor,
                  elevation: 0.6,
                  flexibleSpace: FlexibleSpaceBar(
                      background: SafeArea(
                          child: Obx(() => TabBar(
                              isScrollable:
                              controller.tabLength.value > 3
                                  ? true
                                  : false,
                              //controller: tabController,
                              labelColor: Colors.white,
                              labelStyle: Get.textTheme.headline5
                                  .copyWith(
                                  fontFamily: 'Poppins',
                                  fontSize: getResponsiveFont(15),
                                  fontWeight: FontWeight.w600),
                              unselectedLabelColor: Colors.grey[400],
                              indicatorSize: TabBarIndicatorSize.tab,
                              indicatorColor: Colors.white,
                              tabs: <Widget>[
                                for (var tabName
                                in controller.tabName)
                                  Tab(
                                    child: Align(
                                      alignment: Alignment.center,
                                      child: Text(tabName),
                                    ),
                                  )
                              ]))))),
              body: getTabBarPages()),
        )
            : DefaultTabController(
          length: 3,
          child: Scaffold(
              backgroundColor: Color(0xffeeeff3),
              appBar: AppBar(
                systemOverlayStyle: SystemUiOverlayStyle.light,
                centerTitle: true,
                backgroundColor: Get.theme.primaryColor,
                elevation: 0.6,
                flexibleSpace: FlexibleSpaceBar(
                    background: SafeArea(child: getTabBar())),
              ),
              body: getShimmerTabPages()),
        ));
  }

}
