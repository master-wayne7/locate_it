import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:puryaideu/app/config/custom_colors.dart';
import 'package:puryaideu/app/modules/history/controllers/history_controller.dart';
import 'package:puryaideu/app/modules/history_detail/views/history_detail_view.dart';
import 'package:puryaideu/app/widgets/booking_shimmer.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:puryaideu/generated/locales.g.dart';
import 'package:shimmer/shimmer.dart';

import 'history_card.dart';


class FoodDeliveryHistoryScreen extends StatelessWidget {
  final HistoryController controller = Get.find();
  RefreshController foodDeliveryRefreshController =
  RefreshController(initialRefresh: false);

  @override
  Widget build(BuildContext context) {
    return Obx(() => Column(children: [
      Card(
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        child: Container(
          padding: EdgeInsets.all(16),
          child: Row(
            children: [
              Expanded(child: Text(LocaleKeys.history_show_cancelled_rides.tr)),
              CupertinoSwitch(
                value: controller.foodDeliveryCancelStatus.value,
                activeColor: Get.theme.accentColor,
                onChanged: (value) {
                  controller.changeFoodDeliveryCancelStatus();
                },
              ),
            ],
          ),
        ),
      ),
      SizedBox(height: 0.3),
      Expanded(
          child: SmartRefresher(
              controller: foodDeliveryRefreshController,
              physics: AlwaysScrollableScrollPhysics(),
              enablePullDown: true,
              enablePullUp: true,
              header: ClassicHeader(
                refreshStyle: RefreshStyle.Follow,
                releaseIcon: SizedBox(
                    width: 25.0,
                    height: 25.0,
                    child: const CupertinoActivityIndicator()),
                failedIcon: Icon(Icons.error, color: Colors.grey),
                idleIcon: SizedBox(
                    width: 25.0,
                    height: 25.0,
                    child: CupertinoActivityIndicator.partiallyRevealed(
                      progress: 0.4,
                    )),
                textStyle: Get.textTheme.headline5.copyWith(
                    fontFamily: 'Roboto',
                    color: Get.theme.primaryColor,
                    fontWeight: FontWeight.w500),
                releaseText: '',
                idleText: '',
                failedText: '',
                completeText: '',
                refreshingText: '',
                refreshingIcon: SizedBox(
                    width: 25.0,
                    height: 25.0,
                    child: const CupertinoActivityIndicator()),
              ),
              footer: ClassicFooter(
                // refreshStyle: RefreshStyle.Follow,
                canLoadingText: '',
                loadStyle: LoadStyle.ShowWhenLoading,
                noDataText: '',
                noMoreIcon: SizedBox(
                    width: 25.0,
                    height: 25.0,
                    child: Icon(FontAwesomeIcons.exclamationCircle,
                        color: redColor)),
                canLoadingIcon: SizedBox(
                    width: 25.0,
                    height: 25.0,
                    child: const CupertinoActivityIndicator()),
                failedIcon: Icon(Icons.error, color: Colors.grey),
                idleIcon: SizedBox(
                    width: 25.0,
                    height: 25.0,
                    child: CupertinoActivityIndicator.partiallyRevealed(
                      progress: 0.4,
                    )),
                textStyle: Get.textTheme.headline5.copyWith(
                    fontFamily: 'Roboto',
                    color: Get.theme.primaryColor,
                    fontWeight: FontWeight.w500),
                idleText: '',
                failedText: '',
                loadingText: '',
                loadingIcon: SizedBox(
                    width: 25.0,
                    height: 25.0,
                    child: const CupertinoActivityIndicator()),
              ),
              onRefresh: () async {
                print("${controller.foodDeliveryCancelStatus.value} IT IS ");
                print(controller.foodDeliveryCancelStatus.value);
                if (controller.foodDeliveryCancelStatus.value) {
                  print('we are doing this');
                  final result = await controller.getFoodDeliveryHistoryCancelled(
                      isRefresh: true);
                  if (result == true) {
                    foodDeliveryRefreshController.resetNoData();
                    foodDeliveryRefreshController.refreshCompleted();
                  } else {
                    foodDeliveryRefreshController.refreshCompleted();
                    foodDeliveryRefreshController.printError();
                  }
                } else {
                  final result = await controller.getFoodDeliveryHistoryCompleted(
                      isRefresh: true);
                  if (result == true) {
                    foodDeliveryRefreshController.resetNoData();
                    foodDeliveryRefreshController.refreshCompleted();
                  } else {
                    foodDeliveryRefreshController.refreshCompleted();
                    foodDeliveryRefreshController.printError();
                  }
                }
              },
              onLoading: () async {
                print("${controller.foodDeliveryCancelStatus.value} IT IS ");
                if (controller.foodDeliveryCancelStatus.value) {
                  final result = await controller.getFoodDeliveryHistoryCancelled(
                      isRefresh: false);
                  print("Result is $result");
                  if (result) {
                    Future.delayed(const Duration(milliseconds: 1000), () {
                      foodDeliveryRefreshController.loadComplete();
                    });
                    print("Load Complete");
                  } else {
                    foodDeliveryRefreshController.loadNoData();
                  }
                } else {
                  final result = await controller.getFoodDeliveryHistoryCompleted(
                      isRefresh: false);
                  print("Result is $result");
                  if (result) {
                    Future.delayed(const Duration(milliseconds: 1000), () {
                      foodDeliveryRefreshController.loadComplete();
                    });
                    print("Load Complete");
                  } else {
                    foodDeliveryRefreshController.loadNoData();
                  }
                }
                print(
                    "Length is: ${controller.foodDeliveryCompletedList.length}");
              },
              child: (controller.foodDeliveryCancelStatus.value
                  ? controller.foodDeliveryCancelledList.length
                  : controller.foodDeliveryCompletedList.length) >
                  0
                  ? ListView.builder(
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                padding: EdgeInsets.symmetric(vertical: 0),
                physics: AlwaysScrollableScrollPhysics(),
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () async {
                      if (controller.foodDeliveryCancelStatus.value) {
                        if(controller
                            .foodDeliveryCancelledList[index].userId == null){
                          Get.to(() => HistoryDetailView(
                            rideType: "food_delivery",
                            rider: null,
                            booking: controller
                                .foodDeliveryCancelledList[index],
                          ));
                          return;
                        }
                        final status =
                        await controller.getRiderDetail(controller
                            .foodDeliveryCancelledList[index].userId);
                        if (status) {
                          Get.to(() => HistoryDetailView(
                            rideType: "food_delivery",
                            rider: controller.rider.value,
                            booking: controller
                                .foodDeliveryCancelledList[index],
                          ));
                        } else {
                          CustomSnackbar.showCustomSnackBar(
                            message:
                            'Trip details currently unavailable. Please try again later.',
                          );
                        }
                      } else {
                        final status = await controller
                            .getRiderDetail(controller
                            .foodDeliveryCompletedList[index].riderId);
                        if (status) {
                          Get.to(() => HistoryDetailView(
                            rideType: "food_delivery",
                            rider: controller.rider.value,
                            booking: controller
                                .foodDeliveryCompletedList[index],
                          ));
                        } else {
                          CustomSnackbar.showCustomSnackBar(
                            message:
                            'Trip details currently unavailable. Please try again later.',
                          );
                        }
                      }
                    },
                    child: HistoryCard(
                        controller.foodDeliveryCancelStatus.value
                            ? controller.foodDeliveryCancelledList[index]
                            : controller.foodDeliveryCompletedList[index],
                        controller.foodDeliveryCancelStatus.value
                            ? false
                            : true),
                  );
                },
                itemCount: controller.foodDeliveryCancelStatus.value
                    ? controller.foodDeliveryCancelledList.length
                    : controller.foodDeliveryCompletedList.length,
              )
                  : BookingShimmer()))
    ]));
  }
}
