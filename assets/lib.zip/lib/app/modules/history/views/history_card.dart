import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/modules/history/controllers/history_controller.dart';
import 'package:puryaideu/app/modules/history/model/booking_history.dart';
import 'package:puryaideu/app/modules/ratings/views/rate_later.dart';
import 'package:puryaideu/generated/locales.g.dart';

class HistoryCard extends StatelessWidget {
  final BookingHistory history;

  final bool cancel;

  HistoryCard(this.history, this.cancel);

  final HistoryController controller = Get.find();

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 4),
      child: Column(
        children: [
          Card(
            margin: EdgeInsets.zero,
            elevation: 0.2,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            child: Container(
              padding: EdgeInsets.all(16),
              child: Column(
                children: [
                  Row(
                    children: [
                      Text('${dateToString(history.createdAt)}',
                          style: Get.textTheme.headline5),
                      Expanded(child: Container()),
                      GestureDetector(
                        onTap: () {
                          print(history.bookingId);
                        },
                        child: Text(
                          LocaleKeys.units_rs.tr +
                              ' ${(history.price)}',
                          style: Get.textTheme.headline5,
                        ),
                      ),
                      SizedBox(width: 8),
                    ],
                  ),
                  SizedBox(height: 8),
                  Row(
                    children: [
                      Expanded(
                        child: Column(
                          children: [
                            Row(
                              children: [
                                Icon(FontAwesomeIcons.mapMarkerAlt,
                                    size: 22, color: Get.theme.accentColor),
                                SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    '${history.location.origin.name}',
                                    style: Get.textTheme.bodyText2.copyWith(
                                        fontSize: getResponsiveFont(12)),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                            SizedBox(height: 8),
                            Row(
                              children: [
                                Icon(FontAwesomeIcons.mapPin,
                                    size: 22, color: Get.theme.primaryColor),
                                SizedBox(width: 8),
                                Expanded(
                                  child: Text(
                                    '${history.location.destination.name}',
                                    style: Get.textTheme.bodyText2.copyWith(
                                        fontSize: getResponsiveFont(12)),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      SizedBox(width: 16),
                      Text(
                          '${((double.parse(history.distance))).toStringAsFixed(2)} ' + LocaleKeys.units_km.tr),
                    ],
                  ),
                ],
              ),
            ),
          ),
          SizedBox(height: 1),
          cancel
              ? Card(
            elevation: 0.5,
            margin: EdgeInsets.zero,
            shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.zero),
            child: Container(
              padding: EdgeInsets.all(16),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  GestureDetector(
                    onTap: () async {},
                    child: Container(),
                  ),
                  history.booking.review == null
                      ? GestureDetector(
                    onTap: () async {
                      final status = await controller
                          .getRiderDetail(history.userId);
                      Get.to(() => RatingLaterScreen(
                        rider: controller.rider.value,
                        booking: history,
                      ));
                    },
                    child: Container(
                      child: Text(
                        LocaleKeys.history_rate_now.tr,
                        style: Get.textTheme.headline6.copyWith(
                          fontSize: getResponsiveFont(12),
                          color: Get.theme.accentColor,
                        ),
                      ),
                    ),
                  )
                      : IgnorePointer(
                    child: RatingBar(
                        initialRating:
                        history.booking.review.rate.toDouble(),
                        glow: false,
                        direction: Axis.horizontal,
                        allowHalfRating: true,
                        tapOnlyMode: false,
                        updateOnDrag: false,
                        itemCount: 5,
                        itemSize: getResponsiveFont(16.0),
                        ratingWidget: RatingWidget(
                            full: Icon(Icons.star,
                                color: Color(0xffFFD700)),
                            half: Icon(
                              Icons.star_half,
                              color: Color(0xffFFD700),
                            ),
                            empty: Icon(Icons.star_outline,
                                color: Color(0xffFFD700))),
                        onRatingUpdate: (value) {}),
                  ),
                ],
              ),
            ),
          )
              : SizedBox(height: 0)
        ],
      ),
    );
  }

  String dateToString(DateTime dateTime) {
    if (dateTime == null) {
      return 'Not found';
    }
    return DateFormat('yyyy-MM-dd').format(dateTime);
  }
}
