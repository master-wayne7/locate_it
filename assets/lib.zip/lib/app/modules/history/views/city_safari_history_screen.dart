import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:puryaideu/app/config/custom_colors.dart';
import 'package:puryaideu/app/modules/history/controllers/history_controller.dart';
import 'package:puryaideu/app/modules/history_detail/views/history_detail_view.dart';
import 'package:puryaideu/app/widgets/booking_shimmer.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';

import 'bike_history_screen.dart';
import 'history_card.dart';

class CitySafariHistoryScreen extends StatelessWidget {
  final HistoryController controller = Get.find();
  RefreshController _citySafariRefreshController =
  RefreshController(initialRefresh: false);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Card(
          margin: EdgeInsets.zero,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          child: Container(
            padding: EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(child: Text('Show cancelled Rides')),
                Obx(
                      () => CupertinoSwitch(
                    value: controller.citySafariCancelStatus.value,
                    activeColor: Get.theme.accentColor,
                    onChanged: (value) {
                      controller.changeCitySafariCancelStatus();
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
        SizedBox(height: 0.3),
        Expanded(
          child: Obx(
                () => SmartRefresher(
              controller: _citySafariRefreshController,
                  physics: AlwaysScrollableScrollPhysics(),
              enablePullDown: true,

              enablePullUp: true,
                  header: ClassicHeader(
                    refreshStyle: RefreshStyle.Follow,
                    releaseIcon: SizedBox(
                        width: 25.0,
                        height: 25.0,
                        child: const CupertinoActivityIndicator()),
                    failedIcon: Icon(Icons.error, color: Colors.grey),
                    idleIcon: SizedBox(
                        width: 25.0,
                        height: 25.0,
                        child: CupertinoActivityIndicator.partiallyRevealed(
                          progress: 0.4,
                        )),
                    textStyle: Get.textTheme.headline5.copyWith(
                        fontFamily: 'Roboto',
                        color: Get.theme.primaryColor,
                        fontWeight: FontWeight.w500),
                    releaseText: '',
                    idleText: '',
                    failedText: '',
                    completeText: '',
                    refreshingText: '',
                    refreshingIcon: SizedBox(
                        width: 25.0,
                        height: 25.0,
                        child: const CupertinoActivityIndicator()),
                  ),
                  footer: ClassicFooter(
                    // refreshStyle: RefreshStyle.Follow,
                    canLoadingText: '',
                    loadStyle: LoadStyle.ShowWhenLoading,
                    noDataText: '',
                    noMoreIcon: SizedBox(
                        width: 25.0,
                        height: 25.0,
                        child: Icon(FontAwesomeIcons.exclamationCircle,
                            color: redColor)),
                    canLoadingIcon: SizedBox(
                        width: 25.0,
                        height: 25.0,
                        child: const CupertinoActivityIndicator()),
                    failedIcon: Icon(Icons.error, color: Colors.grey),
                    idleIcon: SizedBox(
                        width: 25.0,
                        height: 25.0,
                        child: CupertinoActivityIndicator.partiallyRevealed(
                          progress: 0.4,
                        )),
                    textStyle: Get.textTheme.headline5.copyWith(
                        fontFamily: 'Roboto',
                        color: Get.theme.primaryColor,
                        fontWeight: FontWeight.w500),
                    idleText: '',
                    failedText: '',
                    loadingText: '',
                    loadingIcon: SizedBox(
                        width: 25.0,
                        height: 25.0,
                        child: const CupertinoActivityIndicator()),
                  ),
              onRefresh: () async {
                print(controller.bikeCancelStatus.value);
                if (controller.bikeCancelStatus.value) {
                  final result = await controller.getSafariHistoryCancelled(
                      isRefresh: true);
                  if (result == true) {
                    _citySafariRefreshController.resetNoData();
                    _citySafariRefreshController.refreshCompleted();
                  } else {
                    _citySafariRefreshController.refreshCompleted();
                    _citySafariRefreshController.printError();
                  }
                } else {
                  final result = await controller.getSafariHistoryCompleted(
                      isRefresh: true);
                  if (result == true) {
                    _citySafariRefreshController.resetNoData();
                    _citySafariRefreshController.refreshCompleted();
                  } else {
                    _citySafariRefreshController.refreshCompleted();
                    _citySafariRefreshController.printError();
                  }
                }
              },
              onLoading: () async {
                if (controller.bikeCancelStatus.value) {
                  final result = await controller.getSafariHistoryCancelled(
                      isRefresh: false);
                  if (result) {
                    _citySafariRefreshController.requestLoading(
                        duration: Duration(seconds: 1));
                    Future.delayed(const Duration(milliseconds: 1000), () {
                      _citySafariRefreshController.loadComplete();
                    });
                  } else {
                    _citySafariRefreshController.loadNoData();
                  }
                } else {
                  final result = await controller.getSafariHistoryCompleted(
                      isRefresh: false);
                  if (result) {
                    _citySafariRefreshController.requestLoading(
                        duration: Duration(seconds: 1));
                    Future.delayed(const Duration(milliseconds: 1000), () {
                      _citySafariRefreshController.loadComplete();
                    });
                  } else {
                    _citySafariRefreshController.loadNoData();
                  }
                }
              },
              child: (!controller.citySafariCancelStatus.value
                  ? controller.citySafariCompletedList.length
                  : controller.citySafariCompletedList.length) >
                  0
                  ? ListView.builder(
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                padding: EdgeInsets.symmetric(vertical: 4),
                physics: NeverScrollableScrollPhysics(),
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () async{
                      if (controller.citySafariCancelStatus.value) {
                        final status = await controller.getRiderDetail(controller.citySafariCancelledList[index].riderId);
                        if(status){
                          Get.to(() => HistoryDetailView(
                            rideType: "citySafari",
                            rider: controller.rider.value,
                            booking: controller.citySafariCancelledList[index],
                          ));
                        }else{
                          CustomSnackbar.showCustomSnackBar(
                            message: 'Trip details currently unavailable. Please try again later.',
                          );
                        }

                      } else {
                        final status = await controller.getRiderDetail(controller.citySafariCompletedList[index].riderId);
                        if(status){
                          Get.to(() => HistoryDetailView(
                            rideType: "citySafari",
                            rider: controller.rider.value,
                            booking: controller.citySafariCompletedList[index],
                          ));
                        }else{
                          CustomSnackbar.showCustomSnackBar(
                            message: 'Trip details currently unavailable. Please try again later.',
                          );
                        }
                      }
                    },
                    child: HistoryCard(controller.citySafariCancelStatus.value
                        ? controller.carCancelledList[index]
                        : controller.citySafariCompletedList[index], controller.citySafariCancelStatus.value
                        ? false
                        : true),
                  );
                },
                itemCount: controller.citySafariCancelStatus.value
                    ? controller.citySafariCompletedList.length
                    : controller.citySafariCompletedList.length,
              )
                  : BookingShimmer(),
            ),
          ),
        ),
      ],
    );
  }
}