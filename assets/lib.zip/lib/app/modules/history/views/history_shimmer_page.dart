import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/widgets/booking_shimmer.dart';
import 'package:shimmer/shimmer.dart';

class HistoryShimmerPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Column(children: [
      Card(
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        child: Container(
          color: Colors.white70,
          padding: EdgeInsets.all(16),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Shimmer.fromColors(
                baseColor: Color(0xffeeeff3),
                highlightColor: Colors.white,
                enabled: true,
                child: Container(
                  padding: EdgeInsets.only(left: 16),
                  width: 120,
                  height: 16,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
              Shimmer.fromColors(
                baseColor: Color(0xffeeeff3),
                highlightColor: Colors.white,
                enabled: true,
                child: CupertinoSwitch(
                  value: false,
                  activeColor: Get.theme.accentColor,
                  onChanged: (value) {},
                ),
              ),
            ],
          ),
        ),
      ),
      SizedBox(height: 0.3),
      Expanded(child: BookingShimmer())
    ]);
  }
}
