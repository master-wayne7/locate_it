import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:puryaideu/app/config/custom_colors.dart';
import 'package:puryaideu/app/modules/history/controllers/history_controller.dart';
import 'package:puryaideu/app/modules/history_detail/views/history_detail_view.dart';
import 'package:puryaideu/app/widgets/booking_shimmer.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';

import 'bike_history_screen.dart';
import 'history_card.dart';

class CarHistoryScreen extends StatelessWidget {
  final HistoryController controller = Get.find();
  RefreshController _carRefreshController =
  RefreshController(initialRefresh: false);

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Card(
          margin: EdgeInsets.zero,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          child: Container(
            padding: EdgeInsets.all(16),
            child: Row(
              children: [
                Expanded(child: Text('Show cancelled Rides')),
                Obx(
                      () => CupertinoSwitch(
                    value: controller.carCancelStatus.value,
                    activeColor: Get.theme.accentColor,
                    onChanged: (value) {
                      controller.changeCarCancelStatus();
                    },
                  ),
                ),
              ],
            ),
          ),
        ),
        SizedBox(height: 0.3),
        Obx(
              () => Expanded(
            child: SmartRefresher(
              controller: _carRefreshController,
              enablePullDown: true,
              enablePullUp: true,

              physics: AlwaysScrollableScrollPhysics(),
              header: ClassicHeader(
                refreshStyle: RefreshStyle.Follow,
                releaseIcon: SizedBox(
                    width: 25.0,
                    height: 25.0,
                    child: const CupertinoActivityIndicator()),
                failedIcon: Icon(Icons.error, color: Colors.grey),
                idleIcon: SizedBox(
                    width: 25.0,
                    height: 25.0,
                    child: CupertinoActivityIndicator.partiallyRevealed(
                      progress: 0.4,
                    )),
                textStyle: Get.textTheme.headline5.copyWith(
                    fontFamily: 'Roboto',
                    color: Get.theme.primaryColor,
                    fontWeight: FontWeight.w500),
                releaseText: '',
                idleText: '',
                failedText: '',
                completeText: '',
                refreshingText: '',
                refreshingIcon: SizedBox(
                    width: 25.0,
                    height: 25.0,
                    child: const CupertinoActivityIndicator()),
              ),
              footer: ClassicFooter(
                // refreshStyle: RefreshStyle.Follow,
                canLoadingText: '',
                loadStyle: LoadStyle.ShowWhenLoading,
                noDataText: '',
                noMoreIcon: SizedBox(
                    width: 25.0,
                    height: 25.0,
                    child: Icon(FontAwesomeIcons.exclamationCircle,
                        color: redColor)),
                canLoadingIcon: SizedBox(
                    width: 25.0,
                    height: 25.0,
                    child: const CupertinoActivityIndicator()),
                failedIcon: Icon(Icons.error, color: Colors.grey),
                idleIcon: SizedBox(
                    width: 25.0,
                    height: 25.0,
                    child: CupertinoActivityIndicator.partiallyRevealed(
                      progress: 0.4,
                    )),
                textStyle: Get.textTheme.headline5.copyWith(
                    fontFamily: 'Roboto',
                    color: Get.theme.primaryColor,
                    fontWeight: FontWeight.w500),
                idleText: '',
                failedText: '',
                loadingText: '',
                loadingIcon: SizedBox(
                    width: 25.0,
                    height: 25.0,
                    child: const CupertinoActivityIndicator()),
              ),
              onRefresh: () async {
                print(controller.carCancelStatus.value);
                if (controller.carCancelStatus.value) {
                  final result =
                  await controller.getCarHistoryCancelled(isRefresh: true);
                  if (result == true) {
                    _carRefreshController.resetNoData();
                    _carRefreshController.refreshCompleted();
                  } else {
                    _carRefreshController.refreshCompleted();
                    _carRefreshController.printError();
                  }
                } else {
                  final result =
                  await controller.getCarHistoryCompleted(isRefresh: true);
                  if (result == true) {
                    _carRefreshController.resetNoData();
                    _carRefreshController.refreshCompleted();
                  } else {
                    _carRefreshController.refreshCompleted();
                    _carRefreshController.printError();
                  }
                }
              },
              onLoading: () async {
                if (controller.carCancelStatus.value) {
                  final result =
                  await controller.getCarHistoryCancelled(isRefresh: false);
                  if (result) {
                    _carRefreshController.requestLoading(
                        duration: Duration(seconds: 1));
                    Future.delayed(const Duration(milliseconds: 1000), () {
                      _carRefreshController.loadComplete();
                    });
                  } else {
                    _carRefreshController.loadNoData();
                  }
                } else {
                  final result =
                  await controller.getCarHistoryCompleted(isRefresh: false);
                  if (result == true) {
                    _carRefreshController.resetNoData();
                    _carRefreshController.refreshCompleted();
                  } else {
                    _carRefreshController.refreshFailed();
                    _carRefreshController.printError();
                  }
                }
              },
              child: (!controller.carCancelStatus.value
                  ? controller.carCompletedList.length
                  : controller.carCancelledList.length) >
                  0
                  ? ListView.builder(
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                padding: EdgeInsets.symmetric(vertical: 4),
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () async{
                      if (controller.carCancelStatus.value) {
                        final status = await controller.getRiderDetail(controller.carCancelledList[index].riderId);
                        if(status){
                          Get.to(() => HistoryDetailView(
                            rideType: "car",
                            rider: controller.rider.value,
                            booking: controller.carCancelledList[index],
                          ));
                        }else{
                          CustomSnackbar.showCustomSnackBar(
                            message: 'Trip details currently unavailable. Please try again later.',
                          );
                        }

                      } else {
                        final status = await controller.getRiderDetail(controller.carCompletedList[index].riderId);
                        if(status){
                          Get.to(() => HistoryDetailView(
                            rideType: "car",
                            rider: controller.rider.value,
                            booking: controller.carCompletedList[index],
                          ));
                        }else{
                          CustomSnackbar.showCustomSnackBar(
                            message: 'Trip details currently unavailable. Please try again later.',
                          );
                        }
                      }
                    },
                    child: HistoryCard(controller.carCancelStatus.value
                        ? controller.carCancelledList[index]
                        : controller.carCompletedList[index], controller.carCancelStatus.value
                        ? false
                        : true),
                  );
                },
                itemCount: controller.carCancelStatus.value
                    ? controller.carCancelledList.length
                    : controller.carCompletedList.length,
              )
                  : BookingShimmer(),
            ),
          ),
        ),
      ],
    );
  }
}