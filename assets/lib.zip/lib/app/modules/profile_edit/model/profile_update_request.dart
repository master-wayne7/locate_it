import 'dart:io';

class ProfileUpdateRequest {
  String firstName;
  String lastName;
  String gender;
  DateTime dob;
  File image;


  ProfileUpdateRequest({
    this.image,
    this.lastName,
    this.firstName,
    this.gender,
    this.dob,
  });

}
