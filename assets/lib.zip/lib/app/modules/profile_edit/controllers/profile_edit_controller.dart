import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:dio/dio.dart' as dio;
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:puryaideu/app/data/models/user.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/data/repositories/profile_repository.dart';
import 'package:puryaideu/app/modules/profile/controllers/profile_controller.dart';
import 'package:puryaideu/app/modules/profile_edit/model/profile_update_request.dart';
import 'package:puryaideu/app/utils/validator.dart';

class ProfileEditController extends GetxController {
  final progressBarStatus = false.obs;
  File _imageFile;
  String firstName;
  String lastName;
  String email = '';
  String phone;
  String password;
  String _errorText;
  User _user;
  bool enableEmailEditing = false;
  TextEditingController firstNameController = TextEditingController();
  TextEditingController lastNameController = TextEditingController();
  TextEditingController phoneController = TextEditingController();
  TextEditingController emailController = TextEditingController();
  List<String> _genderList = ['Male', 'Female', 'Others'];
  final selectedGender = 'Male'.obs;
  final _dob = DateTime.now().add(Duration(days: -365 * 18)).obs;
  final enableEditButton = false.obs;
  final passwordInvisible = true.obs;

  File get imageFile => _imageFile;

  String get errorText => _errorText;

  List<String> get genderList => _genderList;

  DateTime get dob => _dob.value;

  String get dateOfBirth => dateToString(_dob.value);

  User get user => _user;

  @override
  void onInit() {
    _user = SessionManager.instance.user;
    String name = _user.name;
    var arr = name.split(' ');
    String _firstName = arr[0];
    String _lastName = '';
    for (int i = 1; i < arr.length; i++) {
      _lastName = _lastName + ' ' + arr[i];
    }
    firstNameController.text = _firstName;
    lastNameController.text = _lastName;
    emailController.text = _user.email;
    phoneController.text = _user.phone;
    enableEmailEditing = _user.email.length == 0 ? true : false;
    // _facebookId = _user.value.facebookId;
    // _googleId = _user.value.googleId;
    // phoneController.text = _user.value.phone;
    selectedGender.value = _user.gender == null ? 'Male' : _user.gender;
    var dateTime = _user.dob;
    _dob.value = dateTime;
    checkFormFilled();
    super.onInit();
  }

  void updateDob(DateTime date) => _dob.value = date;

  updateGender(String newGender) => selectedGender.value = newGender;

  void updateImageFile(File file) {
    _imageFile = file;
    update();
  }

  String dateToString(DateTime dateTime) => (dateTime == null)
      ? 'Not found'
      : DateFormat('yyyy/MM/dd').format(dateTime);

  bool validateData() {
    firstName = firstNameController.text.trim();
    lastName = lastNameController.text.trim();
    email = emailController.text;
    bool isValid = false;

    if (!(firstName.length > 1 && Validator.isName(firstName))) {
      _errorText = 'first_name_error'.tr;
    } else if (!(lastName.length > 1 && Validator.isName(lastName))) {
      _errorText = 'last_name_error'.tr;
    } else if (!(Validator.isEmail(emailController.value.text))) {
      _errorText = 'valid_email_error'.tr;
    } else if (dateToString(_dob.value) == dateToString(DateTime.now())) {
      _errorText = 'valid_dob'.tr;
    } else {
      isValid = true;
    }
    return isValid;
  }

  Future<bool> performUserUpdate() async {
    showProgressBar();
    File image;
    dynamic multipartImage;

    if (_imageFile != null) {
      final Directory dir = await getApplicationDocumentsDirectory();
      String dirPath = dir.path;
      final String filePath = '$dirPath/image.jpg';
      image = await _imageFile.copy(filePath);
      multipartImage = await dio.MultipartFile.fromFile(image.path);
    }
    String _firstName = firstName;
    String _lastName = lastName;

    ProfileUpdateRequest user = ProfileUpdateRequest(
        firstName: firstNameController.value.text,
        lastName: lastNameController.value.text,
        dob: _dob.value,
        gender: selectedGender.value,
        image: image);
    final responseData = await ProfileRepository.updateUserDetail(user)
        .catchError((error) {
      _errorText = error;
    });
    hideProgressBar();
    print(responseData);
    if (responseData == null) {
      return false;
    }
    print("responseData is == $responseData");
    if(responseData){
      ProfileController profileController = Get.find();

      return true;
    }
    return true;
  }

  void checkFormFilled() {
    if (firstNameController.text.length > 0 &&
        lastNameController.text.length > 0 &&
        emailController.text.length > 0) {
      enableEditButton.value = true;
    } else {
      enableEditButton.value = false;
    }
  }

  void hideProgressBar() => progressBarStatus.value = false;

  void showProgressBar() => progressBarStatus.value = true;
}
