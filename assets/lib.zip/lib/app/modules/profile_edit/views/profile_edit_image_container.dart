import 'dart:io';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/data/models/user.dart';
import 'package:puryaideu/app/modules/profile_edit/controllers/profile_edit_controller.dart';
import 'package:puryaideu/app/modules/signup/controllers/signup_controller.dart';
import 'package:puryaideu/app/utils/image_selector.dart';
import 'package:puryaideu/generated/locales.g.dart';

class ProfileEditImageContainer extends GetView<ProfileEditController> {
  final User user;

  ProfileEditImageContainer({this.user});
  @override
  Widget build(BuildContext context) {
    return GetBuilder<ProfileEditController>(
      builder: (controller) => GestureDetector(
        onTap: () {
          _showPicker(context);
        },
        child: Container(
          height: Get.width * 0.5,
          width: Get.width,
          child: Center(
              child: Container(
            decoration: BoxDecoration(
              color: Colors.grey,
              borderRadius: BorderRadius.circular(Get.width * 0.2),
            ),
            height: Get.width * 0.35,
            width: Get.width * 0.35,
            child: controller.imageFile != null
                ? ClipRRect(
                    borderRadius: BorderRadius.circular(Get.width * 0.2),
                    child: Image.file(controller.imageFile,
                        height: Get.width * 0.35,
                        width: Get.width * 0.35,
                        fit: BoxFit.cover),
                  )
                : controller.user.imagePath == null
                    ? Icon(
                        Icons.add_a_photo_rounded,
                        color: Colors.grey[800],
                      )
                    : Stack(
                      children: [
                        ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: CachedNetworkImage(
                              imageUrl: '$BASE_URL/${user.imagePath}',
                              fit: BoxFit.cover,
                            ),
                          ),
                        Align(
                          alignment: Alignment.bottomRight,
                          child: Icon(
                            Icons.add_a_photo_rounded,
                            color: Colors.black,
                            size: 35,
                          ),
                        )
                      ],
                    ),
          )),
        ),
      ),
    );
  }

  void _showPicker(context) {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext bc) {
          return SafeArea(
            child: Container(
              child: Wrap(
                children: <Widget>[
                  ListTile(
                      leading: Icon(
                        Icons.photo_library,
                        color: Get.theme.primaryColor,
                      ),
                      title: Text(LocaleKeys.image_picker_items_photo_library.tr,
                          style: Get.textTheme.headline5
                              .copyWith(color: Get.theme.accentColor)),
                      onTap: () async {
                        File selectedImage = await ImageSelector()
                            .getSelectedImage(ImageSource.gallery);
                        print('imagepath is=== ${selectedImage.path}');
                        controller.updateImageFile(selectedImage);
                        Navigator.of(context).pop();
                      }),
                  ListTile(
                    leading: Icon(
                      Icons.photo_camera,
                      color: Get.theme.primaryColor,
                    ),
                    title: Text(LocaleKeys.image_picker_items_camera.tr,
                        style: Get.textTheme.headline5
                            .copyWith(color: Get.theme.accentColor)),
                    onTap: () async {
                      File selectedImage = await ImageSelector()
                          .getSelectedImage(ImageSource.camera);
                      print('imagepath is=== ${selectedImage.path}');
                      controller.updateImageFile(selectedImage);
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              ),
            ),
          );
        });
  }
}
