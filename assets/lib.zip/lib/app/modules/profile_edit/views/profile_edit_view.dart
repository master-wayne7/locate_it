import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:puryaideu/app/modules/profile/controllers/profile_controller.dart';
import 'package:puryaideu/app/modules/profile_edit/views/profile_edit_form.dart';
import 'package:puryaideu/app/routes/app_pages.dart';
import 'package:puryaideu/app/widgets/custom_button.dart';
import 'package:puryaideu/app/widgets/custom_progress_bar.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:puryaideu/generated/locales.g.dart';
import './../controllers/profile_edit_controller.dart';
import 'profile_edit_image_container.dart';

class ProfileEditView extends GetView<ProfileEditController> {
  ProfileController profileController = Get.find();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Stack(
          children: [
            Column(
              children: [
                Container(
                  margin: EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      GestureDetector(
                          onTap: () {
                            Get.back();
                          },
                          child: Icon(Icons.arrow_back_ios)),
                      SizedBox(width: 16),
                      Text(
                        LocaleKeys.text_add_profile.tr,
                        style: Get.textTheme.headline6,
                      ),
                    ],
                  ),
                ),
                Expanded(
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        ProfileEditImageContainer(
                          user: profileController.user.value,
                        ),
                        Container(
                          margin: EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              ProfileEditForm(),
                              SizedBox(height: Get.height * 0.05),
                              Obx(
                                    () => Container(
                                  width: Get.width,
                                  child: CustomButton(
                                      onPressed: controller.enableEditButton.value? () async {
                                        if (controller.validateData()) {
                                          final status = await controller
                                              .performUserUpdate();
                                          print('status: $status');
                                          if (status) {
                                            ProfileController profileController = Get.find();
                                            final response = await profileController.getUserDetail();
                                            print('Get user deails: $response');
                                            if(response){
                                              Get.back();
                                              CustomSnackbar.showCustomSnackBar(message: 'Profile Updated successfully.');
                                            }

                                          } else {
                                            CustomSnackbar.showCustomSnackBar(
                                                message:
                                                '${controller.errorText}');
                                          }
                                        } else {
                                          CustomSnackbar.showCustomSnackBar(
                                              message:
                                              '${controller.errorText}');
                                        }
                                      } : null,
                                      backgroundColor: controller.enableEditButton.value? Get.theme.primaryColor: Colors.grey,
                                      text: LocaleKeys.buttons_submit.tr),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            Obx(() => controller.progressBarStatus.value
                ? CustomProgressBar()
                : Container())
          ],
        ),
      ),
    );
  }
}
