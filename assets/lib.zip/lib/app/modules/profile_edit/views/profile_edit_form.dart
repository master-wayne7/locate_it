import 'package:flutter/material.dart';
import 'package:flutter_datetime_picker/flutter_datetime_picker.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/generated/locales.g.dart';
import './../controllers/profile_edit_controller.dart';
import 'package:puryaideu/app/widgets/custom_dropdown_menu.dart';
import 'package:puryaideu/app/widgets/custom_textfield.dart';

class ProfileEditForm extends GetView<ProfileEditController> {
  final FocusNode lastNameNode = FocusNode();
  final FocusNode emailNode = FocusNode();
  final FocusNode passwordNode = FocusNode();

  @override
  Widget build(BuildContext context) {
    final node = FocusScope.of(context);
    return Column(children: [
      Row(
        children: [
          Expanded(
            child: CustomTextField(
              textController: controller.firstNameController,
              label: LocaleKeys.labels_first_name.tr,
              onChanged: (_) {
                controller.checkFormFilled();
              },
              onSubmit: (_) => node.requestFocus(lastNameNode),
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: CustomTextField(
              focusNode: lastNameNode,
              onChanged: (_) {
                controller.checkFormFilled();
              },
              textController: controller.lastNameController,
              label: LocaleKeys.labels_last_name.tr,
              onSubmit: (_) => node.requestFocus(emailNode),
            ),
          ),
        ],
      ),
      SizedBox(height: 16),
      CustomTextField(
        label: 'phone'.tr,
        enabled: false,
        textController: controller.phoneController,
        inputType: TextInputType.emailAddress,
        onSubmit: (_) => node.requestFocus(passwordNode),
      ),
      SizedBox(height: 16),
      CustomTextField(
        label: LocaleKeys.labels_email.tr,
        textController: controller.emailController,
        focusNode: emailNode,
        onChanged: (_) {
          controller.checkFormFilled();
        },
        enabled: controller.enableEmailEditing,
        inputType: TextInputType.emailAddress,
        onSubmit: (_) => node.requestFocus(passwordNode),
      ),
      Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            child: Stack(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    SizedBox(height: 20),
                    Obx(
                      () => Container(
                        padding:
                            EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                        decoration: BoxDecoration(
                          border: Border.all(color: Color(0xfff4f5fe)),
                          color: Color(0xfff4f5fe),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: CustomDropDownMenu(
                            value: controller.selectedGender.value,
                            itemList: controller.genderList,
                            onChanged: (value) {
                              controller.updateGender(value);
                            }),
                      ),
                    ),
                  ],
                ),
                // Positioned(
                //   top: 15,
                //   left: 8,
                //   child: Container(
                //     padding: EdgeInsets.symmetric(horizontal: 6),
                //     color: Colors.transparent,
                //     child: Text(
                //       LocaleKeys.labels_gender.tr,
                //       style: Get.textTheme.bodyText2
                //           .copyWith(fontSize: 12, color: Get.theme.accentColor),
                //     ),
                //   ),
                // ),
              ],
            ),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Stack(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    SizedBox(height: 20),
                    Obx(
                      () => GestureDetector(
                        onTap: () {
                          DatePicker.showDatePicker(context,
                              theme: DatePickerTheme(
                                cancelStyle: Get.textTheme.headline5
                                    .copyWith(color: Get.theme.accentColor),
                                doneStyle: Get.textTheme.headline5
                                    .copyWith(color: Get.theme.primaryColor),
                                containerHeight: Get.height * 0.2,
                                itemHeight: 40,
                                itemStyle: Get.textTheme.bodyText2
                                    .copyWith(fontSize: getResponsiveFont(16)),
                              ),
                              showTitleActions: true,
                              minTime: DateTime(1940, 3, 5),
                              maxTime: DateTime.now().add(Duration(days: -365 * 18)), onConfirm: (date) {
                            controller.updateDob(date);
                          },
                              onCancel: () {},
                              currentTime: controller.dob != null
                                  ? controller.dob
                                  : DateTime.now().add(Duration(days: -365 * 18)),
                              locale: LocaleType.en);
                        },
                        child: Container(
                          padding:
                              EdgeInsets.symmetric(vertical: 18, horizontal: 8),
                          decoration: BoxDecoration(
                            color: Color(0xfff4f5fe),
                            border: Border.all(color: Color(0xfff4f5fe)),
                            borderRadius: BorderRadius.circular(10),
                          ),
                          child: Text('${controller.dateOfBirth}', style:  Theme.of(context).textTheme.bodyText2.copyWith(
                            fontSize: getResponsiveFont(16),
                            color: Colors.black,
                            letterSpacing: 1.0,
                            fontWeight: FontWeight.w600,
                          ),),
                        ),
                      ),
                    ),
                  ],
                ),
                // Positioned(
                //   top: 15,
                //   left: 8,
                //   child: Container(
                //     padding: EdgeInsets.symmetric(horizontal: 6),
                //     color: Colors.white,
                //     child: Text(
                //       LocaleKeys.labels_dob.tr,
                //       style: Get.textTheme.bodyText2
                //           .copyWith(fontSize: 12, color: Get.theme.accentColor),
                //     ),
                //   ),
                // ),
              ],
            ),
          ),
        ],
      ),
    ]);
  }
}
