import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/enums/bottom_navbar_enum.dart';
import 'package:puryaideu/app/modules/dashboard/controllers/dashboard_controller.dart';
import 'package:puryaideu/generated/locales.g.dart';

import 'bottom_navbar_item.dart';

class CustomNavigationBar extends GetView<DashboardController> {

  @override
  Widget build(BuildContext context) {
    return Obx(
          () => Container(
        decoration: BoxDecoration(color: Colors.white,),
        //     boxShadow: [
        //   BoxShadow(
        //       color: Colors.black.withOpacity(0.2),
        //       blurRadius: 5,
        //       spreadRadius: 2
        //     ),
        // ]),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [
            Expanded(
              child: BottomNavBarItem(
                icon: Icons.home,
                title: LocaleKeys.bottom_navigation_items_home.tr,
                color: controller.selectedTab.value ==
                    BottomNavBarEnum.HOME
                    ? Get.theme.primaryColor
                    : Colors.black.withOpacity(0.5),
                onTap: () {
                  controller.selectedTab.value =
                      BottomNavBarEnum.HOME;
                  controller.currentPage.value = 0;
                  // bottomNavbarController.movePage();
                },
              ),
            ),
            Expanded(
              child: BottomNavBarItem(
                icon: Icons.notifications,
                title: LocaleKeys.bottom_navigation_items_notifications.tr,
                color: controller.selectedTab.value ==
                    BottomNavBarEnum.NOTIFICATIONS
                    ? Get.theme.primaryColor
                    : Colors.black.withOpacity(0.5),
                onTap: () {
                  controller.selectedTab.value =
                      BottomNavBarEnum.NOTIFICATIONS;
                  controller.currentPage.value = 1;
                  // bottomNavbarController.movePage();
                },
              ),
            ),
            Expanded(
              child: BottomNavBarItem(
                icon: Icons.history,
                title: LocaleKeys.bottom_navigation_items_history.tr,
                color: controller.selectedTab.value ==
                    BottomNavBarEnum.HISTORY
                    ? Get.theme.primaryColor
                    : Colors.black.withOpacity(0.5),
                onTap: () {
                  controller.selectedTab.value =
                      BottomNavBarEnum.HISTORY;
                  controller.currentPage.value = 2;
                  // bottomNavbarController.movePage();
                },
              ),
            ),
            Expanded(
              child: BottomNavBarItem(
                icon: Icons.settings,
                title: LocaleKeys.bottom_navigation_items_settings.tr,
                color: controller.selectedTab.value ==
                    BottomNavBarEnum.SETTINGS
                    ? Get.theme.primaryColor
                    : Colors.black.withOpacity(0.5),
                onTap: () {
                  controller.selectedTab.value =
                      BottomNavBarEnum.SETTINGS;
                  controller.currentPage.value = 3;
                  // bottomNavbarController.movePage();
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
