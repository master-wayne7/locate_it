import 'package:flutter/material.dart';

class BottomNavBarItem extends StatelessWidget {
  final Function onTap;
  final IconData icon;
  final String title;
  final Color color;

  BottomNavBarItem(
      {@required this.onTap,
        @required this.icon,
        @required this.title,
        this.color});

  @override
  Widget build(BuildContext context) {
    return Material(
      child: InkWell(
        onTap: onTap,
        child: Container(
          padding: EdgeInsets.symmetric(vertical: 8),
          child: Column(
            children: [
              Icon(
                icon,
                color: color,
              ),
              Text(
                title,
                style: Theme.of(context).textTheme.bodyText2.copyWith(color: color),
              ),
            ],
          ),
        ),
      ),
    );
  }
}