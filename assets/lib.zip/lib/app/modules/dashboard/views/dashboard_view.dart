import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

import 'package:get/get.dart';
import 'package:motion_tab_bar_v2/motion-badge.widget.dart';
import 'package:motion_tab_bar_v2/motion-tab-bar.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/enums/bottom_navbar_enum.dart';
import 'package:puryaideu/app/modules/history/views/history_view.dart';
import 'package:puryaideu/app/modules/home/views/home_view.dart';
import 'package:puryaideu/app/modules/notifications/views/notifications_view.dart';
import 'package:puryaideu/app/modules/profile/views/profile_view.dart';
import 'package:puryaideu/app/modules/splash/controllers/all_data_controller.dart';
import 'package:puryaideu/app/widgets/curved_navigation_bar.dart';
import 'package:puryaideu/generated/locales.g.dart';

import '../controllers/dashboard_controller.dart';
import 'custom_nav_bar.dart';

class DashboardView extends GetView<DashboardController> {

   final AllDataController dataController = Get.find();

  final List<Widget> _pages = [
    HomeView(),
    NotificationsView(),
    HistoryView(),
    ProfileView(),
    // PromotionScreen(),
    // HistoryScreen(),
    // SettingsScreen(),
  ];

  final iconList = <IconData>[
    Icons.brightness_5,
    Icons.brightness_4,
    Icons.brightness_6,
    Icons.brightness_7,
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      //   bottomNavigationBar: Obx(
      // () => SlidingClippedNavBar(
      //   backgroundColor: Colors.white,
      //   inactiveColor: Get.theme.primaryColor,
      //   onButtonPressed: (index) {
      //     //Handle button tap
      //     switch (index) {
      //       case 0:
      //
      //         controller.selectedTab.value =
      //             BottomNavBarEnum.HOME;
      //         controller.currentPage.value = 0;
      //         break;
      //       case 1:
      //
      //         controller.selectedTab.value =
      //             BottomNavBarEnum.NOTIFICATIONS;
      //         controller.currentPage.value = 1;
      //         break;
      //       case 2:
      //
      //         controller.selectedTab.value =
      //             BottomNavBarEnum.HISTORY;
      //         controller.currentPage.value = 2;
      //         break;
      //       case 3:
      //
      //         controller.selectedTab.value =
      //             BottomNavBarEnum.SETTINGS;
      //         controller.currentPage.value = 3;
      //         break;
      //     }
      //
      //
      //   },
      //   iconSize: 30,
      //   activeColor: Get.theme.accentColor,
      //   selectedIndex: controller.currentPage.value,
      //   barItems: [
      //     BarItem(
      //       icon: Icons.home,
      //       title: 'Home',
      //     ),
      //     BarItem(
      //       icon: Icons.notifications,
      //       title: 'Notifications',
      //     ),
      //     BarItem(
      //       icon: Icons.history,
      //       title: 'History',
      //     ),
      //     BarItem(
      //       icon: Icons.person_rounded,
      //       title: 'Profile',
      //     ),
      //     /// Add more BarItem if you want
      //   ],
      // ),),
      //   floatingActionButton: FloatingActionButton(
      //     //params
      //   ),
      //   floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: MotionTabBar(
        initialSelectedTab: "Home",
        labels: const ["Home", "Notifications", "History", "Profile"],
        icons: const [
          Icons.home,
          Icons.notifications,
          Icons.history,
          Icons.people_rounded,
        ],
        badges: [
          const MotionBadgeWidget(
            textColor: Colors.white, // optional, default to Colors.white
            color: Colors.red, // optional, default to Colors.red
            size: 18, // optional, default to 18
          ),

          Container(

          ),

          null,

          const MotionBadgeWidget(
            isIndicator: true,
            color: Colors.red, // optional, default to Colors.red
            size: 5, // optional, default to 5,
            show: true, // true / false
          ),
        ],
        tabSize: 50,
        tabBarHeight: 55,
        textStyle:  TextStyle(
          fontSize: getResponsiveFont(12),
          color: Colors.black,
          fontWeight: FontWeight.w600,
        ),
        tabIconColor: Get.theme.primaryColor,
        tabIconSize: 28.0,
        tabIconSelectedSize: 26.0,
        tabSelectedColor: Get.theme.primaryColor,
        tabIconSelectedColor: Colors.white,
        tabBarColor: Colors.white,
        onTabItemSelected: (index) {
          //Handle button tap
          switch (index) {
            case 0:
              controller.selectedTab.value = BottomNavBarEnum.HOME;
              controller.currentPage.value = 0;
              break;
            case 1:
              controller.selectedTab.value = BottomNavBarEnum.NOTIFICATIONS;
              controller.currentPage.value = 1;
              break;
            case 2:
              controller.selectedTab.value = BottomNavBarEnum.HISTORY;
              controller.currentPage.value = 2;
              break;
            case 3:
              controller.selectedTab.value = BottomNavBarEnum.SETTINGS;
              controller.currentPage.value = 3;
              break;
          }
        },
      ),
      body: Stack(
        children: [
          Obx(
            () => IndexedStack(
              children: _pages,
              index: controller.currentPage.value,
            ),
          ),
          Obx(
            () => controller.showLocationRequestDialog
                ? Container(
                    color: Colors.black.withOpacity(0.5),
                    padding: EdgeInsets.symmetric(
                        horizontal: Get.width * 0.05,
                        vertical: Get.height * 0.13),
                    child: Container(
                      color: Colors.white,
                      padding:
                          EdgeInsets.symmetric(horizontal: 16, vertical: 24),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Image.asset(
                            'assets/location_permission.png',
                            fit: BoxFit.cover,
                            width: Get.width,
                          ),
                          Expanded(child: Container()),
                          Text(LocaleKeys.text_location_permission_message.tr,
                              style: Get.textTheme.bodyText2
                                  .copyWith(fontSize: getResponsiveFont(12))),
                          SizedBox(height: Get.height * 0.05),
                          GestureDetector(
                            onTap: () {
                              controller.setShowLocationRequestStatus(false);
                              controller.startLocationPermission();
                            },
                            child: Text(
                              LocaleKeys.buttons_try_again.tr,
                              style: Get.textTheme.headline5.copyWith(
                                color: Get.theme.primaryColor,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  )
                : Container(),
          ),

          // Positioned(
          //     bottom: 0,
          //     child: CurvedNavigationBar(
          //       items: <Widget>[
          //         Icon(Icons.home, size: 30, color: controller.selectedTab.value ==
          //             BottomNavBarEnum.HOME
          //             ? Colors.white
          //             : Colors.white),
          //         Icon(Icons.notifications, size: 30, color: controller.selectedTab.value ==
          //             BottomNavBarEnum.NOTIFICATIONS
          //             ? Colors.white
          //             : Colors.white),
          //         Icon(Icons.history, size: 30, color:controller.selectedTab.value ==
          //             BottomNavBarEnum.HISTORY
          //             ? Colors.white
          //             : Colors.white),
          //         Icon(Icons.settings, size: 30, color: controller.selectedTab.value ==
          //             BottomNavBarEnum.SETTINGS
          //             ? Colors.white
          //             : Colors.white),
          //       ],
          //       onTap: (index) {
          //         //Handle button tap
          //         switch (index) {
          //           case 0:
          //             controller.selectedTab.value =
          //                 BottomNavBarEnum.HOME;
          //             controller.currentPage.value = 0;
          //             break;
          //           case 1:
          //             controller.selectedTab.value =
          //                 BottomNavBarEnum.NOTIFICATIONS;
          //             controller.currentPage.value = 1;
          //             break;
          //           case 2:
          //             controller.selectedTab.value =
          //                 BottomNavBarEnum.HISTORY;
          //             controller.currentPage.value = 2;
          //             break;
          //           case 3:
          //             controller.selectedTab.value =
          //                 BottomNavBarEnum.SETTINGS;
          //             controller.currentPage.value = 3;
          //             break;
          //         }
          //       },
          //     )),
        ],
      ),
    );
  }
}
