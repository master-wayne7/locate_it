import 'dart:async';
import 'dart:core';
import 'dart:core';

import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/data/models/booking.dart';
import 'package:puryaideu/app/data/network/promo_request.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/data/repositories/booking_repository.dart';
import 'package:puryaideu/app/data/repositories/rider_repository.dart';
import 'package:puryaideu/app/data/repositories/user_repository.dart';
import 'package:puryaideu/app/data/services/location_address.dart';
import 'package:puryaideu/app/enums/bottom_navbar_enum.dart';
import 'package:puryaideu/app/data/services/location_fetcher.dart';
import 'package:puryaideu/app/routes/app_pages.dart';
import 'package:puryaideu/app/utils/location_permission_helper.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:shared_preferences/shared_preferences.dart';

class DashboardController extends GetxController {
  final selectedTab = BottomNavBarEnum.HOME.obs;
  final currentPage = 0.obs;
  PageController _pageController;
  final _showLocationRequestDialog = false.obs;
  String errorMessage;
  Booking booking;
  String currentPlaceName;

  final listOfValidDistricts = [
    'lumbini',
    'biratnagar',
    'jhapa',
    'morang',
    'chitwan'
  ];

  bool get showLocationRequestDialog => _showLocationRequestDialog.value;

  PageController get pageController => _pageController;

  @override
  onInit() {
    super.onInit();
    //getPromoCarousel();
    startLocationPermission();
    startSettingListener();
    checkPendingPayment();
    getActiveBooking();
    PageController(initialPage: 0, keepPage: true);
  }

  void setShowLocationRequestStatus(bool status) =>
      _showLocationRequestDialog.value = status;

  startSettingListener() async {
    StreamSubscription<ServiceStatus> serviceStatusStream =
        Geolocator.getServiceStatusStream().listen((ServiceStatus status) {
      if (status.toString() == 'ServiceStatus.enabled') {
        startLocationPermission();
      }
    });
  }

  Future<Position> determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }
    return await Geolocator.getCurrentPosition();
  }

  startLocationPermission() async {
    // bool locationPermissionStatus =
    //     await LocationPermissionHelper.isPermissionEnabled();
    // if (!locationPermissionStatus) setShowLocationRequestStatus(true);
    // final _locationData = await LocationFetcher.determinePosition();
    // await SessionManager.instance.setCurrentLocation(_locationData);
    try {
      final currentPosition = await determinePosition();
      if (currentPosition != null && currentPosition is Position) {
        SessionManager.instance.setCurrentLocation(
            LatLng(currentPosition.latitude, currentPosition.longitude));
        print("Location data ${currentPosition}");
        LocationAddress.getCityFromCoordinates(
                LatLng(currentPosition.longitude, currentPosition.latitude))
            .then((value) async {
          SharedPreferences sharedPreferences =
              await SharedPreferences.getInstance();
          UserRepository userRepository =
              UserRepository(prefs: sharedPreferences);
          userRepository.setCityName(value);
          String cityName = await userRepository.getCityName();
          print('City name: ' + cityName);
          if (listOfValidDistricts.contains(cityName.toLowerCase())) {
            print('This region contains city safari');
            userRepository.setCitySafariStatus(true);
            SessionManager.instance.setCitySafariArea(true);
          } else {
            print('This region does not contain city safari');
            userRepository.setCitySafariStatus(false);
            SessionManager.instance.setCitySafariArea(false);
          }
        });
      }
    } catch (e) {
      print('Exception is ${e}');
      if (e
          .toString()
          .contains('Location permissions are permanently denied')) {
        CustomSnackbar.showCustomSnackBar(
            message:
                "Location permissions are permanently denied. Please enable to continue using the ride-hailing services.");
        // Future.delayed(Duration(seconds: 3));
        // await Geolocator.openLocationSettings();
        // await startLocationPermission();
      }
    }
  }

  @override
  void onClose() {}

  void getActiveBooking() async {
    final response =
        await BookingRepository.getActiveBooking().catchError((error) {
      errorMessage = "No active booking. Please try again!";
    });
    if (response == null) {
      CustomSnackbar.showCustomSnackBar(message: errorMessage);
      return;
    }
    if (response.id == -1) {
      return;
    }
    booking = response;
    Get.toNamed(Routes.TRIP, arguments: booking);
  }

  void checkPendingPayment() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    UserRepository userRepository = UserRepository(prefs: sharedPreferences);
    print('checking pending payment');
    String paymentStatus = await userRepository.getPaymentStatus();
    print('Payment status is $paymentStatus');
    if (paymentStatus == 'unpaid') {
      String bookingId = await userRepository.getBookingId();
      String paymentId = await userRepository.getPaymentId();
      String riderId = await userRepository.getRiderId();
      String completedTripId = await userRepository.getCompletedTripId();

      print("Booking id is === $bookingId");
      print("payment id is === $paymentId");
      print("Rider id  id is === $riderId");

      final response =
          await BookingRepository.getPaymentByID(int.parse(bookingId))
              .catchError((error) {
        errorMessage = "Payment data could not be fetched. Please try again!";
      });

      if (response.customerPaymentStatus == "paid") {
        userRepository.setPaymentStatus("paid");
        return;
      }

      final data = await RiderRepository.getRiderDetail(int.parse(riderId))
          .catchError((error) {
        errorMessage = "Rider data could not be fetched. Please try again.";
      });

      SessionManager.instance.setRider(data);

      await BookingRepository.getCompletedTripByID(int.parse(completedTripId))
          .then((value) =>
              Get.toNamed(Routes.PAYMENT_OPTIONS, arguments: [value]));
      ;

      final status =
          await BookingRepository.getBookingById(int.parse(bookingId))
              .catchError((error) {
        errorMessage = "Booking data could not be fetched. Please try again!";
      });

      SessionManager.instance.setBooking(status);
    }
  }
}
