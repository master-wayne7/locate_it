import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/generated/locales.g.dart';

class ProceedButton extends StatelessWidget {

  final Function onPressed;

  ProceedButton({@required this.onPressed});

  @override
  Widget build(BuildContext context) {
    return ElevatedButton.icon(
      style: ButtonStyle(
        shape: MaterialStateProperty.all<OutlinedBorder>(
          RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(15),
          ),
        ),
        padding: MaterialStateProperty.all<EdgeInsetsGeometry>(
          EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        ),
        backgroundColor: MaterialStateProperty.all<Color>(Get.theme.primaryColor),
        elevation: MaterialStateProperty.all<double>(2),
      ),
      onPressed: onPressed,
      
      icon: Text(
        LocaleKeys.buttons_next.tr,
        style: Get.textTheme.headline5.copyWith(fontSize: getResponsiveFont(14), color: Colors.white),
      ),
      label: Icon(
        Icons.arrow_forward,
        color: Colors.white,
      ),
    );
  }
}

