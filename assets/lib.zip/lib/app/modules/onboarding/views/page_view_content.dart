import 'package:flutter/material.dart';

import './onboarding_content.dart';

class PageViewContent extends StatelessWidget {
  final Function onPageChanged;
  final PageController pageController;

  PageViewContent({this.onPageChanged, this.pageController});

  @override
  Widget build(BuildContext context) {
    return PageView(
      onPageChanged: onPageChanged,
      controller: pageController,
      children: <Widget>[
        OnBoardingContent(
          heading: 'Select Destination',
          content: 'Taxi, Bike, Tempo, whichever you feel comfortable',
          imageUrl: 'assets/onboard2.png',
        ),
        OnBoardingContent(
          heading: 'Fast Response',
          content: 'How far is my rider? Estimated rider time and distance are displayed.',
          imageUrl: 'assets/onboard3.png',
        ),
        OnBoardingContent(
          heading: 'Enjoy The Ride',
          content: '“Life is for service.” – Fred Rogers',
          imageUrl: 'assets/onboard1.png',
        ),
      ],
    );
  }
}
