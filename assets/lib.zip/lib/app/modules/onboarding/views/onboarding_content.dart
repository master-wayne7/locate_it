import 'package:flutter/material.dart';
import 'package:puryaideu/app/config/theme.dart';

class OnBoardingContent extends StatelessWidget {
  final String heading;
  final String content;
  final String imageUrl;

  OnBoardingContent(
      {@required this.heading,
      @required this.content,
      @required this.imageUrl});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      physics:NeverScrollableScrollPhysics(),
      child: Container(
        padding: EdgeInsets.all(22),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceAround,
          children: [

            Image.asset(
              imageUrl,
              fit: BoxFit.cover,
            ),
            SizedBox(height: 16),
            Text(
              heading,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.headline6.copyWith(
                color: Theme.of(context).primaryColor,
                fontSize: getResponsiveFont(30),
              ),
            ),
            SizedBox(height: 16),
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 16),
              child: Text(content,
                  textAlign: TextAlign.center,
                  style:
                      Theme.of(context).textTheme.bodyText2.copyWith(fontSize: getResponsiveFont(16))),
            ),
          ],
        ),
      ),
    );
  }
}
