import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/enums/location_type.dart';
import 'package:puryaideu/app/modules/profile/controllers/saved_location_map_controller.dart';
import 'package:puryaideu/app/modules/profile/views/personal_location_map_container.dart';
import 'package:puryaideu/app/widgets/current_location_button.dart';
import 'package:puryaideu/app/widgets/custom_button.dart';
import 'package:puryaideu/app/widgets/custom_progress_bar.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:shimmer/shimmer.dart';

import 'custom_location_text.dart';
import 'my_location_button.dart';

class SavedLocationMapScreen extends GetView<SavedLocationMapController> {
  final LatLng location;
  final String locationName;
  final LocationType locationType;

  SavedLocationMapScreen({this.location, this.locationName, this.locationType});

  @override
  Widget build(BuildContext context) {
    if (location != null) {
      controller.updateLocationAndAddress(location, locationName, locationType);
    }
    return Scaffold(
      body: SafeArea(
        child: GetBuilder<SavedLocationMapController>(
          builder: (controller) => Stack(
            children: [
              PersonalLocationMapContainer(),
              Positioned(
                top:8,
                left:8,
                child: Padding(
                  padding: const EdgeInsets.only(right: 16, bottom: 16),
                  child: CircleAvatar(
                    backgroundColor: Colors.white,
                    child: IconButton(
                        icon: Icon(Icons.arrow_back_rounded, color: Colors.black),
                        onPressed: (){
                          Get.back();
                        }),
                  ),
                ),
              ),
              Center(
                child: Container(
                  padding: EdgeInsets.only(
                    bottom: 30,
                  ),
                  child: Image.asset(
                    'assets/pin.png',
                    height: 40,
                    width: 40,
                  ),
                ),
              ),
              Positioned(
                bottom: 0,
                child: Container(
                  width: Get.width,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      CurrentLocationButton(
                        onPressed: () {
                          controller.moveToCurrentLocation();
                        },
                      ),
                      Card(
                        margin: EdgeInsets.zero,
                        shape: RoundedRectangleBorder(),
                        child: Container(
                          padding: EdgeInsets.all(16),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.stretch,
                            children: [
                              Text(
                                'Update Home Location',
                                style: Get.textTheme.headline6.copyWith(
                                    color: Get.theme.primaryColor,
                                    fontSize: getResponsiveFont(20),
                                    fontWeight: FontWeight.w600),
                              ),
                              SizedBox(height: 16),
                              Container(
                                color: Get.theme.primaryColor.withOpacity(0.15),
                                padding: EdgeInsets.symmetric(
                                    horizontal: 16, vertical: 8),
                                child: Row(
                                  children: [
                                    Icon(Icons.location_pin,
                                        color: Get.theme.primaryColor),
                                    SizedBox(width: 16),
                                    Expanded(
                                      child: Text(
                                        controller.lastPlaceName,
                                        maxLines: 1,
                                        style: Get.textTheme.bodyText2.copyWith(
                                            color: Colors.grey[800],
                                            fontSize: getResponsiveFont(15),
                                            fontWeight: FontWeight.w500),
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: 16),
                              Obx(() => controller.saveLocationButton.value
                                  ? CustomButton(
                                      backgroundColor: Get.theme.primaryColor,
                                      onPressed: () async {
                                        controller.saveLocationButton.value = false;
                                        final status = await controller
                                            .updateSavedAddress();

                                        print('Status here is  $status');
                                        if (status) {

                                          Get.back();
                                          controller.saveLocationButton.value = true;
                                          CustomSnackbar.showCustomSnackBar(
                                              message:
                                                  'Saved location updated.'
                                                      .tr);

                                        }else{
                                          controller.saveLocationButton.value = true;
                                        }

                                      },
                                      text: 'Update')
                                  : Shimmer.fromColors(
                                      baseColor: Colors.white,
                                      highlightColor: Get.theme.primaryColor
                                          .withOpacity(0.4),
                                      enabled: true,
                                      child: CustomButton(
                                          backgroundColor: controller
                                                  .saveLocationButton.value
                                              ? Get.theme.primaryColor
                                              : Colors.grey,
                                          onPressed: () {},
                                          text: 'Set'),
                                    )),
                            ],
                          ),
                        ),
                      ),
                      // Padding(
                      //   padding: EdgeInsets.only(right: 16, left: 16, bottom: 16),
                      //   child: CustomButton(
                      //     backgroundColor: Get.theme.accentColor,
                      //     onPressed: () async {
                      //       if (controller.locationType.value ==
                      //           LocationType.PICKUP) {
                      //         controller.setPickupLocation();
                      //         if (controller.destinationLocation == null) {
                      //           Get.to(UserLocationInputScreen());
                      //         }
                      //       } else if (controller.locationType.value ==
                      //           LocationType.HOME) {
                      //         // final status =
                      //         // await controller.saveHomeAndWorkLocaton();
                      //         // if (!status) {
                      //         //   CustomSnackbar.showCustomSnackBar(
                      //         //       message: '${controller.errorMessage}');
                      //         // }
                      //         Get.to(UserLocationInputScreen());
                      //       } else if (controller.locationType.value ==
                      //           LocationType.WORK) {
                      //         // final status =
                      //         // await controller.saveHomeAndWorkLocaton();
                      //         // if (!status) {
                      //         //   CustomSnackbar.showCustomSnackBar(
                      //         //       message: '${controller.errorMessage}');
                      //         // }
                      //         Get.to(UserLocationInputScreen());
                      //       } else {
                      //         controller.addDestinationLocation();
                      //       }
                      //     },
                      //     text: controller.locationType.value == LocationType.PICKUP
                      //         ? LocaleKeys.buttons_set_pickup.tr
                      //         : (controller.locationType.value ==
                      //                 LocationType.DESTINATION
                      //             ? LocaleKeys.buttons_set_destination.tr
                      //             : controller.locationType.value ==
                      //                     LocationType.HOME
                      //                 ? LocaleKeys.buttons_set_home.tr
                      //                 : LocaleKeys.buttons_set_work.tr),
                      //   ),
                      // ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
