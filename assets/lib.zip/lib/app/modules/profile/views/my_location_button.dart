import 'package:flutter/material.dart';

class MyLocationButton extends StatelessWidget {

  final Function onPressed;

  MyLocationButton({this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(),
        Padding(
          padding: const EdgeInsets.only(right: 16, bottom: 16),
          child: CircleAvatar(
            backgroundColor: Colors.white,
            child: IconButton(
                icon: Icon(Icons.my_location, color: Colors.black),
                onPressed: onPressed),
          ),
        ),
      ],
    );
  }
}
