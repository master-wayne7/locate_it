import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/enums/progress_status.dart';
import 'package:puryaideu/app/modules/profile/views/user_detail_card.dart';
import 'package:puryaideu/app/modules/profile/views/wallet_and_distance_card.dart';
import 'package:puryaideu/app/routes/app_pages.dart';
import 'package:puryaideu/app/widgets/custom_progress_bar.dart';
import 'package:puryaideu/app/widgets/profile_page_shimmer.dart';
import 'package:puryaideu/generated/locales.g.dart';

import '../controllers/profile_controller.dart';
import 'logout_card.dart';
import 'main_settings_card.dart';

class ProfileView extends GetView<ProfileController> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffeeeff3),
      appBar: AppBar(
      systemOverlayStyle: SystemUiOverlayStyle.dark,
      title: GestureDetector(
        onTap: () {
          controller.getEmergencyContacts();
        },
        child: Text(
          LocaleKeys.text_profile.tr,
          style: Get.textTheme.headline5.copyWith(
              color: Get.theme.primaryColor,
              fontFamily: 'Roboto',
              fontSize: getResponsiveFont(20),
              fontWeight: FontWeight.w600),
        ),
      ),

      centerTitle: true,
      backgroundColor: Colors.white,
      elevation: 0.6,
      actions: [
        IconButton(
            onPressed: () {
              controller.getUserDetail();
              controller.getEmergencyContacts();
              controller.getTotalDistance();
              controller.getTotalTrips();
            },
            icon: Icon(Icons.refresh, color: Get.theme.primaryColor)),
      ],
    ),
      body: SafeArea(child: Obx(() {
        switch (controller.progressStatus.value) {
          case ProgressStatus.LOADING:
            return Container (height: Get.height, child: ProfilePageShimmer());

          case ProgressStatus.ERROR:
            return Center(
              child: Padding(
                padding: EdgeInsets.all(getResponsiveFont(16)),
                child: Text(
                  controller.errorMessage,
                  style: Get.textTheme.headline5,
                ),
              ),
            );

          case ProgressStatus.SUCCESS:
            break;
        }
        return SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              UserDetailCard(
                  user: controller.user.value,
                  onPressed: () {
                    Get.toNamed(Routes.PROFILE_EDIT);
                  }),
              WalletAndDistanceCard(),
              MainSettingsCard(),
              SizedBox(height: 1),
              LogoutCard(),
            ],
          ),
        );
      })),
    );
  }
}
