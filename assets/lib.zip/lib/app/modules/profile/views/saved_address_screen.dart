import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/data/services/location_address.dart';
import 'package:puryaideu/app/data/services/location_fetcher.dart';
import 'package:puryaideu/app/enums/location_type.dart';
import 'package:puryaideu/app/modules/profile/controllers/saved_location_map_controller.dart';
import 'package:puryaideu/generated/locales.g.dart';

import 'saved_location_map_screen.dart';

class SavedAddressScreen extends StatelessWidget {
  final SavedLocationMapController savedLocationMapController =
      Get.put(SavedLocationMapController());

  String homeAddress, workAddress;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        leading: GestureDetector(
            onTap: () => Get.back(),
            child: Icon(Icons.arrow_back_ios, color: Colors.black)),
        title: Text(
          'Saved Addresses',
          style: Get.textTheme.headline6,
        ),
        backgroundColor: Colors.white,
      ),
      body: SafeArea(
        child: Container(
          child: Column(
            children: [
              Card(
                margin: EdgeInsets.zero,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
                child: Column(
                  children: [
                    InkWell(
                      onTap: () async {
                        LatLng homeLocation;
                        String address;
                        if (SessionManager.instance.homeLocation == null) {
                          var _locationData =
                              await LocationFetcher.determinePosition();
                          homeLocation = LatLng(
                              _locationData.latitude, _locationData.longitude);
                          address =
                              await LocationAddress.getAddressFromCoordinates(
                                  homeLocation);
                        } else {
                          homeLocation = SessionManager.instance.homeLocation;
                          address = SessionManager.instance.home;
                        }
                        final status = await Get.to(SavedLocationMapScreen(
                          location: homeLocation,
                          locationName: address,
                          locationType: LocationType.HOME,
                        ));
                        if (status != null && status) {
                          Get.back();
                          updateLocation();
                        }
                      },
                      child: Container(
                        padding: EdgeInsets.all(8),
                        margin: EdgeInsets.all(8),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              padding: EdgeInsets.all(4),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: Colors.grey.withOpacity(0.4),
                              ),
                              child: Icon(
                                Icons.home,
                                size: 20,
                              ),
                            ),
                            SizedBox(width: 8),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                      LocaleKeys
                                          .bottom_navigation_items_home.tr,
                                      style: Get.textTheme.headline5.copyWith(
                                          fontSize: getResponsiveFont(14))),
                                  SessionManager.instance.home == null
                                      ? Text('Home address not saved.'.tr,
                                          maxLines: 1,
                                          overflow: TextOverflow.ellipsis,
                                          style: Get.textTheme.bodyText2
                                              .copyWith(
                                                  fontSize:
                                                      getResponsiveFont(12),
                                                  color: Colors.grey))
                                      : Row(
                                          children: [
                                            Expanded(
                                              child: Text(
                                                  SessionManager.instance.home
                                                      .toString(),
                                                  maxLines: 1,
                                                  overflow:
                                                      TextOverflow.ellipsis,
                                                  style: Get.textTheme.bodyText2
                                                      .copyWith(
                                                          fontSize:
                                                              getResponsiveFont(
                                                                  14),
                                                          color: Colors.grey)),
                                            ),
                                          ],
                                        ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    Container(
                      height: 1,
                      margin: EdgeInsets.symmetric(horizontal: 16),
                      color: Colors.grey.withOpacity(0.3),
                    ),
                    InkWell(
                      onTap: () async {
                        LatLng workLocation;
                        String address;
                        if (SessionManager.instance.workLocation == null) {
                          var _locationData =
                              await LocationFetcher.determinePosition();
                          workLocation = LatLng(
                              _locationData.latitude, _locationData.longitude);
                          address =
                              await LocationAddress.getAddressFromCoordinates(
                                  workLocation);
                        } else {
                          workLocation = SessionManager.instance.workLocation;
                          address = SessionManager.instance.work;
                        }
                        final status = await Get.to(SavedLocationMapScreen(
                          location: workLocation,
                          locationName: address,
                          locationType: LocationType.WORK,
                        ));
                        if (status != null && status) {
                          updateLocation();
                        }
                      },
                      child: Container(
                        padding: EdgeInsets.all(8),
                        margin: EdgeInsets.all(8),
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Container(
                              padding: EdgeInsets.all(4),
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(30),
                                color: Colors.grey.withOpacity(0.4),
                              ),
                              child: Icon(
                                Icons.work,
                                size: 20,
                              ),
                            ),
                            SizedBox(width: 8),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text('Work',
                                      style: Get.textTheme.headline5.copyWith(
                                          fontSize: getResponsiveFont(14))),
                                  Text(
                                      // 'Work Address',
                                      SessionManager.instance.work == null
                                          ? 'Work address not saved.'.tr
                                          : SessionManager.instance.work,
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: Get.textTheme.bodyText2.copyWith(
                                          fontSize: getResponsiveFont(12),
                                          color: Colors.grey)),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void updateLocation() {
    homeAddress = SessionManager.instance.home;
    workAddress = SessionManager.instance.work;
    //setState(() {});
  }
}
