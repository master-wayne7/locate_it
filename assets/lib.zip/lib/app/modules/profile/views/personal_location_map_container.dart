import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/modules/profile/controllers/saved_location_map_controller.dart';
class PersonalLocationMapContainer extends StatefulWidget {

  @override
  _PersonalLocationMapContainerState createState() =>
      _PersonalLocationMapContainerState();
}

class _PersonalLocationMapContainerState
    extends State<PersonalLocationMapContainer> with WidgetsBindingObserver {
  SavedLocationMapController savedLocationMapController = Get.find();

  @override
  void initState() {
    WidgetsBinding.instance.addObserver(this);
    super.initState();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      savedLocationMapController.updateMapStyle();
    }
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<SavedLocationMapController>(
      builder: (_savedLocationMapController) => GoogleMap(
        initialCameraPosition: CameraPosition(
            zoom: 15, target: SessionManager.instance.currentLocation),
        myLocationEnabled: true,
        myLocationButtonEnabled: false,
        onCameraMove: (data) {
          _savedLocationMapController.updateLastCameraLocation(
              LatLng(data.target.latitude, data.target.longitude));
          _savedLocationMapController.updatePlaceName('Searching....'.tr);
        },
        onCameraIdle: () async {
          _savedLocationMapController.fetchNameFromCoordinates(
              _savedLocationMapController.lastCameraLocation);
        },
        compassEnabled: false,
        mapType: MapType.normal,
        zoomGesturesEnabled: true,
        // polygons: PolygonPoints.myPolygon(),
        zoomControlsEnabled: false,
        markers: _savedLocationMapController.markers,
        onMapCreated: (GoogleMapController controller) {
          _savedLocationMapController.updateMapController(controller);
        },
      ),
    );
  }
}
