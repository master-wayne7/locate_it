import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/enums/ride_type.dart';
import 'package:puryaideu/app/modules/document/views/document_view.dart';
import 'package:puryaideu/app/modules/profile/controllers/profile_controller.dart';
import 'package:puryaideu/app/modules/profile/views/saved_address_screen.dart';
import 'package:puryaideu/app/routes/app_pages.dart';
import 'package:puryaideu/generated/locales.g.dart';
import './../../../widgets/icon_text_button.dart';
import 'language_screen.dart';
import 'promotion_screen.dart';

class MainSettingsCard extends GetView<ProfileController> {

  @override
  Widget build(BuildContext context) {
    return Card(
      color:Colors.white,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      child: Column(
        children: [
          // IconTextButton(
          //   icon: Icons.payment,
          //   title: LocaleKeys.settings_top_up_payment.tr,
          //   onTap: () {
          //     // controller.topUpWallet();
          //   },
          // ),

          IconTextButton(
            icon: Icons.location_pin,
            title: 'Saved Address',
            onTap: () {
              Get.to(SavedAddressScreen());

            },
          ),
          // IconTextButton(
          //   icon: Icons.payment,
          //   title: 'Promotion Voucher',
          //   onTap: () {
          //     // controller.topUpWallet();
          //     Get.to(PromotionScreen());
          //   },
          // ),
          IconTextButton(
            icon: Icons.money_outlined,
            title: "Emergency Contacts",
            onTap: () {
              Get.toNamed(Routes.DOCUMENT);
            },
          ),
          IconTextButton(
            icon: Icons.language_outlined,
            title: "Language".tr,
            onTap: () {
              Get.to(LanguageScreen());
            },
          ),
          IconTextButton(
            icon: Icons.info_outline,
            title: LocaleKeys.settings_about.tr,
            onTap: () {},
          ),
        ],
      ),
    );
  }
}
