import 'package:flutter/material.dart';
import 'package:get/get.dart';

class CustomLocationText extends StatelessWidget {

  final String text;

  CustomLocationText({this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      shape:
      RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: Colors.white,
        ),
        child: Text(
          text,
          textAlign: TextAlign.center,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: Get.textTheme.bodyText2.copyWith(fontSize: 12),
        ),
      ),
    );
  }
}