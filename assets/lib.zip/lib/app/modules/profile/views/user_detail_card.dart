import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/data/models/user.dart';
import 'package:puryaideu/generated/locales.g.dart';
import './../../../widgets/icon_text.dart';

class UserDetailCard extends StatelessWidget {
  final User user;
  final Function onPressed;

  UserDetailCard({this.user, this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      margin: EdgeInsets.zero,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
      child: Container(
        margin: EdgeInsets.all(16),
        child: Column(
          children: [
            Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(Get.width * 0.25 / 2),
                  child: CachedNetworkImage(
                    height: Get.width * getResponsiveFont(0.25),
                    width: Get.width * getResponsiveFont(0.25),
                    imageUrl: '$BASE_URL/${user.imagePath}',
                    placeholder: (context, url) => Icon(Icons.person),
                    fit: BoxFit.cover,
                  ),
                ),
                SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('${user.name}',
                          style: Get.textTheme.headline5
                              .copyWith(color: Get.theme.accentColor)),
                      Text(
                        LocaleKeys.text_user.tr,
                        style: Get.textTheme.bodyText2
                            .copyWith(color: Get.theme.primaryColor),
                      ),
                    ],
                  ),
                ),
                SizedBox(width: 16),
                Align(
                  alignment: Alignment.topLeft,
                  child: IconButton(
                    onPressed: onPressed,
                    icon: Icon(
                      Icons.edit,
                      color: Get.theme.primaryColor,
                    ),
                  ),
                ),
              ],
            ),
            SizedBox(height: getResponsiveFont(24)),
            IconText(
              icon: Icons.phone,
              title: user.phone,
            ),
            SizedBox(height: getResponsiveFont(8)),
            IconText(
                icon: Icons.mail_outline,
                title: user.email != '' ? user.email : 'No email found.'),
          ],
        ),
      ),
    );
  }
}
