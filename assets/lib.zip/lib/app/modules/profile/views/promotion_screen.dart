import 'package:flutter/material.dart';
import 'package:get/get.dart';

class PromotionScreen extends StatelessWidget {
  const PromotionScreen({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0.5,
        centerTitle: true,
        leading: GestureDetector(
            onTap: () => Get.back(),
            child: Icon(Icons.arrow_back_ios, color: Colors.black)),
        title: Text(
          'Promotions',
          style: Get.textTheme.headline6,
        ),
        backgroundColor: Colors.white,
      ),
      body: SafeArea(
        child: Container(
          child: Column(
            children: [
            ],
          ),
        ),
      ),
    );
  }
}