import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get/get_utils/src/extensions/internacionalization.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/data/repositories/user_repository.dart';
import 'package:puryaideu/app/routes/app_pages.dart';
import 'package:puryaideu/generated/locales.g.dart';
import 'package:shared_preferences/shared_preferences.dart';
import './../../../widgets/icon_text_button.dart';

class LogoutCard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Card(
        color:Colors.white,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        child: IconTextButton(
          icon: Icons.logout,
          title: LocaleKeys.buttons_log_out.tr,
          titleColor: Theme.of(context).primaryColor,
          iconColor: Theme.of(context).primaryColor,
          onTap: logout,
        ));
  }

  logout() async {
    UserRepository repository =
        UserRepository(prefs: await SharedPreferences.getInstance());
    await repository.logout();
    // GoogleSignIn googleSignIn = GoogleSignIn();
    // googleSignIn.isSignedIn().then((value) => googleSignIn.signOut());
    // FacebookLogin facebookLogin = FacebookLogin();
    // facebookLogin.isLoggedIn.then((value) {
    //   facebookLogin.logOut();
    // });
    SessionManager.instance.setAccessToken(null);
    Get.offAllNamed(Routes.AUTH);
  }
}
