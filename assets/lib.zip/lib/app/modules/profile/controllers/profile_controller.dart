import 'dart:convert';

import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:puryaideu/app/data/models/emergency_contacts.dart';
import 'package:puryaideu/app/data/models/user.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/data/repositories/profile_repository.dart';
import 'package:puryaideu/app/enums/progress_status.dart';
import 'package:puryaideu/app/modules/dashboard/controllers/dashboard_controller.dart';

class ProfileController extends GetxController {
  final user = User().obs;
  final progressStatus = ProgressStatus.LOADING.obs;
  String errorMessage;
  DashboardController _dashboardController;
  final distanceTravelled = "0".obs;
  final totalTrips = "0".obs;

  @override
  void onInit() {
    super.onInit();
    getUserDetail();
    getTotalTrips();
    getTotalDistance();
    getEmergencyContacts();
  }

  setSavedLocation() {
    print('Get saved location');
    if (user.value.location != null) {
      SessionManager.instance.setHomeLocation(LatLng(
          user.value.location.home.latitude == null ? null: user.value.location.home.latitude,
          user.value.location.home.longitude == null ? null : user.value.location.home.longitude));
      SessionManager.instance.setWorkLocation(LatLng(
          user.value.location.work.latitude == null ? null: user.value.location.work.latitude,
          user.value.location.work.longitude == null ? null : user.value.location.work.longitude));
      SessionManager.instance.setWork(user.value.location.work.name == null ? null: user.value.location.work.name);
      SessionManager.instance.setHome(user.value.location.home.name == null ? null: user.value.location.home.name);
    }
  }

  getUserDetail() async {
    progressStatus.value = ProgressStatus.LOADING;
    final response =
        await ProfileRepository.getUserDetailFromServer().catchError((error) {
      errorMessage = "User details are unavailable. Please try again!";
    });
    print('UserDetail $response');

    if (response == null) {
      progressStatus.value = ProgressStatus.ERROR;
    } else {
      user.value = response;
      SessionManager.instance.setUser(response);
      progressStatus.value = ProgressStatus.SUCCESS;
      setSavedLocation();
      return true;
    }
  }

  final emergencyContacts = [].obs;

  Future<bool> getTotalDistance() async {
    final response =
        await ProfileRepository.getTotalDistanceTravelled().catchError((error) {
      errorMessage = error.toString();
    });
    if (response != 0 || response != null) {
      distanceTravelled.value = response;
      return true;
    }
    return false;
  }

  Future<bool> getTotalTrips() async {
    final response =
        await ProfileRepository.getTotalTripsCompleted().catchError((error) {
      errorMessage = error.toString();
    });
    if (response != 0 || response != null) {
      totalTrips.value = response;
      //print('not here');
      return true;
    }
    return false;
  }

  getEmergencyContacts() async {
    final response =
        await ProfileRepository.getEmergencyContacts().catchError((error) {
      errorMessage = "Emergency contacts are unavailable. Please try again!";
    });
    print("emergency response is === $response");
    if (response == null) {
      return;
    } else if (response == true || response == false) {
      return;
    } else {
      List<EmergencyContacts> extraDriverGet =
          (response as List).map((i) => EmergencyContacts.fromJson(i)).toList();
      if((extraDriverGet[0].contact != null)){
        emergencyContacts.value = [];
        emergencyContacts.value = extraDriverGet;
        SessionManager.instance.setContactList(extraDriverGet);
      }
      // EmergencyContacts extraDriverGet = EmergencyContacts.fromJson(json.decode(response));
      //List<dynamic> extraDriverGet = json.decode(response.toString()) as List;

    }

    print('EmergencyContacts ${emergencyContacts.value}');
  }

  @override
  void onReady() {
    _dashboardController = Get.find();
    super.onReady();
  }

  @override
  void onClose() {}
}
