import 'dart:collection';

import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:puryaideu/app/data/network/location_request.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/data/services/location_address.dart';
import 'package:puryaideu/app/data/services/location_fetcher.dart';
import 'package:puryaideu/app/enums/location_type.dart';
import 'package:puryaideu/app/utils/camera_movement.dart';


class SavedLocationMapController extends GetxController {
  GoogleMapController _mapController;
  LatLng _currentLocation;
  LatLng _lastCameraLocation;
  String _placeName;
  LocationType _locationType;
  Set<Marker> _markers = HashSet<Marker>();
  bool _progressBarStatus = false;
  String _error;
  final saveLocationButton = true.obs;

  bool get progressBarStatus => _progressBarStatus;

  @override
  onInit() {
    initializeData();
    super.onInit();
  }

  String get lastPlaceName => _placeName;

  String get error => _error;

  LatLng get currentLocation => _currentLocation;

  LatLng get lastCameraLocation => _lastCameraLocation;

  Set<Marker> get markers => _markers;

  initializeData() async{
    if(_lastCameraLocation == null) {
      _lastCameraLocation = SessionManager.instance.currentLocation;
      await fetchNameFromCoordinates(_currentLocation);
    }
    if(_currentLocation == null) {
      updatePlaceName('Searching...');
      final location = await LocationFetcher.determinePosition();
      _currentLocation = LatLng(location.latitude, location.longitude);
      _lastCameraLocation = _currentLocation;
    }
    await fetchNameFromCoordinates(_currentLocation);
  }

  moveToCurrentLocation() async {
    if (_currentLocation == null) {
      final location = await LocationFetcher.determinePosition();
      _currentLocation = LatLng(location.latitude, location.longitude);
    }
    CameraMovement.moveCameraPosition(
        location: _currentLocation, googleMapsController: _mapController);
  }

  updateMapController(mapController) {
    _mapController = mapController;
    if(_lastCameraLocation != null) {
      CameraMovement.moveCameraPosition(location: _lastCameraLocation, googleMapsController: _mapController, zoomLevel: 15);
    }
  }

  updateMapStyle() {
    _mapController.setMapStyle("[]");
  }

  void updateLastCameraLocation(LatLng latLng) {
    final location = LatLng(latLng.latitude, latLng.longitude);
    _lastCameraLocation = location;
    update();
  }

  updatePlaceName(String place) {
    _placeName = place;
    update();
  }

  showProgressBar() {
    _progressBarStatus = true;
    update();
  }

  hideProgressBar() {
    _progressBarStatus = false;
    update();
  }

  Future<void> fetchNameFromCoordinates(LatLng latLng) async {
    String placeName = await LocationAddress.getAddressFromCoordinates(latLng);
    updatePlaceName(placeName);
  }

  void updateLocationAndAddress(
      LatLng location, String locationName, LocationType locationType) {
    _placeName = locationName;
    _lastCameraLocation = location;
    _locationType = locationType;
    update();
  }

  Future<bool> updateSavedAddress() async {
    showProgressBar();
    if (_locationType == LocationType.HOME) {
      SessionManager.instance.setHome(_placeName);
      SessionManager.instance.setHomeLocation(_lastCameraLocation);
    } else {
      SessionManager.instance.setWork(_placeName);
      SessionManager.instance.setWorkLocation(_lastCameraLocation);
    }
    final status = await LocationRequest.updateUserHomeAndWorkLocation()
        .catchError((error) {
      _error = error;
    });
    print("Status is $status");
    hideProgressBar();
    return status ?? false;
  }
}
