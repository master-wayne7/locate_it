import 'dart:async';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:puryaideu/app/data/models/booking.dart';
import 'package:puryaideu/app/data/models/distance.dart';
import 'package:puryaideu/app/data/models/rider.dart';
import 'package:puryaideu/app/data/network/sos_request.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/data/repositories/booking_repository.dart';
import 'package:puryaideu/app/data/repositories/google_repository.dart';
import 'package:puryaideu/app/data/repositories/rider_repository.dart';
import 'package:puryaideu/app/data/repositories/user_repository.dart';
import 'package:puryaideu/app/data/services/location_address.dart';
import 'package:puryaideu/app/data/services/location_fetcher.dart';
import 'package:puryaideu/app/enums/trip_events.dart';
import 'package:puryaideu/app/modules/ratings/models/cancel_reason.dart';
import 'package:puryaideu/app/modules/ratings/models/ratings_cancel_repository.dart';
import 'package:puryaideu/app/modules/trip/controllers/trip_map_controller.dart';
import 'package:puryaideu/app/routes/app_pages.dart';
import 'package:puryaideu/app/widgets/custom_button.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:url_launcher/url_launcher.dart';

class TripController extends GetxController {
  final _booking = Booking().obs;
  LatLng pickupLocation = LatLng(0, 0);
  LatLng destinationLocation = LatLng(0, 0);
  final _tripEvent = TripEvents.PENDING.obs;
  final rider = Rider().obs;
  final riderRating = 0.0.obs;
  LatLng _driverLocation = LatLng(0, 0);
  final currentLocation = LatLng(27.7165445, 85.3404986).obs;
  final waitingDuration = ''.obs;
  String currentPlaceName = 'Sanepa';
  final sosSent = false.obs;
  String errorMessage;
  Timer tripStatusTimer;
  TripMapController _tripMapController;
  final emergencySavedMessage = 'Help'.obs;

  Booking get booking => _booking.value;

  TripEvents get tripEvent => _tripEvent.value;

  LatLng get driverLocation => _driverLocation;

  List<CancelReason> _cancelReasons = [];
  int _groupValue;

  int get groupValue => _groupValue;

  List<CancelReason> get cancelReason => _cancelReasons;

  double getDuration() {
    DateTime dateTime;
    if (_booking == null) {
      return 0.0;
    }

    print('We havave');
    dateTime = _booking.value.createdAt;
    print('createdAt: $dateTime');
    // dateTime = DateTime.now();
    print(dateTime);
    DateTime currentTime = DateTime.now();
    //DateTime currentTime = _booking.value.createdAt.add(Duration(minutes: 2));
    int difference = currentTime.difference(dateTime).inSeconds;
    print('Current date time $currentTime');
    print('Difference is=== $difference');
    if (difference < 0) {
      return 0.0;
    }
    if (difference >= 300) {
      return 1.0;
    } else {
      return double.parse((difference / 120.0).toStringAsFixed(2));
    }
  }

  notifyAdmin(BuildContext context) async {
    final id = await _booking.value.id;
    print('Id of booking is $id');

    final response = await BookingRepository.notifyAdmin(_booking.value.id)
        .catchError((error) {
      errorMessage = error;
    });
    if (response == null) {
      CustomSnackbar.showCustomSnackBar(message: '$errorMessage');
      return;
    }
    if (response) {
      Get.defaultDialog(
          barrierDismissible: true,
          title: 'Assinging Rider'.tr,
          content: Container(
            margin: EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Text(
                  'Admin has been notified'.tr,
                  style: Get.textTheme.bodyText2,
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ));
    } else {
      print('Admin already notified====');
    }
  }

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
    _tripMapController = Get.find();
    listenTripStatus();
    getCancelReasons();
  }

  getCancelReasons() async {
    final reasons = await RatingsAndCancelRepository.getCancelReasons();
    updateCancelReasons(reasons);
  }

  updateCancelReasons(List<CancelReason> list) {
    _cancelReasons = list;
    _groupValue = _cancelReasons[0].id;
    print(_cancelReasons);
    update();
  }

  updateGroupValue(int id) {
    _groupValue = id;
    update();
  }

  @override
  void onClose() {
    if (tripStatusTimer != null) {
      tripStatusTimer.cancel();
    }
  }

  void setBooking(Booking booking) {
    print('set booking called====');
    _booking.value = booking;
    pickupLocation = LatLng(_booking.value.location.origin.latitude,
        _booking.value.location.origin.longitude);
    destinationLocation = LatLng(_booking.value.location.destination.latitude,
        _booking.value.location.destination.longitude);
  }

  cancelBooking() async {
    final response =
        await BookingRepository.cancelBooking(booking.id).catchError((error) {
      errorMessage = "Booking cancel service error. Please try again!";
    });
    print(response);
    if (response == null) {
      CustomSnackbar.showCustomSnackBar(message: errorMessage);
    } else {
      return true;
    }
  }

  void updateTripStatus(TripEvents event) => _tripEvent.value = event;

  void getDriverDetail() async {
    final response = await RiderRepository.getRiderDetail(booking.riderId)
        .catchError((error) {
      errorMessage = "Rider details are unavailable. Please try again!";
    });

    if (response == null) {
      CustomSnackbar.showCustomSnackBar(message: errorMessage);
      return;
    }
    print('Fetched data===');
    rider.value = response;
  }

  void getRiderRating() async {
    final response = await RiderRepository.getRiderRating(booking.riderId)
        .catchError((error) {
      errorMessage = "Rider ratings are available. Please try again!";
    });
    if (response == null) {
      return;
    }
    print('Rider rating is $response');
    riderRating.value = response;
    print('Rider rating value ${riderRating.value}');
  }

  void listenTripStatus() async {
    if (tripStatusTimer != null && tripStatusTimer.isActive) {
      return;
    }

    tripStatusTimer = Timer.periodic(Duration(seconds: 10), (timer) async {
      final status = await BookingRepository.getBookingById(_booking.value.id)
          .catchError((error) {
        errorMessage = "Trip status could not be updated. Please try again!";
      });
      print('Here');
      print('Status is === $status');

      if (status == null) {
        CustomSnackbar.showCustomSnackBar(message: errorMessage);
        return;
      }
      print('Status ==== ${status.status}');
      if (status.status == 'finished') {
        tripStatusTimer.cancel();
        SessionManager.instance.setBooking(booking);
        // if(status.vehicleTypeId == 4){
        //   Get.offNamed(Routes.DASHBOARD);
        // }
        Get.offNamed(Routes.PAYMENT_OPTIONS, arguments: [booking]);
        return;
      }

      if (status.status == 'completed') {
        if (tripStatusTimer != null) {
          tripStatusTimer.cancel();
        }

        // if(status.vehicleTypeId == 4){
        //   Get.offNamed(Routes.DASHBOARD);
        // }
        // final status = await BookingRepository.getBookingById(_booking.value.id)
        //     .catchError((error) {
        //   errorMessage = "Trip status could not be updated. Please try again!";
        // });

        final response =
            await BookingRepository.getPaymentByID(_booking.value.id)
                .catchError((error) {
          errorMessage = "Trip status could not be updated. Please try again!";
        });

        SharedPreferences sharedPreferences =
            await SharedPreferences.getInstance();
        UserRepository userRepository =
            UserRepository(prefs: sharedPreferences);
        userRepository.setBookingId(status.id.toString());
        userRepository.setPaymentId(response.id.toString());
        userRepository.setCompletedTripId(response.completedTripId.toString());
        userRepository.setRiderId(status.riderId.toString());
        userRepository.setPaymentStatus('unpaid');

        final completedTrip = await BookingRepository.getCompletedTripByID(
                response.completedTripId)
            .catchError((error) {
          errorMessage = "Completed Trip not found.";
        }).then((name) {
          Get.offNamed(Routes.PAYMENT_OPTIONS, arguments: [name]);
        });
        ;

        return;
      }

      if (status.status == 'cancelled') {
        tripStatusTimer.cancel();
        Get.offNamed(Routes.DASHBOARD);
        return;
      }
      if (_booking.value.status != status.status) {
        _booking.value = status;
        await _tripMapController.clearMap();
        await _tripMapController.setUpMap();
      }
    });
  }

  void setGooglePadding(double padding) =>
      _tripMapController.setGooglePadding(padding);

  void checkRideStatus() async {
    final status = await BookingRepository.getBookingById(_booking.value.id)
        .catchError((error) {
      errorMessage = "Ride status unavailable. Please try again!";
    });

    if (status == null) {
      CustomSnackbar.showCustomSnackBar(message: errorMessage);
      return;
    }
    if (status.status == 'completed') {
      if (tripStatusTimer != null) {
        tripStatusTimer.cancel();
      }

      // if(status.vehicleTypeId == 4){
      //   Get.offNamed(Routes.DASHBOARD);
      //   return;
      // }

      final response = await BookingRepository.getPaymentByID(_booking.value.id)
          .catchError((error) {
        errorMessage = "Trip status could not be updated. Please try again!";
      });

      SharedPreferences sharedPreferences =
          await SharedPreferences.getInstance();
      UserRepository userRepository = UserRepository(prefs: sharedPreferences);
      userRepository.setBookingId(_booking.value.id.toString());
      userRepository.setPaymentId(response.id.toString());
      userRepository.setCompletedTripId(response.completedTripId.toString());
      userRepository.setRiderId(status.riderId.toString());
      userRepository.setPaymentStatus('unpaid');

      // final bookingResponse = await BookingRepository.getBookingById(_booking.value.id)
      //     .catchError((error) {
      //   errorMessage = "Trip status could not be updated. Please try again!";
      // });

      await BookingRepository.getCompletedTripByID(response.completedTripId)
          .catchError((error) {
        errorMessage = "Completed Trip not found.";
      }).then((name) {
        Get.offNamed(Routes.PAYMENT_OPTIONS, arguments: [name]);
      });
      ;

      print("WE ARE HERE");

      return;
    }
    // CustomSnackbar.showCustomSnackBar(message: 'Booking status is=== ${status.status}');
    if (_booking.value.status != status.status) {
      _booking.value = status;
      _tripMapController.setUpMap();
    }
  }

  Future<LatLng> getDriverLocation() async {
    final status = await RiderRepository.getRiderLocation(booking.riderId)
        .catchError((error) {
      errorMessage = "Driver location is not available. Please try again!";
    });
    if (status == null) {
      CustomSnackbar.showCustomSnackBar(message: errorMessage);
      return null;
    }
    _driverLocation = status;
    return _driverLocation;
  }

  getEstimatedTimerForRiderArrival() async {
    DistanceDTO distanceDTO =
        await GoogleRepository.getDistanceBetweenCoordinates(
                pickupLocation, _driverLocation)
            .catchError((error) {
      errorMessage =
          "Driver distance estimation is not available. Please try again!";
    });
    if (distanceDTO == null) {
      CustomSnackbar.showCustomSnackBar(message: errorMessage);
      return;
    }
    var durationTime = distanceDTO.rows[0].elements[0].duration.text;
    waitingDuration.value = durationTime;
    CustomSnackbar.showCustomSnackBar(
        message:
            'Driver will reach you in ${waitingDuration.value} approximately.');
  }

  Future<bool> sendSosRequest(String message) async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    UserRepository userRepository = UserRepository(prefs: sharedPreferences);
    String id = await userRepository.getSosId();
    print('SOS id is $id');

    String _error = '';
    var _locationData = await LocationFetcher.determinePosition();
    currentLocation.value =
        LatLng(_locationData.latitude, _locationData.longitude);
    await LocationAddress.getAddressFromCoordinates(currentLocation.value)
        .then((name) {
      currentPlaceName = name;
    });

    if (id == 'no') {
      print('New SOS Request');
      final status = await SosRequest.sendSosRequest(
              currentLocation.value, message, booking.id, currentPlaceName)
          .catchError((error) {
        _error = error;
      });
      if (status == null) {
        CustomSnackbar.showCustomSnackBar(message: '$_error');
        return false;
      }
      if (status) {
        sosSent.value = true;
        CustomSnackbar.showCustomSnackBar(
            message: 'Admin has been notified'.tr);
        return true;
      } else {
        return false;
      }
    } else {
      print('Existing SOS Request');
      final status = await SosRequest.continueSosEvent(message, int.parse(id))
          .catchError((error) {
        _error = error;
      });
      if (status == null) {
        CustomSnackbar.showCustomSnackBar(message: '$_error');
        return false;
      }
      if (status) {
        CustomSnackbar.showCustomSnackBar(
            message: 'Admin has been notified'.tr);
        return true;
      } else {
        return false;
      }
    }
  }

  Future<bool> shareTrip({String message, String contacts}) async {
    // Android
    String contacts = '';
    String emergencyMessage;
    String replaceWhitespaces(String s, String replace) {
      if (s == null) {
        return null;
      }

      return s.replaceAll(' ', replace);
    }
    emergencyMessage = "Hey,%20it's" +
        '%20${SessionManager.instance.user.firstName}' +
        '%0AI%20am%20sharing%20this%20detail%20with%20you%20as%20my%20emergency%20contact.'
            .tr +
    '%0A' +
    'Rider%20name'.tr +
    ':%20${rider.value.name}' +
        '%0A' +
    'Rider%20number'.tr +
    ':%20${rider.value.phone}' +
        '%0A' +
    'Origin%20location:%20'.tr +
        replaceWhitespaces(_booking.value.location.origin.name, '%20') +
        '%0A' +
    'Destination%20location:%20'.tr +
        replaceWhitespaces(_booking.value.location.destination.name, '%20');

    String encodeQueryParameters(Map<String, String> params) {
      return params.entries
          .map((e) =>
              '${Uri.encodeComponent(e.key)}=${Uri.encodeComponent(e.value)}')
          .join('&');
    }

    if (message != null) {
      emergencyMessage = emergencyMessage + '\n' + message;
      // emergencyMessage = emergencyMessage + '\n\n' + message;
    }
    print("Emergency Message is $emergencyMessage");
    if (SessionManager.instance.contactList != null) {
      for (int i = 0; i < SessionManager.instance.contactList.length; i++) {
        contacts = contacts +
            ' ' +
            SessionManager.instance.contactList[i].contact +
            ',';
      }
      if (Platform.isAndroid) {
        final uri = "sms:$contacts?body=$emergencyMessage";
        if (await canLaunch(uri)) {
          await launch(uri);
        } else {
          throw 'Could not launch $uri';
        }
      } else if (Platform.isIOS) {
        print('ehere');
        final uri = 'sms:${SessionManager.instance.contactList[0].contact}&body=$emergencyMessage';
        await launch(uri.toString());
      }
      return true;
    }

    emergencySavedMessage.value = emergencyMessage;
    return false;
  }
}

//Dynamic code for smsUri
/*
 String? encodeQueryParameters(Map<String, String> params) {
    return params.entries
        .map((e) => '${Uri.encodeComponent(e.key)}=${Uri.encodeComponent(e.value)}')
        .join('&');
  }

Uri smsUri = Uri(
      scheme: 'sms',
      path: '$phoneNumber',
      query: encodeQueryParameters(<String, String>{
        'body':
            'Hey this is message body'
      }),
    );

    try {
      if (await canLaunch(smsUri.toString())) {
        await launch(smsUri.toString());
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Some error occured'),
        ),
      );
    }
 */
