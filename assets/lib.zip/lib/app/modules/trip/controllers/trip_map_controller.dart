import 'dart:collection';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/data/services/polylines_fetcher.dart';
import 'package:puryaideu/app/enums/trip_events.dart';
import 'package:puryaideu/app/modules/trip/controllers/trip_controller.dart';
import 'package:puryaideu/app/utils/camera_movement.dart';
import 'package:puryaideu/app/utils/map_bound_from_location.dart';
import 'package:puryaideu/app/utils/place_to_marker.dart';

class TripMapController extends GetxController {
  GoogleMapController _mapController;
  TripController _tripController;
  final markers = HashSet<Marker>().obs;
  final _googlePadding = 10.0.obs;
  final Set<Polyline> polylines = {};
  BitmapDescriptor originIconText;
  BitmapDescriptor destinationIconText;

  Future<void> initializeTextMarkers() async {
    originIconText = await placeToMarker(
        _tripController.booking.location.origin.name, null,
        icon: Icons.gps_fixed_rounded);
    destinationIconText = await placeToMarker(
        _tripController.booking.location.destination.name, null,
        icon: Icons.location_pin);
  }

  updateMapStyle() {
    _mapController.setMapStyle("[]");
  }

  clearMap() {
    markers.value.clear();
    polylines.clear();
    update();
  }

  updateMapController(mapController) {
    print('update map controller called===');
    _mapController = mapController;
    clearMap();
    setUpMap();
  }

  double get googlePadding => _googlePadding.value;

  setUpMap() async {
    await clearMap();
    await initializeTextMarkers();
    print('booking status=== ${_tripController.booking.status}');
    print(
        'pickup location===== ${_tripController.pickupLocation.latitude}, ${_tripController.pickupLocation.longitude}');
    print(
        'destination location=== ${_tripController.destinationLocation.latitude}, ${_tripController.destinationLocation.longitude}');
    switch (_tripController.booking.status) {
      case 'pending':
        _tripController.updateTripStatus(TripEvents.PENDING);
        makeRoute(
            _tripController.pickupLocation,
            _tripController.destinationLocation,
            SessionManager.instance.pickupIcon,
            SessionManager.instance.destinationIcon);
        break;
      case 'accepted':
        _tripController.getDriverDetail();
        _tripController.getRiderRating();
        await _tripController.getDriverLocation().then((driverLocation) {
          _tripController.getEstimatedTimerForRiderArrival();
          print(
              "_tripController.booking.vehicleTypeId is ==== ${_tripController.booking.vehicleTypeId}");
          makeTwoWayRoute(
              _tripController.pickupLocation,
              _tripController.destinationLocation,
              driverLocation,
              SessionManager.instance.pickupIcon,
              SessionManager.instance.destinationIcon,
              _tripController.booking.vehicleTypeId == 1
                  ? SessionManager.instance.bikeIcon
                  : _tripController.booking.vehicleTypeId == 2
                      ? SessionManager.instance.carIcon
                      : _tripController.booking.vehicleTypeId == 3
                          ? SessionManager.instance.citySafariIcon
                          : _tripController.booking.vehicleTypeId == 5
                              ? SessionManager.instance.foodIcon
                              : _tripController.booking.vehicleTypeId == 5
                                  ? SessionManager.instance.medicalIcon
                                  : SessionManager.instance.ambulanceIcon);
          _tripController.updateTripStatus(TripEvents.ACCEPTED);
        });

        break;
      case 'running':
        _tripController.getDriverDetail();
        _tripController.getRiderRating();
        makeRoute(
            _tripController.pickupLocation,
            _tripController.destinationLocation,
            SessionManager.instance.pickupIcon,
            SessionManager.instance.destinationIcon);
        _tripController.updateTripStatus(TripEvents.RUNNING);
        break;
    }
    // _tripController.listenTripStatus();
  }

  makeTwoWayRoute(
      LatLng origin,
      LatLng destination,
      LatLng myLocation,
      Uint8List originIcon,
      Uint8List destinationIcon,
      Uint8List myLocationIcon) async {
    markers.value.clear();
    polylines.clear();
    _addIconMarker(
        BitmapDescriptor.fromBytes(originIcon), 'origin', null, origin);
    _addIconMarker(originIconText, 'origin_text', null, origin,
        anchor: Offset(0.5, 1.1));
    _addIconMarker(
        BitmapDescriptor.fromBytes( _tripController.booking.vehicleTypeId == 1
            ? SessionManager.instance.bikeIcon
            : _tripController.booking.vehicleTypeId == 2
            ? SessionManager.instance.carIcon
            : _tripController.booking.vehicleTypeId == 3
            ? SessionManager.instance.citySafariIcon
            : _tripController.booking.vehicleTypeId == 5
            ? SessionManager.instance.foodIcon
            : _tripController.booking.vehicleTypeId == 5
            ? SessionManager.instance.medicalIcon
            : SessionManager.instance.ambulanceIcon),
        'my_location',
        null,
        myLocation);
    _addIconMarker(BitmapDescriptor.fromBytes(destinationIcon), 'destination',
        null, destination);
    _addIconMarker(destinationIconText, 'destination_text', null, destination,
        anchor: Offset(0.5, 1.1));
    final firstRoute = await PolylinesFetcher.getPolylines(
      origin,
      myLocation,
      'my_route',
      color: Get.theme.accentColor,
    );
    final secondRoute = await PolylinesFetcher.getPolylines(
        origin, destination, 'main_route'.tr,
        color: Get.theme.primaryColor);
    polylines.add(firstRoute);
    polylines.add(secondRoute);
    _mapController.animateCamera(
      CameraUpdate.newLatLngBounds(
        MapBoundFromLocation.boundsFromLatLngList([myLocation, destination]),
        100.0,
      ),
    );
    update();
  }

  makeRoute(LatLng origin, LatLng destination, Uint8List originIcon,
      Uint8List destinationIcon,
      {Function originTap, Function destinationTap}) async {
    markers.value.clear();
    _addIconMarker(
        BitmapDescriptor.fromBytes(originIcon), 'origin', originTap, origin);
    _addIconMarker(originIconText, 'originText', originTap, origin,
        anchor: Offset(0.5, 1.1));
    _addIconMarker(BitmapDescriptor.fromBytes(destinationIcon), 'destination',
        destinationTap, destination);
    _addIconMarker(
        destinationIconText, 'destinationText', destinationTap, destination,
        anchor: Offset(0.5, 1.1));
    final response = await PolylinesFetcher.getPolylines(
        origin, destination, 'main_route',
        color: Get.theme.primaryColor);
    updatePolyLines(response);
    _mapController.animateCamera(
      CameraUpdate.newLatLngBounds(
        MapBoundFromLocation.boundsFromLatLngList([origin, destination]),
        100.0,
      ),
    );
  }

  updatePolyLines(lines) {
    polylines.add(lines);
    update();
  }

  void _addIconMarker(final icon, String id, Function onTap, LatLng location,
      {Offset anchor = const Offset(0, 0)}) async {
    Marker _marker = Marker(
        onTap: onTap,
        markerId: MarkerId(id),
        position: location,
        anchor: anchor,
        // icon: BitmapDescriptor.fromBytes(icon),
        icon: icon);
    markers.value.add(_marker);
  }

  @override
  void onReady() {
    super.onReady();
    _tripController = Get.find();
  }

  setGooglePadding(double padding) => _googlePadding.value = padding;
}
