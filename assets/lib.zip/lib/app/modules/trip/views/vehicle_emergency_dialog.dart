import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/modules/trip/controllers/trip_controller.dart';
import 'package:puryaideu/app/widgets/custom_button.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:url_launcher/url_launcher.dart';

class VehicleEmergencyDialog extends GetView<TripController> {
  final TextEditingController reasonController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Positioned(
      right: 16,
      top: 16,
      child: GestureDetector(
        onTap: () async {
          await buildEmergencyPanel(context, controller, reasonController);
        },
        child: Container(
          child: Image.asset(
            'assets/siren.png',
            fit: BoxFit.contain,
            height: 42,
            width: 42,
          ),
        ),
      ),
    );
  }
}

buildEmergencyPanel(BuildContext context, TripController controller,
    TextEditingController reasonController) async {
  showGeneralDialog(
      barrierColor: Colors.black.withOpacity(0.5),
      transitionBuilder: (context, a1, a2, widget) {
        final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
        return Transform(
          transform: Matrix4.translationValues(
              curvedValue * 1, -curvedValue * 100, 0.0),
          child: Opacity(
            opacity: a1.value,
            child: Stack(
              children: [
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Container(
                      // height: Get.height * 0.3,
                      padding: EdgeInsets.all(16),
                      decoration: BoxDecoration(color: Colors.white),
                      child: SingleChildScrollView(
                        physics: NeverScrollableScrollPhysics(),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: <Widget>[
                            Text('Emergency Services',
                                style: Get.textTheme.bodyText2.copyWith(
                                    color: Colors.black.withOpacity(0.9),
                                    fontSize: getResponsiveFont(20),
                                    fontWeight: FontWeight.w600)),
                            SizedBox(height: getResponsiveFont(12)),
                            GestureDetector(
                              onTap: () async {
                                // if (await canLaunch('tel: 100')) {
                                //
                                //   await launch('tel:100');
                                // } else {
                                //   throw 'Could not launch url';
                                // }
                                try {
                                  final Uri launchUri = Uri(
                                    scheme: 'tel',
                                    path: '100',
                                  );
                                  await launch(launchUri.toString());
                                } catch (e) {
                                  CustomSnackbar.showCustomSnackBar(
                                      message: 'Could not call Nepal Police.');
                                }
                              },
                              child: Row(
                                children: [
                                  Image.asset(
                                    'assets/emergency-call.png',
                                    fit: BoxFit.contain,
                                    height: 32,
                                    width: 32,
                                  ),
                                  SizedBox(width: 16),
                                  Expanded(
                                      child: Text(
                                    'Call Nepal Police.',
                                    maxLines: 1,
                                    style: Get.textTheme.bodyText2.copyWith(
                                        color: Colors.grey[800],
                                        fontSize: getResponsiveFont(17),
                                        fontWeight: FontWeight.w500),
                                    overflow: TextOverflow.ellipsis,
                                  )),
                                ],
                              ),
                            ),
                            SizedBox(height: getResponsiveFont(12)),
                            GestureDetector(
                              onTap: () async {
                                print('Share your trip pressed.');
                                final status = await controller.shareTrip();
                                if (!status) {
                                  Clipboard.setData(ClipboardData(
                                      text: controller
                                          .emergencySavedMessage.value));
                                  ShareTripNoContact.show(context);
                                  Future.delayed(Duration(milliseconds: 10000))
                                      .then((_) => ShareTripNoContact.hide());
                                }
                              },
                              child: Row(
                                children: [
                                  Image.asset(
                                    'assets/shar.png',
                                    fit: BoxFit.contain,
                                    height: 32,
                                    width: 32,
                                  ),
                                  SizedBox(width: 16),
                                  Expanded(
                                      child: Text(
                                    'Share your trip.',
                                    maxLines: 1,
                                    style: Get.textTheme.bodyText2.copyWith(
                                        color: Colors.grey[800],
                                        fontSize: getResponsiveFont(17),
                                        fontWeight: FontWeight.w500),
                                    overflow: TextOverflow.ellipsis,
                                  )),
                                ],
                              ),
                            ),
                            SizedBox(height: getResponsiveFont(12)),
                            GestureDetector(
                              onTap: () async {
                                showDialog(
                                    context: context,
                                    builder: (_) {
                                      return AlertDialog(actions: [
                                        Column(children: [
                                          TextField(
                                            autofocus: true,
                                            controller: reasonController,
                                            style: Get.textTheme.bodyText2,
                                            maxLines: 10,
                                            decoration: InputDecoration(
                                              hintText:
                                                  'Enter your complain.'.tr,
                                            ),
                                          ),
                                          SizedBox(height: Get.height * 0.05),
                                          Container(
                                            width: Get.width,
                                            child: CustomButton(
                                              text: 'Submit'.tr,
                                              backgroundColor:
                                                  Get.theme.primaryColor,
                                              onPressed: () async {
                                                if (reasonController
                                                        .text.length ==
                                                    0) {
                                                  CustomSnackbar.showCustomSnackBar(
                                                      message:
                                                          'please_enter_your_complain');
                                                  return;
                                                }
                                                Navigator.of(context,
                                                        rootNavigator: true)
                                                    .pop();
                                                await controller.sendSosRequest(
                                                    reasonController.text);
                                                //controller.sendSmsToEmergencyContacts(reasonController.text);
                                                reasonController.text = '';
                                              },
                                            ),
                                          ),
                                        ])
                                      ]);
                                    });
                              },
                              child: Row(
                                children: [
                                  Image.asset(
                                    'assets/sos.png',
                                    fit: BoxFit.contain,
                                    height: 32,
                                    width: 32,
                                  ),
                                  SizedBox(width: 16),
                                  Expanded(
                                      child: Text(
                                    'Send emergency message to Puryaideu team.',
                                    maxLines: 2,
                                    style: Get.textTheme.bodyText2.copyWith(
                                        color: Colors.grey[800],
                                        fontSize: getResponsiveFont(17),
                                        fontWeight: FontWeight.w500),
                                    overflow: TextOverflow.ellipsis,
                                  )),
                                ],
                              ),
                            ),
                          ],
                        ),
                      )),
                ),
              ],
            ),
          ),
        );
      },
      transitionDuration: Duration(milliseconds: 330),
      barrierDismissible: true,
      barrierLabel: '',
      context: context,
      pageBuilder: (context, animation1, animation2) {});
}

class ShareTripNoContact extends StatelessWidget {
  final TripController controller = Get.find();
  final TextEditingController shareController = TextEditingController();
  static OverlayEntry currentLoader;

  static void show(BuildContext context) {
    currentLoader = new OverlayEntry(
        builder: (context) => Stack(
              children: <Widget>[
                Container(
                  color: Color(0x99ffffff),
                ),
                Center(
                  child: ShareTripNoContact(),
                ),
              ],
            ));
    Overlay.of(context).insert(currentLoader);
  }

  static void hide() {
    currentLoader?.remove();
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Container(
          padding: EdgeInsets.all(16.0),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(5),
              border: Border.all(color: Colors.grey.withOpacity(0.3)),
              color: Colors.white),
          child: Text(
              "${controller.emergencySavedMessage.value} \n\nShare trip message has been copied to clipboard.",
              style: Get.textTheme.bodyText2.copyWith(
                  fontSize: getResponsiveFont(15),
                  fontWeight: FontWeight.w500,
                  color: Colors.black))),
    );
  }
}
