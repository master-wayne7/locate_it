import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/modules/trip/controllers/trip_controller.dart';
import 'package:puryaideu/app/widgets/sliding_up_panel.dart';
import 'package:puryaideu/generated/locales.g.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../../widgets/custom_snackbar.dart';
import '../vehicle_emergency_dialog.dart';
import 'trip_accepted_dialog.dart';

class TripRunningDialog extends GetView<TripController> {
  final PanelController _pc = new PanelController();

  @override
  Widget build(BuildContext context) {
    return SlidingUpPanel(
      controller: _pc,
      minHeight: Get.height * 0.25,
      maxHeight: Get.height * 0.69,
      defaultPanelState: PanelState.CLOSED,
      panel: Container(
        padding: EdgeInsets.symmetric(horizontal: 8),
        decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.all(Radius.circular(24.0)),
            boxShadow: [
              BoxShadow(
                blurRadius: 20.0,
                color: Colors.transparent,
              ),
            ]),
        child: SingleChildScrollView(
          physics: NeverScrollableScrollPhysics(),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                margin: EdgeInsets.only(
                  left: 8,
                  right: 8,
                  top: 16,
                ),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(24.0),
                      topRight: Radius.circular(24.0)),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Center(
                      child: Container(
                        height: 3,
                        width: 40,
                        color: Color(0xff8b8b8b).withOpacity(0.5),
                      ),
                    ),
                    SizedBox(height: 8),
                    Text('Towards the destination...',
                        style: Get.textTheme.bodyText2.copyWith(
                            color: Colors.black.withOpacity(0.9),
                            fontSize: getResponsiveFont(21),
                            fontWeight: FontWeight.w600)),
                    SizedBox(height: 8),
                    Divider(
                      height: 1,
                      thickness: 1.2,
                      color: Color(0xffe6e8eb),
                    ),
                    SizedBox(height: 10),
                    Container(
                        padding: EdgeInsets.symmetric(horizontal: 0),
                        color: Colors.white,
                        width: Get.width,
                        child: Row(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Column(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(5),
                                    child: Obx(
                                          () => CachedNetworkImage(
                                        imageUrl:
                                        '$BASE_URL/${controller.rider.value.imagePath}',
                                        height: 90,
                                        width: 90,
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  SizedBox(height: 2),
                                  Obx(
                                          () =>IgnorePointer(
                                        child: RatingBar(
                                            initialRating:
                                            controller.riderRating.value,
                                            glow: false,
                                            direction: Axis.horizontal,
                                            allowHalfRating: true,
                                            tapOnlyMode: false,
                                            updateOnDrag: false,
                                            itemCount: 5,
                                            itemSize: getResponsiveFont(16.0),
                                            ratingWidget: RatingWidget(
                                                full: Icon(Icons.star,
                                                    color: Color(0xffFFD700)),
                                                half: Icon(
                                                  Icons.star_half,
                                                  color: Color(0xffFFD700),
                                                ),
                                                empty: Icon(Icons.star_outline,
                                                    color: Color(0xffFFD700))),
                                            onRatingUpdate: (value) {}),
                                      )),
                                ],
                              ),
                              SizedBox(width: 16),
                              Expanded(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.start,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Obx(
                                          () => Text(
                                        controller.rider.value == null
                                            ? '---'
                                            : '${controller.rider.value.name}',
                                        style: Get.textTheme.bodyText2.copyWith(
                                            color: Colors.black,
                                            fontSize: getResponsiveFont(18),
                                            fontWeight: FontWeight.w600),
                                      ),
                                    ),
                                    SizedBox(height: 4),
                                    Obx(
                                            () =>Text(
                                          controller.rider.value.riderDetails ==
                                              null
                                              ? '--'
                                              : controller.rider.value.riderDetails
                                              .vehicle.brand +
                                              ' ' +
                                              controller.rider.value
                                                  .riderDetails.vehicle.model,
                                          style: Get.textTheme.bodyText2.copyWith(
                                              color: Color(0xff8b8b8b),
                                              fontSize: getResponsiveFont(16),
                                              fontWeight: FontWeight.w500),
                                        )),
                                    SizedBox(height: 4),
                                    Container(
                                      color: Color(0xffe6e8eb),
                                      padding: EdgeInsets.symmetric(
                                          horizontal: 12, vertical: 8),
                                      child: Obx(
                                              () =>Text(
                                              controller.rider.value.riderDetails ==
                                                  null
                                                  ? '---'
                                                  : controller
                                                  .rider
                                                  .value
                                                  .riderDetails
                                                  .vehicle
                                                  .vehicleNumber,
                                              style: Get.textTheme.bodyText2
                                                  .copyWith(
                                                  color: Color(0xff2c2d2e),
                                                  fontSize:
                                                  getResponsiveFont(15),
                                                  fontWeight: FontWeight.w600))),
                                    ),
                                  ],
                                ),
                              ),
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  ElevatedButton(
                                    onPressed: () async {
                                      try {
                                        final Uri launchUri = Uri(
                                          scheme: 'tel',
                                          path: controller.rider.value.phone,
                                        );
                                        await launch(launchUri.toString());
                                      } catch (e) {
                                        CustomSnackbar.showCustomSnackBar(
                                            message: 'Could not call Nepal Police.');
                                      }
                                    },
                                    child: Icon(Icons.call,
                                        color: Colors.black, size: 20),
                                    style: ButtonStyle(
                                      shape: MaterialStateProperty.all(
                                          CircleBorder()),
                                      padding: MaterialStateProperty.all(
                                          EdgeInsets.all(6)),
                                      backgroundColor:
                                      MaterialStateProperty.all(
                                          Colors.white), // <-- Button color

                                      // overlayColor: MaterialStateProperty
                                      //     .resolveWith<Color>((states) {
                                      //   if (states
                                      //       .contains(MaterialState.pressed))
                                      //     return Colors.red; // <-- Splash color
                                      // }),
                                    ),
                                  ),
                                  ElevatedButton(
                                    onPressed: () async {
                                      try {
                                        final Uri launchUri = Uri(
                                          scheme: 'tel',
                                          path: controller.rider.value.phone,
                                        );
                                        await launch(launchUri.toString());
                                      } catch (e) {
                                        CustomSnackbar.showCustomSnackBar(
                                            message: 'Could not call Nepal Police.');
                                      }
                                    },
                                    child: Icon(Icons.share,
                                        color: Colors.black, size: 20),
                                    style: ButtonStyle(
                                      shape: MaterialStateProperty.all(
                                          CircleBorder()),
                                      padding: MaterialStateProperty.all(
                                          EdgeInsets.all(6)),
                                      backgroundColor:
                                      MaterialStateProperty.all(
                                          Colors.white), // <-- Button color

                                      // overlayColor: MaterialStateProperty
                                      //     .resolveWith<Color>((states) {
                                      //   if (states
                                      //       .contains(MaterialState.pressed))
                                      //     return Colors.red; // <-- Splash color

                                      // }),
                                    ),
                                  ),
                                ],
                              ),
                            ])),
                    SizedBox(height: 6),
                    // Divider(
                    //   height: 1,
                    //   thickness: 1.2,
                    //   color: Color(0xffe6e8eb),
                    // ),
                    SizedBox(height: 10),
                  ],
                ),
              ),
              TripDetailWidget(controller: controller),
            ],
          ),
        ),
      ),
      body: Stack(children: [
        Container(),
        VehicleEmergencyDialog(),
      ]),
    );
  }
}