import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/modules/trip/controllers/trip_controller.dart';
import 'package:puryaideu/app/widgets/custom_button.dart';
import 'package:puryaideu/app/widgets/sliding_up_panel.dart';
import 'package:puryaideu/generated/locales.g.dart';

import '../cancel_dialog.dart';
import '../cancel_reason.dart';
import '../vehicle_emergency_dialog.dart';
import 'trip_accepted_dialog.dart';

class WaitingDialog extends StatefulWidget {
  @override
  State<WaitingDialog> createState() => _WaitingDialogState();
}

class _WaitingDialogState extends State<WaitingDialog>
    with SingleTickerProviderStateMixin {
  final TripController controller = Get.find();

  AnimationController animationController;
  Animation animation;
  final PanelController _pc = new PanelController();

  @override
  void initState() {
    startProgressAnimation();
    super.initState();
  }

  startProgressAnimation() async {
    double startValue = controller.getDuration();
    // double startValue = 0.0;
    print('startValue is ' + startValue.toString());
    int remainingDuration = ((1.0 - startValue) * 120).toInt();
    animationController = AnimationController(
        duration: Duration(seconds: remainingDuration), vsync: this);
    animation = Tween(begin: startValue, end: 1.0).animate(animationController)
      ..addListener(() {
        setState(() {});
      });
    //animationController.forward();
    animationController.forward().then((_) => controller.notifyAdmin(context));
  }

  @override
  void dispose() {
    // _animationController.dispose();
    animationController.stop();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SlidingUpPanel(
          controller: _pc,
          minHeight: Get.height * 0.1,
          maxHeight: controller.booking.vehicleTypeId == 4
              ? Get.height * 0.45 : Get.height * 0.53,
          renderPanelSheet: false,
          defaultPanelState: PanelState.CLOSED,
          //panel: _floatingPanel(),
          //collapsed: _floatingCollapsed(),
          panel: Container(
            padding: EdgeInsets.symmetric(horizontal: 8),
            decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(24.0),
                    topRight: Radius.circular(24.0)),
                boxShadow: [
                  BoxShadow(
                    blurRadius: 20.0,
                    color: Colors.transparent,
                  ),
                ]),
            child: SingleChildScrollView(
              physics: NeverScrollableScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                    margin: EdgeInsets.only(
                      left: 8,
                      right: 8,
                      top: 16,
                    ),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(24.0),
                          topRight: Radius.circular(24.0)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        Center(
                          child: Container(
                            height: 3,
                            width: 40,
                            color: Color(0xff8b8b8b).withOpacity(0.5),
                          ),
                        ),
                        SizedBox(height: 8),
                        GestureDetector(
                          onTap: () {},
                          child: Text('Searching for riders...',
                              style: Get.textTheme.bodyText2.copyWith(
                                  color: Colors.black.withOpacity(0.9),
                                  fontSize: getResponsiveFont(21),
                                  fontWeight: FontWeight.w600)),
                        ),
                        SizedBox(height: 8),
                        Divider(
                          height: 1,
                          thickness: 1.2,
                          color: Color(0xffe6e8eb),
                        ),
                        SizedBox(height: 10),
                        // Divider(
                        //   height: 1,
                        //   thickness: 1.2,
                        //   color: Color(0xffe6e8eb),
                        // ),
                        SizedBox(height: 10),
                      ],
                    ),
                  ),
                  TripDetailWidget(controller: controller),
                ],
              ),
            ),
          ),
          body: Container(
            height: Get.height,
            width: Get.width,
            color: Colors.black12,
            child: Center(
              child: Stack(
                children: [
                  Container(
                    width: 100,
                    height: 100,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Image.asset(
                        controller.booking.vehicleTypeId == 1
                            ? 'assets/bike.png'
                            : controller.booking.vehicleTypeId == 2
                                ? 'assets/car.png'
                                : controller.booking.vehicleTypeId == 3
                                    ? 'assets/tuk-tuk.png'
                                    : controller.booking.vehicleTypeId == 4
                                        ? 'assets/new_ambulance.png'
                                        : controller.booking.vehicleTypeId == 5
                            ? 'assets/food_truck.png' : controller.booking.vehicleTypeId == 6
                            ? 'assets/delivery.png' : 'assets/bike.png',
                        fit: BoxFit.contain,
                      ),
                    ),
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: Colors.white,
                      // boxShadow: [
                      //   BoxShadow(
                      //       color: Colors.black54,
                      //       blurRadius: _animation.value,
                      //       spreadRadius: _animation.value)
                      // ]
                    ),
                  ),
                  Container(
                    height: 100,
                    width: 100,
                    child: CircularProgressIndicator(
                      value: animation.value,
                      color: Get.theme.primaryColor.withOpacity(0.3),
                      valueColor:
                          AlwaysStoppedAnimation<Color>(Get.theme.primaryColor),
                      //backgroundColor: Get.theme.primaryColor.withOpacity(0.3),
                      //backgroundColor: Get.theme.primaryColor.withOpacity(0.1),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        // VehicleEmergencyDialog(),
      ],
    );
  }
}
