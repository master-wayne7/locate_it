import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/modules/trip/controllers/trip_controller.dart';
import 'package:puryaideu/app/modules/trip/controllers/trip_map_controller.dart';
import 'package:puryaideu/app/utils/local_notifications_singleton.dart';

class TripMapContainer extends StatefulWidget {
  @override
  _TripMapContainerState createState() => _TripMapContainerState();
}

class _TripMapContainerState extends State<TripMapContainer>
    with WidgetsBindingObserver {
  TripMapController controller = Get.find();
  TripController tripController = Get.find();

  @override
  void initState() {
    WidgetsBinding.instance.addObserver(this);
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
      RemoteNotification notification = message.notification;
      print(" Message data : ${message.data}");
      final messageType = message.data['data'];

      if (messageType == "booking_accepted") {
        tripController.checkRideStatus();
      } else if (messageType == "booking_running") {
        tripController.checkRideStatus();
      } else if (messageType == "booking_completed") {
        tripController.checkRideStatus();
      }else if (messageType == "booking_cancelled") {
        tripController.checkRideStatus();
      }


      AndroidNotification android = message.notification?.android;
      if (notification != null && android != null) {
        LocalNotificationPluginSingleton.instance.localNotificationsPlugin.show(
          notification.hashCode,
          notification.title,
          notification.body,
          NotificationDetails(
              android: AndroidNotificationDetails(
                  LocalNotificationPluginSingleton.instance.channel.id,
                  LocalNotificationPluginSingleton.instance.channel.name,
                  LocalNotificationPluginSingleton.instance.channel.description,
                  playSound: true,
                  icon: '@mipmap/ic_launcher')),
        );
      }
    });
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      controller.updateMapStyle();
    }
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<TripMapController>(
      builder: (myController) => Obx(
        () => GoogleMap(
          initialCameraPosition: CameraPosition(
              zoom: 16,
              target: SessionManager.instance.currentLocation == null
                  ? LatLng(27.700769, 85.300140)
                  : SessionManager.instance.currentLocation),
          myLocationEnabled: true,
          myLocationButtonEnabled: false,
          compassEnabled: false,
          mapType: MapType.normal,
          padding: EdgeInsets.only(bottom: controller.googlePadding),
          polylines: myController.polylines,
          zoomGesturesEnabled: true,
          // polygons: PolygonPoints.myPolygon(),
          zoomControlsEnabled: false,
          markers: controller.markers.value,
          onMapCreated: (GoogleMapController _controller) {
            controller.updateMapController(_controller);
          },
        ),
      ),
    );
  }
}
