import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/modules/booking/controllers/booking_controller.dart';
import 'package:puryaideu/app/modules/trip/controllers/trip_controller.dart';
import 'package:puryaideu/app/routes/app_pages.dart';
import 'package:puryaideu/app/widgets/custom_button.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';

class CancelReasonDialog extends StatelessWidget {
  TripController controller = Get.find();

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.all(Radius.circular(10.0))),
      contentPadding: EdgeInsets.only(top: 10.0),
      content: Container(
        width: Get.width,
        child: GetBuilder<TripController>(
          builder: (myController) => Container(
            margin: EdgeInsets.all(16),
            child: Column(
              children: [
                Text(
                  'CANCEL BOOKING',
                  style: Get.textTheme.bodyText2.copyWith(
                    color: Colors.red,
                    fontSize: getResponsiveFont(20),
                  ),
                ),
                SizedBox(height: 16),
                SvgPicture.asset(
                  'svg_assets/warning.svg',
                  height: Get.height * 0.2,
                ),
                SizedBox(height: 16),
                Text(
                  'Why do you want to cancel this booking?',
                  style: Get.textTheme.headline6,
                  textAlign: TextAlign.center,
                ),
                SizedBox(height: 16),
                Expanded(
                  child: Container(
                    child: ListView.builder(
                      itemBuilder: (context, index) {
                        return Card(
                          child: Container(
                            padding: EdgeInsets.all(16),
                            child: Row(
                              children: [
                                // CachedNetworkImage(
                                //   height: 40,
                                //   width: 40,
                                //   imageUrl:
                                //   '$BASE_URL/${myController.cancelReason[index].imagePath}',
                                // ),
                                // SizedBox(width: 16),
                                Expanded(
                                  child: Text(
                                    myController.cancelReason[index].text,
                                    style: Get.textTheme.bodyText2,
                                  ),
                                ),
                                SizedBox(width: 16),
                                Radio(
                                  value: myController.cancelReason[index].id,
                                  groupValue: myController.groupValue,
                                  onChanged: (value) {
                                    myController.updateGroupValue(value);
                                  },
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                      itemCount: myController.cancelReason.length,
                    ),
                  ),
                ),
                SizedBox(height: 16),
                Text(
                  'Are you satisfied with your cancel reason?',
                  style: Get.textTheme.bodyText2,
                  textAlign: TextAlign.center,
                ),SizedBox(height: 16),
                Row(
                  children: [

                    Expanded(
                        child: CustomButton(
                          onPressed: () {
                            Navigator.pop(context);
                          },
                          text: 'No',
                          backgroundColor: Colors.red,
                        )),

                    VerticalDivider(
                      width: 1,
                      color: Colors.white,
                    ),
                    Expanded(
                        child: Container(
                          decoration: BoxDecoration(
                            borderRadius:
                            BorderRadius.only(bottomLeft: Radius.circular(10)),
                          ),
                          child: CustomButton(
                            onPressed: () async{
                              final response = await controller.cancelBooking();
                              if (response){
                                CustomSnackbar.showCustomSnackBar(message: 'Booking Cancelled');
                                Get.offAllNamed(Routes.DASHBOARD);
                                Navigator.pop(context);
                              }
                            },
                            text: 'Yes',
                            backgroundColor: Colors.green,
                          ),
                        )),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}