import 'package:get/get.dart';
import 'package:puryaideu/app/modules/ratings/controllers/ratings_controller.dart';

class RatingBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => RatingController());
  }

}