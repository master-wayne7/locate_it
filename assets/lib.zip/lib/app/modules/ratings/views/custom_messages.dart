class CustomMessages {

  static String ratingMessage(double rating) {
    String message = '';
    if (rating == 1) {
      message = 'Worst';
    } else if (rating == 1.5 || rating == 2) {
      message = 'Bad';
    } else if (rating == 2.5 || rating == 3) {
      message = 'Good';
    } else if (rating == 3.5 || rating == 4) {
      message = 'Better';
    } else {
      message = 'Best';
    }
    return message;
  }
}
