import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/data/models/rider.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/modules/history/controllers/history_controller.dart';
import 'package:puryaideu/app/modules/history/model/booking_history.dart';
import 'package:puryaideu/app/modules/history/views/history_view.dart';
import 'package:puryaideu/app/modules/home/controllers/home_controller.dart';
import 'package:puryaideu/app/modules/ratings/controllers/ratings_controller.dart';
import 'package:puryaideu/app/routes/app_pages.dart';
import 'package:puryaideu/app/widgets/custom_button.dart';
import 'package:puryaideu/app/widgets/custom_progress_bar.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:shimmer/shimmer.dart';

class RatingLaterScreen extends StatelessWidget {
  BookingHistory booking;
  Rider rider;
  HistoryController historyController = Get.find();
  final RatingController ratingController = Get.put(RatingController());

  RatingLaterScreen({this.booking, this.rider});


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
          child: GetBuilder<RatingController>(
            builder: (myController) => Stack(
              children: [
                Column(
                  children: [
                    Row(
                      children: [
                        IconButton(icon: Icon(Icons.arrow_back_sharp), onPressed: (){
                          Get.back();
                        },),
                        Expanded(flex: 2,child: SizedBox()),
                        GestureDetector(
                          onTap: (){
                          },
                          child: Center(
                            child: Text(
                              'Rate Rider'.tr,
                              style: Get.textTheme.headline6,
                            ),
                          ),
                        ),
                        Expanded(flex: 3, child: SizedBox()),
                      ],
                    ),
                    SizedBox(height: Get.height * 0.05),
                    ClipRRect(
                        borderRadius: BorderRadius.circular(50),
                        child: CachedNetworkImage(
                          imageUrl:
                          '$BASE_URL/${rider.imagePath}',
                          height: 100,
                          width: 100,
                          fit: BoxFit.cover,
                        )),
                    SizedBox(height: 8),
                    Text(
                      '${rider.firstName} ${rider.lastName}',
                      style: Get.textTheme.headline5,
                    ),
                    SizedBox(height: 8),
                    Text(
                      'Rider'.tr,
                      style: Get.textTheme.bodyText2.copyWith(color: Colors.grey),
                    ),
                    SizedBox(height: 16),
                    RatingBar(
                        minRating: 1.0,
                        initialRating: ratingController.rating,
                        glow: false,
                        direction: Axis.horizontal,
                        allowHalfRating: false,
                        itemCount: 5,
                        ratingWidget: RatingWidget(
                            full: Icon(Icons.star, color: Color(0xffFFD700)),
                            half: Icon(
                              Icons.star_half,
                              color: Color(0xffFFD700),
                            ),
                            empty: Icon(Icons.star_outline,
                                color: Color(0xffFFD700))),
                        onRatingUpdate: (value) {
                          ratingController.setRating(value);
                        }),
                    SizedBox(height: 16),
                    Obx(() => Text(ratingController.ratingResponse)),
                    SizedBox(height: 16), Expanded(
                      child: Container(
                          child: ratingController.ratingSuggestions.length > 0 ? ListView.builder(
                            padding: EdgeInsets.symmetric(horizontal: 16),
                            itemBuilder: (context, index) {
                              return Card(
                                child: Container(
                                  padding: EdgeInsets.all(16),
                                  child: Row(
                                    children: [
                                      CachedNetworkImage(
                                        height: 40,
                                        width: 40,
                                        imageUrl:
                                        '$BASE_URL/${myController.ratingSuggestions[index].imagePath}',
                                      ),
                                      SizedBox(width: 16),
                                      Expanded(
                                        child: Text(
                                          myController
                                              .ratingSuggestions[index].text,
                                          style: Get.textTheme.bodyText2,
                                        ),
                                      ),
                                      SizedBox(width: 16),
                                      Radio(
                                        value: myController
                                            .ratingSuggestions[index].id,
                                        groupValue: myController.groupValue,
                                        onChanged: (value) {
                                          myController.updateGroupValue(value);
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                            itemCount: myController.ratingSuggestions.length,
                          ): Shimmer.fromColors(
                            baseColor: Color(0xffeeeff3),
                            highlightColor: Colors.white,
                            enabled: true,
                            child: ListView.builder(
                              padding: EdgeInsets.symmetric(horizontal: 16),
                              itemBuilder: (context, index) {
                                return Card(
                                  child: Container(
                                    padding: EdgeInsets.all(16),
                                    child: Row(
                                      children: [
                                        ClipRRect(
                                            borderRadius: BorderRadius.circular(10),
                                            child: Container(
                                                height: 40,
                                                width: 40,
                                                color:Colors.white
                                            )),
                                        SizedBox(width: 16),
                                        Expanded(
                                          child: Container(
                                            width: 100,
                                            height: 14,
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius: BorderRadius.circular(16),
                                            ),
                                          ),
                                        ),
                                        SizedBox(width: 16),
                                      ],
                                    ),
                                  ),
                                );
                              },
                              itemCount: 3,
                            ),
                          )
                      ),
                    ),

                    // SizedBox(height: 16),
                    // Container(
                    //   margin: EdgeInsets.symmetric(horizontal: 16),
                    //   child: TextField(
                    //     maxLines: 10,
                    //     controller: ratingController.commentController,
                    //     cursorColor: Get.theme.primaryColor,
                    //     style: Get.textTheme.bodyText2,
                    //     textInputAction: TextInputAction.done,
                    //     onSubmitted: (_) => FocusScope.of(context).unfocus(),
                    //     decoration: InputDecoration(
                    //       hintText: 'Please review your customer.'.tr,
                    //       fillColor: Colors.grey.withOpacity(0.1),
                    //       filled: true,
                    //       border: OutlineInputBorder(
                    //         borderRadius: BorderRadius.circular(10),
                    //         borderSide: BorderSide(
                    //           color: Colors.grey.withOpacity(0.1),
                    //         ),
                    //       ),
                    //       enabledBorder: OutlineInputBorder(
                    //         borderRadius: BorderRadius.circular(10),
                    //         borderSide: BorderSide(
                    //           color: Colors.grey.withOpacity(0.1),
                    //         ),
                    //       ),
                    //       focusedBorder: OutlineInputBorder(
                    //         borderRadius: BorderRadius.circular(10),
                    //         borderSide: BorderSide(
                    //           color: Colors.grey.withOpacity(0.1),
                    //         ),
                    //       ),
                    //     ),
                    //   ),
                    // ),
                    SizedBox(height: 4),
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 16),
                      width: Get.width,
                      child: CustomButton(
                        backgroundColor: Get.theme.primaryColor,
                        onPressed: () async {
                          final response = await ratingController.ratingRider(booking.booking.id);
                          if (response) {
                            Get.back();
                            CustomSnackbar.showCustomSnackBar(message: 'Rider rated successfully. Thank you!');
                            // await homeController.getAvailableBookings();
                            historyController.getBikeHistoryCompleted(isRefresh: true);
                            historyController.getBikeHistoryCancelled(isRefresh: true);
                            historyController.getCarHistoryCompleted(isRefresh: true);
                            historyController.getCarHistoryCancelled(isRefresh: true);
                            historyController.getSafariHistoryCompleted(isRefresh: true);
                            historyController.getSafariHistoryCancelled(isRefresh: true);


                          } else {
                            CustomSnackbar.showCustomSnackBar(
                                message: 'something_went_wrong'.tr);
                          }
                        },
                        text: 'Rate Now'.tr,
                      ),
                    ),
                    SizedBox(height: 8),
                    SizedBox(height: 16),
                  ],
                ),
                Obx(
                      () => ratingController.showProgress
                      ? CustomProgressBar()
                      : Container(),
                ),
              ],
            ),
          ),
        ));
  }
}
