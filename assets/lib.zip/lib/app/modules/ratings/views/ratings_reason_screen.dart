
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/modules/ratings/controllers/ratings_controller.dart';
import 'package:puryaideu/app/widgets/custom_button.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';

class RatingReasonScreen extends StatefulWidget {
  @override
  _RatingReasonScreenState createState() => _RatingReasonScreenState();
}

class _RatingReasonScreenState extends State<RatingReasonScreen> {
  RatingController ratingController = Get.find();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          title: Text(
            'Rating Reasons'.tr,
            style:
            Get.textTheme.headline6.copyWith(color: Get.theme.primaryColor),
          ),
        ),
        body: SafeArea(
            child: GetBuilder<RatingController>(
              builder: (myController) => Container(
                margin: EdgeInsets.all(16),
                child: Column(
                  children: [
                    Expanded(
                      child: Container(
                        child: ListView.builder(
                          itemBuilder: (context, index) {
                            return Card(
                              child: Container(
                                padding: EdgeInsets.all(16),
                                child: Row(
                                  children: [
                                    CachedNetworkImage(
                                      height: 40,
                                      width: 40,
                                      imageUrl:
                                      '$BASE_URL/${myController.ratingSuggestions[index].imagePath}',
                                    ),
                                    SizedBox(width: 16),
                                    Expanded(
                                      child: Text(
                                        myController.ratingSuggestions[index].text,
                                        style: Get.textTheme.bodyText2,
                                      ),
                                    ),
                                    SizedBox(width: 16),
                                    Radio(
                                      value: myController.ratingSuggestions[index].id,
                                      groupValue: myController.groupValue,
                                      onChanged: (value) {
                                        myController.updateGroupValue(value);
                                      },
                                    ),
                                  ],
                                ),
                              ),
                            );
                          },
                          itemCount: myController.ratingSuggestions.length,
                        ),
                      ),
                    ),
                    SizedBox(
                      height: Get.height * 0.05,
                    ),
                    Container(
                      width: Get.width,
                      child: CustomButton(
                        onPressed: () async {
                          final response = await ratingController.ratingTask();
                          if (response) {
                            Get.back();
                          } else {
                            CustomSnackbar.showCustomSnackBar(
                                message: 'something_went_wrong'.tr);
                          }
                        },
                        text: 'Rate Driver'.tr,
                      ),
                    ),
                    SizedBox(
                      height: Get.height * 0.05,
                    ),
                  ],
                ),
              ),
            )));
  }
}

// ratingController.showProgressBar();
//                         bool rateStatus = await ratingController.ratingTask();
//                         if (rateStatus) {
//                           Get.back();
//                         } else {
//                           CustomSnackbar.showCusotmSnackBar(
//                               message: ratingController.error);
//                         }
//                         ratingController.hideProgressBar();
