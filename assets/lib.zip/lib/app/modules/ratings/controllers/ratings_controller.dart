
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/data/models/booking.dart';
import 'package:puryaideu/app/data/models/completed_trip.dart';
import 'package:puryaideu/app/data/models/rider.dart';
import 'package:puryaideu/app/modules/ratings/models/cancel_reason.dart';
import 'package:puryaideu/app/modules/ratings/models/rating_request.dart';
import 'package:puryaideu/app/modules/ratings/models/ratings_cancel_repository.dart';
import 'package:puryaideu/app/modules/ratings/models/suggestions.dart';
import 'package:puryaideu/app/modules/ratings/views/custom_messages.dart';

class RatingController extends GetxController {
  final _rating = 3.0.obs;
  //Customer user;
  //final user = Customer().obs;
  final user = Rider().obs;
  CompletedTrip _booking;
  CompletedTrip get booking => _booking;
  void setBooking(booking) => _booking = booking;
  TextEditingController commentController = TextEditingController();
  String _error;
  final _progressBarStatus = false.obs;
  List<CancelReason> _ratingReasons = [];
  List<Suggestion> _ratingSuggestions = [];
  int _groupValue;


  int get groupValue => _groupValue;
  List<CancelReason> get ratingReasons => _ratingReasons;
  List<Suggestion> get ratingSuggestions => _ratingSuggestions;


  @override
  void onInit() {
    super.onInit();
    getRatingReasons();
  }

  updateGroupValue(int id) {
    _groupValue = id;
    update();
  }

  double get rating => _rating.value;
  String get error => _error;
  bool get showProgress => _progressBarStatus.value;
  String get ratingResponse => CustomMessages.ratingMessage(_rating.value);


  setRating(double value) {
    _rating.value = value;
  }

  Future<bool> ratingTask() async {
    final response = await RatingRequest.rateUser(
        booking.id, _rating.value, _groupValue, 'User')
        .catchError((message) {
      _error = message;
    });


    if (response == null) {
      return false;
    }

    if(response != "Ride Review Successful!"){
      return false;
    }

    return true;
  }

  Future<bool> ratingRider(int id) async {
    final response = await RatingRequest.rateUser(
        id, _rating.value, _groupValue, 'User')
        .catchError((message) {
      _error = message;
    });


    if (response == null) {
      return false;
    }

    if(response != "Ride Review Successful!"){
      return false;
    }

    return true;
  }

  getRatingReasons() async{
    final reasons =  await RatingsAndCancelRepository.getRatingReasons();
    updateRatingReasons(reasons);

  }

  updateRatingReasons(List<Suggestion> list) {
    _ratingSuggestions = list;
    _groupValue = _ratingSuggestions[0].id;
    update();
  }

  showProgressBar() => _progressBarStatus.value = true;
  hideProgressBar() => _progressBarStatus.value = false;
}
