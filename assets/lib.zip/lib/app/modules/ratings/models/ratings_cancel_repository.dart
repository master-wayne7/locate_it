
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/data/network/constant_headers.dart';
import 'package:puryaideu/app/data/network/network_helper.dart';
import 'package:puryaideu/app/enums/header_type.dart';
import 'package:puryaideu/app/modules/ratings/models/suggestions.dart';

import 'cancel_reason.dart';


class RatingsAndCancelRepository {

  static Future<List<CancelReason>> getCancelReasons() async {
    String url = '$BASE_URL/api/suggestion/booking_cancel_by_user';
    try {
      final response = await NetworkHelper().getRequest(url,
          contentType:
          ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
      print('response is=== $response');
      final data = response.data;
      final reasonResponse = data['suggestions'];
      List<CancelReason> reasons = (reasonResponse as List)
          .map((i) => CancelReason.fromJson(i))
          .toList();

      return reasons;
    } catch (e) {
      print("Exception=== $e");
      return Future.error(e.toString());
    }
  }

  static Future<List<Suggestion>> getRatingReasons() async {
    String url = '$BASE_URL/api/suggestion/review_by_user';
    try {
      final response = await NetworkHelper().getRequest(url,
          contentType:
          ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
      final data = response.data;
      final reasonResponse = data['suggestions'];

      List<Suggestion> reasons = (reasonResponse as List)
          .map((i) => Suggestion.fromJson(i))
          .toList();

      return reasons;
    } catch (e) {
      print("Exception=== $e");
      return Future.error(e.toString());
    }
  }
}
