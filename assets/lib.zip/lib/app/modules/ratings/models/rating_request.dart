import 'dart:convert';
import 'dart:io';

import 'package:get/get.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/data/network/constant_headers.dart';
import 'package:puryaideu/app/data/network/network_helper.dart';
import 'package:puryaideu/app/enums/header_type.dart';
class RatingRequest {

  static Future<dynamic> rateUser(
      int id, double rate, int comment, String rateReasonId) async {
    String url = '$BASE_URL/api/review/create';
    String body =
    jsonEncode({
      "booking_id": id,
      "rate": rate,
      "comment": comment.toString(),
      "reviewed_by_role": "customer"
    });

    try {
      final response = await NetworkHelper().postRequest(url,
          data: body,
          contentType: ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));

      print('Body here===  $body');
      print('Response rating ==== $response');
      String data = response.data["message"];
      return data;
    } on SocketException {
      Future.error('no_internet_connection'.tr);
    } catch (e) {
      Future.error(e.toString());
    }
  }
}
