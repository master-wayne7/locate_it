class CancelReason {
  CancelReason({
    this.id,
    this.text,
  });

  int id;
  String text;

  factory CancelReason.fromJson(Map<String, dynamic> json) => CancelReason(
    id: json["id"],
    text: json["text"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "text": text,
  };
}
