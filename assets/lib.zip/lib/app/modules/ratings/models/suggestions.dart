class Suggestion {
  Suggestion({
    this.id,
    this.text,
    this.category,
    this.thumbnailPath,
    this.imagePath,
  });

  int id;
  String text;
  String category;
  String thumbnailPath;
  String imagePath;

  factory Suggestion.fromJson(Map<String, dynamic> json) => Suggestion(
    id: json["id"],
    text: json["text"],
    category: json["category"],
    thumbnailPath: json["thumbnail_path"],
    imagePath: json["image_path"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "text": text,
    "category": category,
    "thumbnail_path": thumbnailPath,
    "image_path": imagePath,
  };
}
