import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/data/models/notifications.dart';
import 'package:puryaideu/app/data/models/promo.dart';
import 'package:puryaideu/app/data/network/promo_request.dart';
import 'package:puryaideu/app/enums/notification_enum.dart';

class NotificationsController extends GetxController {
  final notificationList = [].obs;

  var notificationIndex = 1.obs;

  final selectedNotification = Notifications().obs;

  final notificationType = NotiType.CAMPAIGN.obs;

  final currentPage = 0.obs;

  String error = '';
  bool returnValue = false;
  bool promoReturnValue = false;

  final promotionList = [].obs;

  var promoIndex = 1.obs;

  final selectedPromo = Promo().obs;

  final pageController = PageController(initialPage: 0, keepPage: true).obs;

  setSelectedPromotion(Promo promo) => selectedPromo.value = promo;

  setSelectedNotification(Notifications notification) => selectedNotification.value = notification;


  final count = 0.obs;
  @override
  void onInit() {
    //getPromotion(isRefresh: true);
    getCampaign(isRefresh: true);
    getPromotion(isRefresh: true);
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
  }

  @override
  void onClose() {}
  void increment() => count.value++;

  void updateSelectedNotiType(NotiType _notificationType) {
    switch (_notificationType) {
      case NotiType.CAMPAIGN:
        notificationType.value = NotiType.CAMPAIGN;
        currentPage.value = 0;
        break;

      case NotiType.PROMO:
        notificationType.value = NotiType.PROMO;
        currentPage.value = 1;
        break;

    }
    // animatePage();
  }



  Future<bool> getPromotion({bool isRefresh = false}) async {

    if (isRefresh) {
      promoIndex.value = 1;
    }

    await PromoRequest.getPromotionList(promoIndex.value)
        .catchError((error) {
      this.error = error;
    }).then((value) {
      if (value == null) {
        promoReturnValue = false;
        return promoReturnValue;
      }
      if (value.isEmpty) {
        promoReturnValue = false;
        return promoReturnValue;
      } else {
        promoReturnValue = true;
      }

      if (isRefresh) {
        promotionList.value = value;
        promoIndex.value = 2;
      } else if (value.isNotEmpty) {
        promoIndex++;
        promotionList.addAll(value);
      }

      setSelectedPromotion(promotionList[0]);
    });

    return promoReturnValue;
  }


  Future<bool> getCampaign({bool isRefresh = false}) async {
    if (isRefresh) {
      notificationIndex.value = 1;
    }

    await PromoRequest.getNotificationList(notificationIndex.value)
        .catchError((error) {
      this.error = error;
    }).then((value) {
      if (value == null) {
        returnValue = false;
        return returnValue;
      }
      if (value.isEmpty) {
        returnValue = false;
        return returnValue;
      } else {
        returnValue = true;
      }

      if (isRefresh) {
        notificationList.value = value;
        notificationIndex.value = 2;
      } else if (value.isNotEmpty) {
        notificationIndex++;
        notificationList.addAll(value);
      }

      setSelectedNotification(notificationList[0]);
    });

    return returnValue;
  }
}
