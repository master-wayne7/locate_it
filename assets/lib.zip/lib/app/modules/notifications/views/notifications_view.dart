import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/generated/locales.g.dart';

import '../controllers/notifications_controller.dart';
import 'campaign_view.dart';
import 'promo_view.dart';

class NotificationsView extends StatefulWidget {
  @override
  _NotificationsViewState createState() => _NotificationsViewState();
}

class _NotificationsViewState extends State<NotificationsView>
    with SingleTickerProviderStateMixin {
  final NotificationsController controller = Get.find();

  TabController tabController;

  @override
  void initState() {
    super.initState();

    tabController = TabController(length: 2, vsync: this);
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  List<String> data = ['Campaigns', 'Promotions'];
  final List pageContent = [
    PromoView(),
    CampaignView(),
  ];

  int initPosition = 1;

  Widget getTabBar() {
    return TabBar(
        controller: tabController,
        labelColor: Colors.white,
        labelStyle: Get.textTheme.headline5.copyWith(
            fontFamily: 'Poppins',
            fontSize: getResponsiveFont(16),
            fontWeight: FontWeight.w600),
        unselectedLabelColor: Colors.grey[400],
        indicatorSize: TabBarIndicatorSize.tab,
        indicatorColor: Color(0xffeeeff3),
        tabs: [
          Tab(
            child: Align(
              alignment: Alignment.center,
              child: Text(LocaleKeys.notifications_CAMPAIGNS.tr),
            ),
          ),
          Tab(
            child: Align(
              alignment: Alignment.center,
              child: Text(LocaleKeys.notifications_PROMOTIONS.tr),
            ),
          )
        ]);
  }

  Widget getTabBarPages() {
    return TabBarView(controller: tabController, children: <Widget>[
      CampaignView(),
      PromoView(),
    ]);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: Color(0xffeeeff3),
        extendBodyBehindAppBar: true,
        appBar: AppBar(
          backgroundColor: Get.theme.primaryColor,
          elevation: 0.6,
          systemOverlayStyle: SystemUiOverlayStyle.light,
          flexibleSpace: FlexibleSpaceBar(
            
              background: SafeArea(child: getTabBar())),
        ),
        body: getTabBarPages());
  }
}
