import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/config/custom_colors.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/modules/notifications/controllers/notifications_controller.dart';
import 'package:shimmer/shimmer.dart';

class CampaignView extends GetView<NotificationsController> {
  final RefreshController refreshControllerCampaign =
      RefreshController(initialRefresh: false);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Column(children: [
        Expanded(
          child: Obx(() => SmartRefresher(
                controller: refreshControllerCampaign,
                enablePullDown: true,
                enablePullUp: true,
                header: ClassicHeader(
                  refreshStyle: RefreshStyle.Follow,
                  releaseIcon: SizedBox(
                      width: 25.0,
                      height: 25.0,
                      child: const CupertinoActivityIndicator()),
                  failedIcon: Icon(Icons.error, color: Colors.grey),
                  idleIcon: SizedBox(
                      width: 25.0,
                      height: 25.0,
                      child: CupertinoActivityIndicator.partiallyRevealed(
                        progress: 0.4,
                      )),
                  textStyle: Get.textTheme.headline5.copyWith(
                      fontFamily: 'Roboto',
                      color: Get.theme.primaryColor,
                      fontWeight: FontWeight.w500),
                  releaseText: '',
                  idleText: '',
                  failedText: '',
                  completeText: '',
                  refreshingText: '',
                  refreshingIcon: SizedBox(
                      width: 25.0,
                      height: 25.0,
                      child: const CupertinoActivityIndicator()),
                ),
                footer: ClassicFooter(
                  // refreshStyle: RefreshStyle.Follow,
                  canLoadingText: '',
                  loadStyle: LoadStyle.ShowWhenLoading,
                  noDataText: '',
                  noMoreIcon: SizedBox(
                      width: 25.0,
                      height: 25.0,
                      child: Icon(FontAwesomeIcons.exclamationCircle,
                          color: redColor)),
                  canLoadingIcon: SizedBox(
                      width: 25.0,
                      height: 25.0,
                      child: const CupertinoActivityIndicator()),
                  failedIcon: Icon(Icons.error, color: Colors.grey),
                  idleIcon: SizedBox(
                      width: 25.0,
                      height: 25.0,
                      child: CupertinoActivityIndicator.partiallyRevealed(
                        progress: 0.4,
                      )),
                  textStyle: Get.textTheme.headline5.copyWith(
                      fontFamily: 'Roboto',
                      color: Get.theme.primaryColor,
                      fontWeight: FontWeight.w500),
                  idleText: '',
                  failedText: '',
                  loadingText: '',
                  loadingIcon: SizedBox(
                      width: 25.0,
                      height: 25.0,
                      child: const CupertinoActivityIndicator()),
                ),
                onRefresh: () async {
                  final result = await controller.getCampaign(isRefresh: true);
                  if (result == true) {
                    refreshControllerCampaign.resetNoData();
                    refreshControllerCampaign.refreshCompleted();
                  } else {
                    refreshControllerCampaign.refreshFailed();
                  }
                },
                onLoading: () async {
                  final result = await controller.getCampaign(isRefresh: false);
                  if (result) {
                    refreshControllerCampaign.requestLoading(
                        duration: Duration(seconds: 1));
                    Future.delayed(const Duration(milliseconds: 1000), () {
                      refreshControllerCampaign.loadComplete();
                    });
                  } else {
                    Future.delayed(const Duration(milliseconds: 1000), () {
                      refreshControllerCampaign.loadComplete();
                    });
                    // refreshControllerCampaign.loadNoData();
                  }
                },
                child: controller.notificationList.length != 0
                    ? ListView.builder(
                        scrollDirection: Axis.vertical,
                        shrinkWrap: true,
                        padding: EdgeInsets.only(left: 16, top: 16, right: 16),
                        itemCount: controller.notificationList.length,
                        itemBuilder: (
                          context,
                          index,
                        ) {
                          return GestureDetector(
                              onTap: () {},
                              child: CampaignWidget(
                                title: controller.notificationList[index].title,
                                body:
                                    controller.notificationList[index].message,
                                imagePath: controller
                                    .notificationList[index].imagePath,
                                dateTime: controller
                                    .notificationList[index].createdAt,
                              ));
                        })
                    : ListView.builder(
                        scrollDirection: Axis.vertical,
                        shrinkWrap: true,
                        itemCount: 4,
                        itemBuilder: (
                          context,
                          index,
                        ) {
                          return GestureDetector(
                              onTap: () {},
                              child: Shimmer.fromColors(
                                baseColor: Color(0xffeeeff3),
                                highlightColor: Colors.white,
                                enabled: true,
                                child: CampaignWidget(
                                  title: 'Hehe',
                                  body: 'HoHoHO',
                                  dateTime: DateTime.now(),
                                  imagePath:
                                  '$BASE_URL/assets/media/noimage.png',
                                ),
                              ));
                        }),
              )),
        ),
      ]),
    );
  }
}

class CampaignWidget extends StatelessWidget {
  final String _title;
  final String _body;
  final DateTime _dateTime;
  final String _imagePath;

  CampaignWidget({
    @required String title,
    @required String body,
    @required DateTime dateTime,
    @required String imagePath,
  })  : _title = title,
        _imagePath = imagePath,
        _dateTime = dateTime,
        _body = body;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(5),
          color: Colors.white,
          border: Border.all(color: Colors.grey.withOpacity(0.2)),
          boxShadow: [
            BoxShadow(
              offset: const Offset(3.0, 3.0),
              blurRadius: 2.0,
              color: Colors.grey.withOpacity(0.5),
              spreadRadius: 0.8,
            ),
          ]),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Padding(
          //   padding: const EdgeInsets.only(left: 16.0, top: 16.0),
          //   child: Icon(
          //     Icons.local_attraction,
          //     color: Get.theme.primaryColor,
          //     size: getResponsiveFont(22),
          //   ),
          // ),
          Expanded(
            child: Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  SizedBox(
                    height: 14,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        ClipOval(
                          child: Material(
                            color: redColor, // Button color
                            child: InkWell(
                              onTap: () {},
                              child: SizedBox(
                                width: 32,
                                height: 32,
                                child: Icon(FontAwesomeIcons.fireAlt,
                                    size: 18, color: Colors.white),
                              ),
                            ),
                          ),
                        ),
                        SizedBox(width: 16),
                        Expanded(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                _title,
                                textAlign: TextAlign.start,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: Get.textTheme.headline5.copyWith(
                                    fontSize: getResponsiveFont(16),
                                    fontFamily: 'Roboto',
                                    fontWeight: FontWeight.w600,
                                    color: Colors.grey[800]),
                              ),
                              SizedBox(height: 4),
                              Text(
                                _dateTime.difference(DateTime.now()).inDays > 0
                                    ? DateFormat('yyyy-MM-dd hh:mm a')
                                        .format(_dateTime)
                                        .toString()
                                    : DateFormat('hh:mm a')
                                        .format(_dateTime)
                                        .toString(),
                                textAlign: TextAlign.start,
                                overflow: TextOverflow.ellipsis,
                                maxLines: 1,
                                style: Get.textTheme.headline5.copyWith(
                                    fontSize: getResponsiveFont(12),
                                    fontFamily: 'Roboto',
                                    fontWeight: FontWeight.w400,
                                    color: Colors.grey[500]),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  SizedBox(height: 10),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    child: Container(
                      height: Get.height * 0.14,
                      width: Get.width * 1,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(5.0),
                        child: CachedNetworkImage(
                          imageUrl: '$BASE_URL/$_imagePath',
                          maxWidthDiskCache: getResponsiveFont(300).toInt(),
                          maxHeightDiskCache: getResponsiveFont(300).toInt(),
                          progressIndicatorBuilder:
                              (context, url, downloadProgress) =>
                                  Shimmer.fromColors(
                            baseColor: Color(0xffeeeff3),
                            highlightColor: Colors.white,
                            enabled: true,
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(5),
                              ),
                            ),
                          ),
                          errorWidget: (context, url, error) =>
                              Shimmer.fromColors(
                            baseColor: Color(0xffeeeff3),
                            highlightColor: Colors.white,
                            enabled: true,
                            child: Container(
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(5),
                              ),
                            ),
                          ),
                          fit: BoxFit.cover,
                        ),
                      ),
                    ),
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 16),
                    child: Text(
                      _body,
                      overflow: TextOverflow.ellipsis,
                      maxLines: 4,
                      textAlign: TextAlign.start,
                      style: Get.textTheme.headline5.copyWith(
                          fontSize: getResponsiveFont(14),
                          fontFamily: 'Roboto',
                          fontWeight: FontWeight.w500,
                          color: Colors.grey[600]),
                    ),
                  ),
                  SizedBox(
                    height: Get.height * 0.01,
                  ),
                ]),
          ),
        ],
      ),
    );
  }
}
