import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:puryaideu/app/config/custom_colors.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/modules/auth/views/phone_login_button.dart';
import 'package:puryaideu/app/routes/app_pages.dart';
import 'package:puryaideu/app/widgets/custom_dropdown_menu.dart';
import 'package:puryaideu/app/widgets/custom_progress_bar.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:puryaideu/app/widgets/phone_input_field.dart';
import 'package:puryaideu/generated/locales.g.dart';

import '../controllers/phone_login_controller.dart';

class PhoneLoginView extends GetView<PhoneLoginController> {
  @override
  Widget build(BuildContext context) {
    final node = FocusScope.of(context);
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xfffafafa),
        leading: IconButton(
          onPressed: () {
            Navigator.pop(context);
          },
          icon: Icon(Icons.arrow_back, color: Colors.black),
        ),
        elevation: 0,
        title: Text("Continue with phone",
            style: Get.textTheme.headline5.copyWith(
              fontSize: getResponsiveFont(18),
              color: Colors.black,
              fontWeight: FontWeight.w600,
              letterSpacing: 1.0,
            )),
        centerTitle: true,
      ),
      body: SafeArea(
          child: SingleChildScrollView(
        physics: NeverScrollableScrollPhysics(),
        child: Stack(
          children: [
            Column(
              children: [
                // Row(
                //   children: [
                //     InkWell(
                //       borderRadius: BorderRadius.circular(30),
                //       child: Padding(
                //         padding: const EdgeInsets.all(16.0),
                //         child: Icon(Icons.arrow_back),
                //       ),
                //       onTap: () {
                //         Get.back();
                //       },
                //     ),
                //     Text("Continue with phone",
                //         style: Get.textTheme.headline5
                //             .copyWith(fontSize: getResponsiveFont(18))),
                //     Expanded(child: Container()),
                //   ],
                // ),
                Container(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      Center(
                        child: Container(
                          width: Get.width * 0.6,
                          height: Get.height * 0.3,
                          child: Image.asset(
                            'assets/phone.png',
                            fit: BoxFit.fill,
                          ),
                        ),
                      ),
                      SizedBox(height: Get.height * 0.02),
                      Text("You'll receiver a 5 digit code\nto verify next.",
                          textAlign: TextAlign.center,
                          style: Get.textTheme.headline5.copyWith(
                              color: Colors.grey[600],
                              fontSize: getResponsiveFont(18))),
                      SizedBox(height: Get.height * 0.03),

                      // Text(LocaleKeys.text_phone_input.tr,
                      //     style: Get.textTheme.headline5
                      //         .copyWith(fontSize: getResponsiveFont(18))),
                      // SizedBox(height: Get.height * 0.05),
                      // Text(
                      //   LocaleKeys.text_phone_usecase_message.tr,
                      //   style: Get.textTheme.bodyText2.copyWith(
                      //       fontSize: getResponsiveFont(12), color: Colors.grey),
                      // ),
                      // SizedBox(height: Get.height * 0.05),
                      Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 24),
                        child: Text("Enter your phone",
                            textAlign: TextAlign.justify,
                            style: Get.textTheme.headline5.copyWith(
                                color: Colors.grey[600],
                                fontWeight: FontWeight.w600,
                                fontSize: getResponsiveFont(14))),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16),
                        child: PhoneInputField(
                          controller: controller.phoneInputController,
                          onChanged: (input) {
                            controller.setPhoneInput(input);
                            if (controller.phoneInput.length == 10) {
                              SystemChannels.textInput
                                  .invokeMethod('TextInput.hide');
                            }
                          },
                          prefix: Padding(
                            padding: const EdgeInsets.only(
                              right: 8.0,
                              bottom: 8,
                            ),
                            child: Obx(
                              () => CustomDropDownMenu(
                                country: true,
                                onChanged: (value) {
                                  controller.setSelectedCountryPhone(value);
                                },
                                value: controller.countryCode.value,
                                itemList: controller.countryOption,
                              ),
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: Get.height * 0.05),
                      Obx(
                        () => Container(
                          margin: EdgeInsets.symmetric(horizontal: 16),
                          child: PhoneLoginButton(
                            onPressed: controller.enableSubmit.value
                                ? () async {
                                    node.unfocus();
                                    final status =
                                        await controller.callServerForOTP();
                                    if (!status) {
                                      CustomSnackbar.showCustomSnackBar(
                                          message: controller.errorMessage);
                                      return;
                                    }
                                    final response = await Get.toNamed(
                                        Routes.OTP,
                                        arguments: controller.phoneInput);
                                    if (response != null && response) {
                                      Navigator.pop(context, true);
                                    }
                                  }
                                : null,
                            backgroundColor: controller.enableSubmit.value
                                ? null
                                : kGreyColor,
                            title: LocaleKeys.buttons_continue.tr,
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
            controller.progressbarStatus.value
                ? CustomProgressBar()
                : Container()
          ],
        ),
      )),
    );
  }
}
