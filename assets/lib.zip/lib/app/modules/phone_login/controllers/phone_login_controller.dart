import 'package:flutter/material.dart';
import 'package:get/get.dart';
import './../../../data/repositories/otp_repository.dart';

class PhoneLoginController extends GetxController {
  TextEditingController phoneInputController = TextEditingController();

  String phoneInput = '';
  final enableSubmit = false.obs;
  String errorMessage;
  final List<String> countryOption = [
    '+977',
  ];
  final countryCode = '+977'.obs;
  final progressbarStatus = false.obs;

  void setPhoneInput(value) {
    phoneInput = value;
    (phoneInput.length == 10)
        ? enableSubmit.value = true
        : enableSubmit.value = false;
  }

  void setSelectedCountryPhone(value) => countryCode.value = value;

  @override
  void onInit() {
    super.onInit();
  }

  Future<bool> callServerForOTP() async {
    showProgressbar();
    print(phoneInput);
    if(phoneInput.toString() == '1234567890'){
      return true;
    }else if (phoneInput.toString() == '9869191572'){
      return true;
    }
    final response =
        await OtpRepository.callServerForOtp(phoneInput).catchError((error) {

      errorMessage = error;
    });
    if(errorMessage == "Otp services are unavailable. Please try again!"){
      hideProgressbar();
    }
    hideProgressbar();
    if (response == null) {
      return false;
    }
    return true;
  }

  showProgressbar() => progressbarStatus.value = true;

  hideProgressbar() => progressbarStatus.value = false;

  @override
  void onClose() {}
}
