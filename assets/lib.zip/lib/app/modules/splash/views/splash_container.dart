import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lottie/lottie.dart';

class SplashContainer extends StatelessWidget {

  @override
  Widget build(BuildContext context) {

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Image.asset(
            'assets/logo.png',
            height: Get.width * 0.5,
            width: Get.width * 0.5,
            fit: BoxFit.fill,
          ),
          SizedBox(height: 16),
          Lottie.asset('assets/animations/car_animation1.json'),
        ],
      ),
    );
  }
}