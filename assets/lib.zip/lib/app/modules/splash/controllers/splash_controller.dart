import 'package:connectivity/connectivity.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/utils/network_connectivity.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:puryaideu/app/routes/app_pages.dart';
import './../../../data/repositories/user_repository.dart';

class SplashController extends GetxController with StateMixin<dynamic>{

  @override
  void onInit() {
    startLoader();
    super.onInit();
  }



  void showConnectivitySnackBar(ConnectivityResult result) {
    final hasInternet = result != ConnectivityResult.none;

    print("Has internet value === $hasInternet");
    if(!hasInternet){
      Get.dialog(InternetDialog(), barrierDismissible: false, barrierColor: Colors.black.withOpacity(0.8));
    }
    //NetworkConnectivity.showTopSnackBar(context, message, color);

  }

  startLoader() async {
    final result = await Connectivity().checkConnectivity();
    showConnectivitySnackBar(result);

    Future.delayed(Duration(seconds: 3)).then((value) async{
      SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
      UserRepository repository = UserRepository(prefs: sharedPreferences);
      var previouslyLaunched = await repository.isAppLaunchedPreviously();
      final logged = await repository.isLoggedIn();
      if (logged) {
        final token = await repository.getAccessToken();
        print(token);
        SessionManager.instance.setAccessToken(token);
        SessionManager.instance.setVoucherCode(null);
        Get.offNamed(Routes.DASHBOARD);
        // Get.offNamed(Routes.TEST);
      } else {
        Get.offNamed(previouslyLaunched ? Routes.AUTH : Routes.ONBOARDING_SCREEN);
        //Get.offNamed(previouslyLaunched ? Routes.ONBOARDING_SCREEN : Routes.ONBOARDING_SCREEN);
      }
      change(value, status: RxStatus.success());
    });
  }
}
