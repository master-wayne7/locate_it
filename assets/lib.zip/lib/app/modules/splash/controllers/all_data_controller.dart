
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/data/network/promo_request.dart';

class AllDataController extends GetxController{
  String errorMessage;

  final promoList = [].obs;
  final imageList = [].obs;
  final codeList = [].obs;
  final progressBarStatus = false.obs;

  final  homeEnabled = true.obs;

  TextEditingController promoController = TextEditingController();

  List<String> imageStringList = [];
  List<String> codeStringList = [];

  @override
  void onInit() {
    getPromoCarousel();
    super.onInit();
  }

  showProgressBar() => progressBarStatus.value = true;

  hideProgressBar() => progressBarStatus.value = false;

  Future<bool> getPromoCarousel() async {
    homeEnabled.value = true;
    final value = await PromoRequest.getPromoList()
        .catchError((error) {
      this.errorMessage = error;
    });
    if (value == null) {
      return false;
    } else if (value.isEmpty) {
      return false;
    }else{
      List<PromoRequestModel> listP =
      (value as List).map((i) => PromoRequestModel.fromJson(i)).toList();
      promoList.value = [].obs;
      promoList.value = listP;
      codeList.value = [].obs;
      imageList.value = [].obs;
      for (int index = 0; index < promoList.length; index++) {
        String img = '$BASE_URL/${promoList[index].imagePath}';
        imageList.add(img);
        codeList.add(promoList[index].code);
      }
      print(imageStringList);
      print(codeList);
      homeEnabled.value = false;
      print(homeEnabled.value);
      return true;
    }
  }

  checkPromoCode(String promoCodeCheck) async {
    showProgressBar();

    var response = await PromoRequest.checkPromoValidity(promoCodeCheck)
        .catchError((error) {
      errorMessage = error;
    });
    print('response is $response');
    print(errorMessage);
    if(response == true){
      hideProgressBar();
      return true;
    }
    if (response == null) {
      hideProgressBar();
      return false;
    }

    if (response.isEmpty) {
      hideProgressBar();
      return false;
    }
  }

}