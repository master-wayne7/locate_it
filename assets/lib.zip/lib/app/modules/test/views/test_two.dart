import 'package:flutter/material.dart';

class TestTwo extends StatefulWidget {
  String notificationValue;

  TestTwo({this.notificationValue});

  @override
  State<TestTwo> createState() => _TestTwoState();
}

class _TestTwoState extends State<TestTwo> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('TestTwo'),
          centerTitle: true,
        ),
        body: Container(
          padding: EdgeInsets.all(16),
          child: Column(
            children: [
              Text(widget.notificationValue),
            ],
          ),
        ));
  }
}
