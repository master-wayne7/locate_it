import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:rxdart/rxdart.dart';

class NotificationTester {
  static final _notifications = FlutterLocalNotificationsPlugin();
  static final onNotifications = BehaviorSubject<String>();

  static Future _notificationDetails() async {
    return NotificationDetails(
      android: AndroidNotificationDetails(
          'channel id', 'channel name', 'channel description',
          // styleInformation: styleInformation,
          enableVibration: true,
          importance: Importance.max),
      iOS: IOSNotificationDetails(
          presentSound: true,
          presentAlert: true,
          presentBadge: true),
    );
  }

  static Future _customNotificationDetails() async {
    // largeIconPath = await Utils.downloadFile();

    // final styleInformation = BigPictureStyleInformation(
    //   FilePathAndroidBitmap(bigPicturePath),
    //   largeIcon: FilePathAndroidBitmap(largeIconPath),
    // );
    final sound = 'notification_sound.wav';

    return NotificationDetails(
      android: AndroidNotificationDetails(
          'channel id 1', 'channel name', 'channel description',
          // styleInformation: styleInformation,
          enableVibration: true,
          sound: RawResourceAndroidNotificationSound(sound.split('.').first),
          importance: Importance.max),
      iOS: IOSNotificationDetails(
          sound: sound,
          presentSound: true,
          presentAlert: true,
          presentBadge: true),
    );
  }

  static Future init({bool initScheduled = false}) async {
    final android = AndroidInitializationSettings('@mipmap/ic_launcher');
    final iOS = IOSInitializationSettings();
    final settings = InitializationSettings(android: android, iOS: iOS);

    //Background Notification
    final details = await _notifications.getNotificationAppLaunchDetails();
    if (details != null && details.didNotificationLaunchApp) {
      onNotifications.add(details.payload);
    }

    await _notifications.initialize(settings,
        onSelectNotification: (payload) async {
      onNotifications.add(payload);
    });
  }

  static Future showNotification({
    int id = 0,
    String title,
    String body,
    String payload,
  }) async =>
      _notifications.show(id, title, body, await _notificationDetails(),
          payload: payload);

  static Future showCustomNotification({
    int id = 1,
    String title,
    String body,
    String payload,
  }) async =>
      _notifications.show(id, title, body, await _customNotificationDetails(),
          payload: payload);
}
