import 'package:flutter/material.dart';
import 'package:geocoding/geocoding.dart';
import 'package:geolocator/geolocator.dart';

import 'package:get/get.dart';

import '../controllers/test_controller.dart';
import 'notification_tester.dart';
import 'test_two.dart';

class TestView extends StatefulWidget {
  final TestController testController = Get.find();

  TestView({Key key}) : super(key: key);

  @override
  State<TestView> createState() => _TestViewState();
}

class _TestViewState extends State<TestView> {
  var _latitude = "";
  var _longitude = "";
  var _altitude = "";
  var _speed = "";
  var _address = "";

  @override
  void initState() {
    super.initState();
    NotificationTester.init();
    listenNotifications();
  }

  void listenNotifications() =>
      NotificationTester.onNotifications.stream.listen(onClickedNotification);

  void onClickedNotification(String payload) => Get.to(() => TestTwo(
        notificationValue: payload,
      ));

  Future<Position> _determinePosition() async {
    bool serviceEnabled;
    LocationPermission permission;
    serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) {
      return Future.error('Location services are disabled.');
    }

    permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied) {
        return Future.error('Location permissions are denied');
      }
    }

    if (permission == LocationPermission.deniedForever) {
      return Future.error(
          'Location permissions are permanently denied, we cannot request permissions.');
    }
    return await Geolocator.getCurrentPosition();
  }

  Future<void> _updatePosition() async {
    Position pos = await _determinePosition();
    List pm = await placemarkFromCoordinates(pos.latitude, pos.longitude);
    setState(() {
      _latitude = pos.latitude.toString();
      _longitude = pos.longitude.toString();
      _altitude = pos.altitude.toString();
      _speed = pos.speed.toString();
      _address = pm[0].toString();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('TestView'),
        centerTitle: true,
      ),
      body: Container(
        padding: EdgeInsets.all(16),
        child: Center(
          child: Column(
            children: [
              ElevatedButton(
                  onPressed: () => NotificationTester.showNotification(
                        title: 'Simple Noti',
                        body: 'Hey, We are just testing notifications.',
                        payload: 'foreground_notification',
                      ),
                  child: Text('Foreground Notification')),
              ElevatedButton(
                  onPressed: () => Future.delayed(Duration(seconds: 10))
                      .then((_) => NotificationTester.showNotification(
                            title: 'Background Noti',
                            body: 'Hey, We are just testing notifications.',
                            payload: 'background_notification',
                          )),
                  child: Text('Background Notification')),
              ElevatedButton(
                  onPressed: () => NotificationTester.showCustomNotification(
                        title: 'Sound Noti',
                        body: 'Hey, We are just testing notifications.',
                        payload: 'sound_notification',
                      ),
                  child: Text('Custom Sound')),
              Text('Your last know location is:'),
              Text(
                'Latitude: ' + _latitude,
                style: TextStyle(fontSize: 20),
              ),
              Text(
                'Longitude: ' + _longitude,
                style: TextStyle(fontSize: 20),
              ),
              Text(
                'Altitude: ' + _altitude,
                style: TextStyle(fontSize: 20),
              ),
              Text(
                'Speed: ' + _speed,
                style: TextStyle(fontSize: 20),
              ),
              Text(
                'Address: ' + _address,
                style: TextStyle(fontSize: 20),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
          onPressed: _updatePosition,
          tooltip: 'Get GPS position',
          child: const Icon(Icons.change_circle_outlined)),
    );
  }
}
