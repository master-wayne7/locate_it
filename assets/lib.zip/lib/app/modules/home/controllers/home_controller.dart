import 'package:get/get.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/data/repositories/user_repository.dart';
import 'package:puryaideu/app/utils/image_byte_converter.dart';
import 'package:shared_preferences/shared_preferences.dart';

class HomeController extends GetxController {
  final count = 0.obs;
  final previouslyLaunched = false.obs;
  final  enabled = true.obs;

  @override
  void onInit() {
    super.onInit();
    _loadIcons();
    _checkPreviouslyLaunched();
  }

  @override
  void onReady() {
    print('I am ready in homeController===');
    super.onReady();
  }

  Future<void> _checkPreviouslyLaunched() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    UserRepository repository = UserRepository(prefs: sharedPreferences);
    previouslyLaunched.value = await repository.isAppLaunchedPreviously();
  }

  Future<void> _loadIcons() async {
    final _pickupIcon = await ImageByteConverter.getBytesFromAsset(
        'assets/user_location.png', 80);
    final _destinationIcon = await ImageByteConverter.getBytesFromAsset(
        'assets/destination.png', 80);
    final _bikeIcon = await ImageByteConverter.getBytesFromAsset(
        'assets/bike.png', 90);
    final _carIcon =
        await ImageByteConverter.getBytesFromAsset('assets/car.png', 90);
    final _citySafariIcon = await ImageByteConverter.getBytesFromAsset(
        'assets/tuk-tuk.png', 90);
    final _foodIcon =
        await ImageByteConverter.getBytesFromAsset('assets/food_truck.png', 90);
    final _ambulanceIcon =
        await ImageByteConverter.getBytesFromAsset('assets/new_ambulance.png', 90);
    final _medicalIcon =
        await ImageByteConverter.getBytesFromAsset('assets/delivery.png', 90);
    SessionManager.instance.setMapIcons(
        _pickupIcon,
        _destinationIcon,
        _bikeIcon,
        _carIcon,
        _citySafariIcon,
        _foodIcon,
        _ambulanceIcon,
        _medicalIcon);
  }

  @override
  void onClose() {}

  void increment() => count.value++;
}
