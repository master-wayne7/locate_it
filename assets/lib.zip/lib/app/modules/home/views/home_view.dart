import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:geolocator/geolocator.dart';

import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:pull_to_refresh/pull_to_refresh.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/data/models/user.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/data/repositories/user_repository.dart';
import 'package:puryaideu/app/enums/ride_type.dart';
import 'package:puryaideu/app/modules/dashboard/controllers/dashboard_controller.dart';
import 'package:puryaideu/app/modules/profile/controllers/profile_controller.dart';
import 'package:puryaideu/app/modules/splash/controllers/all_data_controller.dart';
import 'package:puryaideu/app/routes/app_pages.dart';
import 'package:puryaideu/app/widgets/carousal_view.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:puryaideu/generated/locales.g.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:shimmer/shimmer.dart';

import '../../../widgets/custom_button.dart';
import '../controllers/home_controller.dart';
import 'custom_icon_button.dart';

class HomeView extends GetView<HomeController> {
  final User user;
  final AllDataController dataController = Get.find();
  final DashboardController dashboardController = Get.find();
  final RefreshController _homeRefreshController =
      RefreshController(initialRefresh: false);
  final ProfileController profileController = Get.find();

  HomeView({this.user});

  @override
  Widget build(BuildContext context) {
    print('controller created=== ${controller.count}');
    return Scaffold(
      appBar: AppBar(
        toolbarHeight: 80,
        backgroundColor: Colors.white,
        elevation: 0,
        title: Obx(() => profileController.user.value.firstName == null
            ? Container(
                color: Colors.white,
                width: Get.width,
                padding: EdgeInsets.symmetric(horizontal: 0, vertical: 8),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SizedBox(height: 8),
                    Shimmer.fromColors(
                      baseColor: Color(0xffeeeff3),
                      highlightColor: Colors.white,
                      enabled: true,
                      child: Container(
                        width: 150,
                        height: 14,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ),
                    SizedBox(height: 10),
                    Shimmer.fromColors(
                      baseColor: Color(0xffeeeff3),
                      highlightColor: Colors.white,
                      enabled: true,
                      child: Container(
                        width: 110,
                        height: 16,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ),
                    SizedBox(height: 8),
                  ],
                ),
              )
            : Container(
                padding: EdgeInsets.only(top: 16, bottom: 8),
                child: RichText(
                  text: TextSpan(
                    style: Get.textTheme.headline6.copyWith(
                        color: Get.theme.primaryColor,
                        fontFamily: 'Poppins',
                        fontWeight: FontWeight.w600,
                        fontSize: getResponsiveFont(14)),
                    children: [
                      WidgetSpan(
                          child: Container(
                        padding: EdgeInsets.all(2.0),
                      )),
                      TextSpan(
                          text: controller.previouslyLaunched.value
                              ? 'Welcome back,'
                              : 'Welcome,',
                          style: TextStyle(
                              fontFamily: 'Poppins',
                              color: Colors.black,
                              fontWeight: FontWeight.w700,
                              fontSize: getResponsiveFont(18))),
                      TextSpan(
                          text: '\n' + profileController.user.value.firstName,
                          style: TextStyle(
                              fontFamily: 'Poppins',
                              color: Get.theme.primaryColor,
                              fontWeight: FontWeight.w700,
                              fontSize: getResponsiveFont(24))),
                      WidgetSpan(
                          child: Container(
                        padding: EdgeInsets.all(2.0),
                      )),
                    ],
                  ),
                ),
              )),
      ),
      backgroundColor: Color(0xffeeeff3),
      body: SafeArea(
        child: FutureBuilder(
          future: Future.delayed(Duration(milliseconds: 4000)),
          builder: (c, s) => s.connectionState == ConnectionState.done
              ? SmartRefresher(
                  enablePullDown: true,
                  physics: AlwaysScrollableScrollPhysics(),
                  enablePullUp: false,
                  header: ClassicHeader(
                    refreshStyle: RefreshStyle.Follow,
                    releaseIcon: SizedBox(
                        width: 25.0,
                        height: 25.0,
                        child: const CupertinoActivityIndicator()),
                    failedIcon:
                        Icon(Icons.error, color: Get.theme.primaryColor),
                    idleIcon: SizedBox(
                        width: 25.0,
                        height: 25.0,
                        child: CupertinoActivityIndicator.partiallyRevealed(
                          progress: 0.4,
                        )),
                    textStyle: Get.textTheme.headline5.copyWith(
                        fontFamily: 'Roboto',
                        color: Get.theme.primaryColor,
                        fontWeight: FontWeight.w500),
                    releaseText: '',
                    idleText: '',
                    failedText: '',
                    completeText: '',
                    refreshingText: '',
                    refreshingIcon: SizedBox(
                        width: 25.0,
                        height: 25.0,
                        child: const CupertinoActivityIndicator()),
                  ),
                  controller: _homeRefreshController,
                  onRefresh: () async {
                    await dataController.getPromoCarousel();
                    await profileController.getUserDetail();
                    //await Future.delayed(Duration(milliseconds: 1500));
                    _homeRefreshController.refreshCompleted();
                  },
                  child: SingleChildScrollView(
                    child: Container(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Container(
                          //   color: Colors.white,
                          //   padding: EdgeInsets.symmetric(
                          //       horizontal: 16, vertical: 8),
                          //   child: Column(
                          //     children: [
                          //       GestureDetector(
                          //         onTap: () {
                          //           print(SessionManager.instance.user);
                          //         },
                          //         child: Container(),
                          //       ),
                          //     ],
                          //   ),
                          // ),
                          Container(
                            padding:
                                EdgeInsets.only(left: 16, right: 16, bottom: 4),
                            child: Row(
                              children: [
                                Expanded(
                                  child: CustomIconButton(
                                    rightBorder: true,
                                    bottomBorder: true,
                                    topBorder: true,
                                    iconUrl: 'assets/bike.png',
                                    title: LocaleKeys.vehicle_type_bike.tr,
                                    onTap: () async {
                                      try {
                                        final status = await dashboardController
                                            .determinePosition();
                                        if (status != null &&
                                            status is Position) {
                                          Get.toNamed(Routes.BOOKING,
                                              arguments: [RideType.BIKE]);
                                        }
                                      } catch (e) {
                                        await Geolocator.openLocationSettings();
                                      }

                                      // CustomSnackbar.showCusotmSnackBar(message: 'Bike Tapped.');
                                    },
                                  ),
                                ),
                                Expanded(
                                  child: CustomIconButton(
                                    rightBorder: true,
                                    bottomBorder: true,
                                    topBorder: true,
                                    iconUrl: 'assets/car.png',
                                    title: LocaleKeys.vehicle_type_taxi.tr,
                                    onTap: () async {
                                      try {
                                        final status = await dashboardController
                                            .determinePosition();
                                        if (status != null &&
                                            status is Position) {
                                          Get.toNamed(Routes.BOOKING,
                                              arguments: [RideType.CAR]);
                                        }
                                      } catch (e) {
                                        await Geolocator.openLocationSettings();
                                      }
                                    },
                                  ),
                                ),
                                Expanded(
                                  child: CustomIconButton(
                                    bottomBorder: true,
                                    rightBorder: false,
                                    topBorder: true,
                                    iconUrl: 'assets/tuk-tuk.png',
                                    title:
                                        LocaleKeys.vehicle_type_city_safari.tr,
                                    onTap: () async {
                                      SharedPreferences sharedPreferences =
                                          await SharedPreferences.getInstance();
                                      UserRepository userRepository =
                                          UserRepository(
                                              prefs: sharedPreferences);

                                      bool citySafariArea = await userRepository
                                          .isCitySafariRegion();
                                      if (citySafariArea) {
                                        try {
                                          final status =
                                              await dashboardController
                                                  .determinePosition();
                                          if (status != null &&
                                              status is Position) {
                                            Get.toNamed(Routes.BOOKING,
                                                arguments: [
                                                  RideType.CITY_SAFARI
                                                ]);
                                          }
                                        } catch (e) {
                                          await Geolocator
                                              .openLocationSettings();
                                        }
                                      } else {
                                        CustomSnackbar.showCustomSnackBar(
                                            message:
                                                'City safari is not available in this region.');
                                      }
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                          Container(
                            padding: EdgeInsets.symmetric(horizontal: 16),
                            child: Row(
                              children: [
                                Expanded(
                                  child: CustomIconButton(
                                    rightBorder: true,
                                    bottomBorder: true,
                                    iconUrl: 'assets/food_truck.png',
                                    title: LocaleKeys.buttons_ghar_khaja.tr,
                                    onTap: () async {
                                      try {
                                        final status = await dashboardController
                                            .determinePosition();
                                        if (status != null &&
                                            status is Position) {
                                          Get.toNamed(Routes.BOOKING,
                                              arguments: [RideType.FOOD_DELIVERY]);
                                        }
                                      } catch (e) {
                                        await Geolocator.openLocationSettings();
                                      }

                                    },
                                  ),
                                ),
                                Expanded(
                                  child: CustomAmbulanceButton(
                                    rightBorder: true,

                                    bottomBorder: true,
                                    bgColor: Get.theme.primaryColor,
                                    iconUrl: 'assets/new_ambulance.png',
                                    title: LocaleKeys.buttons_ambulance.tr,
                                    onTap: () async {
                                      try {
                                        final status = await dashboardController
                                            .determinePosition();
                                        if (status != null &&
                                            status is Position) {
                                          Get.toNamed(Routes.BOOKING,
                                              arguments: [RideType.AMBULANCE]);
                                        }
                                      } catch (e) {
                                        await Geolocator.openLocationSettings();
                                      }
                                    },
                                  ),
                                ),
                                Expanded(
                                  child: CustomIconButton(
                                    iconUrl: 'assets/delivery.png',
                                    // title: LocaleKeys.buttons_courier.tr,
                                    title: 'Pickup Truck',
                                    bottomBorder: true,
                                    onTap: () async {
                                      try {
                                        final status = await dashboardController
                                            .determinePosition();
                                        if (status != null &&
                                            status is Position) {
                                          await SessionManager.instance
                                              .setCurrentLocation(LatLng(
                                                  status.latitude,
                                                  status.longitude));
                                          Get.toNamed(Routes.BOOKING,
                                              arguments: [RideType.COURIER]);
                                        }
                                      } catch (e) {
                                        await Geolocator.openLocationSettings();
                                      }
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                          GestureDetector(
                            onTap: () {
                              dataController.getPromoCarousel();
                              print(
                                  'Promos list is ${dataController.promoList}');
                            },
                            child: Container(
                              width: Get.width,
                              color: Colors.white,
                              padding: EdgeInsets.symmetric(
                                  horizontal: 16, vertical: 16),
                              child: Column(
                                mainAxisAlignment: MainAxisAlignment.start,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'Promotions',
                                    style: Get.textTheme.headline6,
                                    textAlign: TextAlign.left,
                                  ),
                                ],
                              ),
                            ),
                          ),
                          Obx(() => dataController.promoList.isNotEmpty
                              ? Card(
                                  margin: EdgeInsets.zero,
                                  child: CarousalView(
                                    // imageUrlList: ['$BASE_URL/no-image.jpg'],
                                    imageUrlList:
                                        dataController.imageList == null
                                            ? ['$BASE_URL/no-image.jpg']
                                            : dataController.imageList
                                                .map<String>((title) => title)
                                                .toList(),
                                    promoCode: dataController.imageList == null
                                        ? ["10"]
                                        : dataController.codeList
                                            .map<String>((code) => code)
                                            .toList(),

                                    //imageUrlList: [dashBoardController.imageList[0],dashBoardController.imageList[1],dashBoardController.imageList[2]],
                                    //   promoCode: [dashBoardController.codeList[0],dashBoardController.codeList[2],dashBoardController.codeList[2]],
                                  ),
                                )
                              :
                              // Shimmer.fromColors(
                              //         baseColor: Color(0xffeeeff3),
                              //         highlightColor: Colors.white,
                              //         enabled: true,
                              //         child: Card(
                              //           margin: EdgeInsets.zero,
                              //           child: CarousalView(imageUrlList: [
                              //             '$BASE_URL/no-image.jpg'
                              //           ]),
                              //         ),
                              //       ),
                              Center(
                                  child: SizedBox(
                                    height: Get.height * 0.25,
                                    child: ListView.builder(
                                        padding: EdgeInsets.symmetric(
                                            horizontal: 28),
                                        scrollDirection: Axis.horizontal,
                                        shrinkWrap: true,
                                        itemCount: 1,
                                        itemBuilder: (
                                          context,
                                          index,
                                        ) {
                                          return Column(
                                            children: [
                                              Expanded(
                                                  child: SizedBox(height: 10)),
                                              // Expanded(
                                              //   child: CircleAvatar(
                                              //     backgroundColor: Colors.white,
                                              //     radius: 45,
                                              //   ),
                                              // ),
                                              SizedBox(height: 10),
                                              Container(
                                                padding: EdgeInsets.symmetric(
                                                    vertical: 0),
                                                child: Align(
                                                  alignment:
                                                      Alignment.topCenter,
                                                  child: Text('Looks Empty'.tr,
                                                      maxLines: 1,
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: Get
                                                          .textTheme.headline5
                                                          .copyWith(
                                                              fontSize: 14,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w600,
                                                              color: Color(
                                                                  0xff1D1D1D))),
                                                ),
                                              ),
                                              Container(
                                                padding: EdgeInsets.symmetric(
                                                    vertical: 4),
                                                child: Align(
                                                  alignment:
                                                      Alignment.topCenter,
                                                  child: Text(
                                                      'Promotions are currently unavailable.'
                                                          .tr,
                                                      maxLines: 1,
                                                      textAlign:
                                                          TextAlign.center,
                                                      style: Get
                                                          .textTheme.headline5
                                                          .copyWith(
                                                              fontSize: 12,
                                                              fontWeight:
                                                                  FontWeight
                                                                      .w400,
                                                              color: Color(
                                                                  0xff1D1D1D))),
                                                ),
                                              ),
                                              SizedBox(height: 8),
                                              // Obx(() =>
                                                  CustomButton(
                                                    radius: 10,
                                                  backgroundColor:
                                                      Get.theme.primaryColor,
                                                  onPressed: () async {
                                                      await dataController.getPromoCarousel();
                                                  },
                                                  text: 'Update'),
                                              // ),
                                              Expanded(child: SizedBox()),
                                            ],
                                          );
                                        }),
                                  ),
                                )),
                          Container(
                            width: Get.width,
                            height: 16,
                            color: Colors.white,
                            padding: EdgeInsets.symmetric(
                                horizontal: 16, vertical: 16),
                          ),
                          // Container(
                          //   width: Get.width,
                          //   height: 16,
                          //   color: Color(0xffeeeff3),
                          //   padding: EdgeInsets.symmetric(
                          //       horizontal: 16, vertical: 16),
                          // ),
                          // Container(
                          //   width: Get.width,
                          //   color: Colors.white,
                          //   padding: EdgeInsets.symmetric(
                          //       horizontal: 16, vertical: 16),
                          //   child: Column(
                          //     mainAxisAlignment: MainAxisAlignment.start,
                          //     crossAxisAlignment: CrossAxisAlignment.start,
                          //     children: [
                          //       Text(
                          //         LocaleKeys.text_get_discount.tr,
                          //         style: Get.textTheme.headline6,
                          //       ),
                          //       SizedBox(height: 16),
                          //       Center(
                          //           child: SvgPicture.asset(
                          //         'svg_assets/discount.svg',
                          //         height: Get.height * 0.3,
                          //         fit: BoxFit.contain,
                          //       )),
                          //       Text(
                          //         LocaleKeys.text_share_this_code.tr,
                          //         style: Get.textTheme.bodyText2.copyWith(
                          //             color: Colors.grey,
                          //             fontSize: getResponsiveFont(12)),
                          //       ),
                          //       SizedBox(height: 16),
                          //       Row(
                          //         children: [
                          //           Expanded(
                          //             child: Container(
                          //               padding: EdgeInsets.all(8),
                          //               decoration: BoxDecoration(
                          //                   borderRadius:
                          //                       BorderRadius.circular(5),
                          //                   border: Border.all(
                          //                     color: Colors.grey,
                          //                   )),
                          //               child: Row(
                          //                 children: [
                          //                   Expanded(
                          //                       child: Text(
                          //                           'Share your code: TEST1234',
                          //                           textAlign: TextAlign.center,
                          //                           style: Get
                          //                               .textTheme.headline6
                          //                               .copyWith(
                          //                                   fontSize:
                          //                                       getResponsiveFont(
                          //                                           12)))),
                          //                   Container(
                          //                       height: 24,
                          //                       width: 1,
                          //                       color: Colors.black),
                          //                   SizedBox(width: 16),
                          //                   Icon(Icons.copy,
                          //                       color: Get.theme.primaryColor),
                          //                 ],
                          //               ),
                          //             ),
                          //           ),
                          //           SizedBox(width: 16),
                          //           ElevatedButton(
                          //             child: Text(LocaleKeys.buttons_invite.tr),
                          //             onPressed: () {},
                          //             style: ButtonStyle(
                          //                 backgroundColor:
                          //                     MaterialStateProperty.all<Color>(
                          //                         Get.theme.primaryColor)),
                          //           ),
                          //         ],
                          //       ),
                          //     ],
                          //   ),
                          // ),
                        ],
                      ),
                    ),
                  ),
                )
              : SingleChildScrollView(
                  child: Container(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Container(
                        //   color: Colors.white,
                        //   width: Get.width,
                        //   padding:
                        //       EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                        //   child: Column(
                        //     mainAxisAlignment: MainAxisAlignment.start,
                        //     crossAxisAlignment: CrossAxisAlignment.start,
                        //     children: [
                        //       SizedBox(height: 8),
                        //       Shimmer.fromColors(
                        //         baseColor: Color(0xffeeeff3),
                        //         highlightColor: Colors.white,
                        //         enabled: true,
                        //         child: Container(
                        //           width: 120,
                        //           height: 14,
                        //           decoration: BoxDecoration(
                        //             color: Colors.white,
                        //             borderRadius: BorderRadius.circular(16),
                        //           ),
                        //         ),
                        //       ),
                        //       SizedBox(height: 10),
                        //       Shimmer.fromColors(
                        //         baseColor: Color(0xffeeeff3),
                        //         highlightColor: Colors.white,
                        //         enabled: true,
                        //         child: Container(
                        //           width: 150,
                        //           height: 16,
                        //           decoration: BoxDecoration(
                        //             color: Colors.white,
                        //             borderRadius: BorderRadius.circular(16),
                        //           ),
                        //         ),
                        //       ),
                        //       SizedBox(height: 8),
                        //     ],
                        //   ),
                        // ),
                        Container(
                          color: Colors.white.withOpacity(0.6),
                          padding:
                              EdgeInsets.only(left: 16, right: 16, bottom: 4),
                          child: Shimmer.fromColors(
                            baseColor: Color(0xffeeeff3),
                            highlightColor: Colors.white,
                            enabled: true,
                            child: Row(
                              children: [
                                Expanded(
                                  child: CustomIconButton(
                                    rightBorder: true,
                                    bottomBorder: true,
                                    topBorder: true,
                                    iconUrl: 'assets/bike.png',
                                    title: LocaleKeys.vehicle_type_bike.tr,
                                    onTap: () async {
                                      // CustomSnackbar.showCusotmSnackBar(message: 'Bike Tapped.');
                                    },
                                  ),
                                ),
                                Expanded(
                                  child: CustomIconButton(
                                    rightBorder: true,
                                    bottomBorder: true,
                                    topBorder: true,
                                    iconUrl: 'assets/car.png',
                                    title: LocaleKeys.vehicle_type_taxi.tr,
                                    onTap: () async {},
                                  ),
                                ),
                                Expanded(
                                  child: CustomIconButton(
                                    bottomBorder: true,
                                    topBorder: true,
                                    iconUrl: 'assets/tuk-tuk.png',
                                    title:
                                        LocaleKeys.vehicle_type_city_safari.tr,
                                    onTap: () async {},
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          color: Colors.white.withOpacity(0.6),
                          padding: EdgeInsets.symmetric(horizontal: 16),
                          child: Shimmer.fromColors(
                            baseColor: Color(0xffeeeff3),
                            highlightColor: Colors.white,
                            enabled: true,
                            child: Row(
                              children: [
                                Expanded(
                                  child: CustomIconButton(
                                    rightBorder: true,
                                    bottomBorder: true,
                                    iconUrl: 'assets/food_truck.png',
                                    title: LocaleKeys.buttons_ghar_khaja.tr,
                                    onTap: () async {},
                                  ),
                                ),
                                Expanded(
                                  child: CustomAmbulanceButton(
                                    rightBorder: true,
                                    bottomBorder: true,
                                    bgColor: Get.theme.primaryColor,
                                    iconUrl: 'assets/new_ambulance.png',
                                    title: LocaleKeys.buttons_ambulance.tr,
                                    onTap: () async {},
                                  ),
                                ),
                                Expanded(
                                  child: CustomIconButton(
                                    iconUrl: 'assets/delivery.png',
                                    // title: LocaleKeys.buttons_courier.tr,
                                    title: 'PICKUP TRUCK'.tr,
                                    bottomBorder: true,
                                    onTap: () async {},
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        Container(
                          width: Get.width,
                          color: Colors.white,
                          padding: EdgeInsets.symmetric(
                              horizontal: 16, vertical: 16),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Shimmer.fromColors(
                                baseColor: Color(0xffeeeff3),
                                highlightColor: Colors.white,
                                enabled: true,
                                child: Container(
                                  width: 150,
                                  height: 12,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Shimmer.fromColors(
                          baseColor: Color(0xffeeeff3),
                          highlightColor: Colors.white,
                          enabled: true,
                          child: Card(
                            margin: EdgeInsets.zero,
                            child: CarousalView(
                              imageUrlList: [
                                '$BASE_URL/${"assets/media/noimage.png"}',
                                '$BASE_URL/${"assets/media/noimage.png"}',
                                '$BASE_URL/${"assets/media/noimage.png"}',
                              ],
                            ),
                          ),
                        ),
                        Container(
                          width: Get.width,
                          height: 16,
                          color: Colors.white,
                          padding: EdgeInsets.symmetric(
                              horizontal: 16, vertical: 16),
                        ),
                        Container(
                          width: Get.width,
                          height: 16,
                          color: Color(0xffeeeff3),
                          padding: EdgeInsets.symmetric(
                              horizontal: 16, vertical: 16),
                        ),
                        // Container(
                        //   width: Get.width,
                        //   color: Colors.white,
                        //   padding: EdgeInsets.symmetric(
                        //       horizontal: 16, vertical: 16),
                        //   child: Column(
                        //     mainAxisAlignment: MainAxisAlignment.start,
                        //     crossAxisAlignment: CrossAxisAlignment.start,
                        //     children: [
                        //       Shimmer.fromColors(
                        //         baseColor: Color(0xffeeeff3),
                        //         highlightColor: Colors.white,
                        //         enabled: true,
                        //         child: Container(
                        //           width: 150,
                        //           height: 12,
                        //           decoration: BoxDecoration(
                        //             color: Colors.white,
                        //             borderRadius: BorderRadius.circular(16),
                        //           ),
                        //         ),
                        //       ),
                        //       SizedBox(height: 16),
                        //       Shimmer.fromColors(
                        //         baseColor: Color(0xffeeeff3),
                        //         highlightColor: Colors.white,
                        //         enabled: true,
                        //         child: Center(
                        //             child: SvgPicture.asset(
                        //           'svg_assets/discount.svg',
                        //           height: Get.height * 0.3,
                        //           fit: BoxFit.contain,
                        //         )),
                        //       ),
                        //       Shimmer.fromColors(
                        //         baseColor: Color(0xffeeeff3),
                        //         highlightColor: Colors.white,
                        //         enabled: true,
                        //         child: Text(
                        //           LocaleKeys.text_share_this_code.tr,
                        //           style: Get.textTheme.bodyText2.copyWith(
                        //               color: Colors.grey,
                        //               fontSize: getResponsiveFont(12)),
                        //         ),
                        //       ),
                        //       SizedBox(height: 16),
                        //       Shimmer.fromColors(
                        //         baseColor: Color(0xffeeeff3),
                        //         highlightColor: Colors.white,
                        //         enabled: true,
                        //         child: Row(
                        //           children: [
                        //             Expanded(
                        //               child: Container(
                        //                 padding: EdgeInsets.all(8),
                        //                 decoration: BoxDecoration(
                        //                     borderRadius:
                        //                         BorderRadius.circular(5),
                        //                     border: Border.all(
                        //                       color: Colors.grey,
                        //                     )),
                        //                 child: Row(
                        //                   children: [
                        //                     Expanded(
                        //                         child: Text(
                        //                             'Share your code: TEST1234',
                        //                             textAlign: TextAlign.center,
                        //                             style: Get
                        //                                 .textTheme.headline6
                        //                                 .copyWith(
                        //                                     fontSize:
                        //                                         getResponsiveFont(
                        //                                             14)))),
                        //                     Container(
                        //                         height: 24,
                        //                         width: 1,
                        //                         color: Colors.black),
                        //                     SizedBox(width: 16),
                        //                     Icon(Icons.copy,
                        //                         color: Get.theme.primaryColor),
                        //                   ],
                        //                 ),
                        //               ),
                        //             ),
                        //             SizedBox(width: 16),
                        //             ElevatedButton(
                        //               child: Text(LocaleKeys.buttons_invite.tr),
                        //               onPressed: () {},
                        //               style: ButtonStyle(
                        //                   backgroundColor:
                        //                       MaterialStateProperty.all<Color>(
                        //                           Get.theme.primaryColor)),
                        //             ),
                        //           ],
                        //         ),
                        //       ),
                        //     ],
                        //   ),
                        // ),
                      ],
                    ),
                  ),
                ),
        ),
      ),
    );
  }
}

// Container(
//     color: Colors.transparent,
//     width: MediaQuery.of(context).size.width,
//     height: Get.height * 0.125,
//     child: CustomPaint(
//       painter: CustomToolbarShape(lineColor: Colors.deepOrange),
//     )),
// Positioned(
//   top:Get.height * 0.22,
//   child: Container(
//     decoration: BoxDecoration(
//       // borderRadius: BorderRadius.circular(10),
//         color:Color.fromRGBO(255, 89, 89, 1).withOpacity(0.9),
//         border: Border.all(color:Color.fromRGBO(255, 89, 89, 1).withOpacity(0.2)),
//         boxShadow: [
//           BoxShadow(
//             offset: const Offset(3.0, 3.0),
//             blurRadius: 2.0,
//             color: Colors.grey.withOpacity(0.5),
//             spreadRadius: 0.8,
//           ),
//         ]),
//     height: Get.height * 0.15,
//     width: Get.width,
//   ),
// ),

// Opacity(
//   opacity: 0.9,
//   child: Container(
//     height: Get.height * 0.35,
//     width: Get.width,
//     child:Image.asset(
//       'assets/background3.jpg',
//       fit: BoxFit.cover,
//     ),
//   ),
// ),
