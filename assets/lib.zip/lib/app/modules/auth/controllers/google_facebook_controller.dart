import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:puryaideu/app/data/models/user.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/data/repositories/auth_repository.dart';
import 'package:puryaideu/app/data/services/fb_login_service.dart';
import 'package:puryaideu/app/data/services/google_login_service.dart';
import 'package:puryaideu/app/modules/signup/models/register_request_model_model.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';

class GoogleFacebookController extends GetxController {
  String authError;
  String userId;
  GoogleSignInAccount _googleData;
  dynamic _facebookData;

  Future<bool> googleLogin() async {
    GoogleSignInAccount googleSignInAccount =
        await GoogleLoginService.performGoogleLogin().catchError((error) {
      authError = "Google login is currently unavailable. Please try again!";
    });
    if (googleSignInAccount == null) {
      return false;
    }
    userId = googleSignInAccount.id;
    _googleData = googleSignInAccount;
    print('GOogle login success===');
    return true;
  }

  Future<int> checkUserExist(String authType) async {
    final response = await AuthRepository.checkUserExist(authType, userId)
        .catchError((error) {
      authError = "User data could not be verified with server. Please try again!";
    });
    if (response == null) {
      return -1;
    }
    print('response vaiya=== $response');
    return response;
  }

  Future<bool> googleRegister() async {
    final name = _googleData.displayName;
    var arr = name.split(' ');
    final firstName = arr[0];
    final lastName = arr[1];
    RegisterRequestModel registerRequestModel = RegisterRequestModel(
        googleId: userId,
        firstName: firstName,
        lastName: lastName,
        email: _googleData.email,
        phone: SessionManager.instance.phone,
        // profilePic: _googleData.photoUrl
        socialImageUrl: _googleData.photoUrl);
    final response = await AuthRepository.callRegisterApi(registerRequestModel)
        .catchError((error) {
      authError = "Registration failed. Please try again!";
    });
    if (response == null) {
      return false;
    }
    return true;
  }

  Future<bool> saveGoogleId() async {
    final response =
        await AuthRepository.saveGoogleId(userId).catchError((error) {
      authError = "Google account could not be linked. Please try again!";
    });

    if (response == null) {
      return false;
    }

    return true;
  }

  // Future<bool> facebookLogin() async {
  //   final facebookResponse =
  //       await FbLoginService.performFacebookLogin().catchError((error) {
  //     authError = "Facebook services are unavailable. Please try again!";
  //   });
  //   if (facebookResponse == null) {
  //     return false;
  //   }
  //
  //   userId = facebookResponse['id'];
  //   _facebookData = facebookResponse;
  //   return true;
  // }

  Future<bool> facebookRegister() async {
    final name = _facebookData['name'];
    var arr = name.split(' ');
    final firstName = arr[0];
    final lastName = arr[1];
    RegisterRequestModel registerRequestModel = RegisterRequestModel(
        facebookId: userId,
        firstName: firstName,
        lastName: lastName,
        email: _facebookData['email'],
        phone: SessionManager.instance.phone,
        // profilePic: _googleData.photoUrl
        socialImageUrl: _facebookData["picture"]["data"]["url"]);
    final response = await AuthRepository.callRegisterApi(registerRequestModel)
        .catchError((error) {
      authError = "Registration failed. Please try again!";
    });
    if (response == null) {
      return false;
    }
    return true;
  }

  Future<bool> saveFacebookId() async {
    final response =
    await AuthRepository.saveFacebookId(userId).catchError((error) {
      authError = "Facebook account could not be linked. Please try again!";
    });

    if (response == null) {
      return false;
    }

    return true;
  }
}
