import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';

import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:lottie/lottie.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/modules/auth/controllers/google_facebook_controller.dart';
import 'package:puryaideu/app/routes/app_pages.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:puryaideu/app/widgets/facebook_google_login_button.dart';
import 'package:puryaideu/app/widgets/custom_progress_bar.dart';
import 'package:puryaideu/generated/locales.g.dart';

import '../controllers/auth_controller.dart';
import 'phone_login_button.dart';

class AuthView extends GetView<AuthController> {
  final GoogleFacebookController _googleFacebookController = Get.find();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Stack(
            children: [
              SingleChildScrollView(
                physics: NeverScrollableScrollPhysics(),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    // Image.asset(
                    //   'assets/auth.png',
                    //   fit: BoxFit.cover,
                    // ),
                    Lottie.asset('assets/animations/login.json'),
                    SizedBox(height: Get.height * 0.05),
                    PhoneLoginButton(
                      title: LocaleKeys.buttons_continue_with_phone.tr,
                      onPressed: () async {
                        final status = await Get.toNamed(Routes.PHONE_LOGIN);
                        if (status != null && status) {
                          if (SessionManager.instance.accessToken == null) {
                            Get.toNamed(Routes.SIGNUP);
                          } else {
                            await controller
                                .saveToken()
                                .then((_) => Get.offAllNamed(Routes.DASHBOARD));
                          }
                        }
                      },
                    ),
                    SizedBox(height: Get.height * 0.05),
                    // Text(
                    //   LocaleKeys.text_or.tr,
                    //   textAlign: TextAlign.center,
                    //   style: Get.textTheme.bodyText2,
                    // ),
                    // SizedBox(height: Get.height * 0.05),
                    // Row(
                    //   children: [
                    //     Expanded(
                    //       child: FacebookGoogleLoginButton(
                    //         iconUrl: 'svg_assets/google.svg',
                    //         title: LocaleKeys.buttons_google.tr,
                    //         onTap: () async {
                    //           final status =
                    //               await _googleFacebookController.googleLogin();
                    //           if (status) {
                    //             final userExist =
                    //                 await _googleFacebookController
                    //                     .checkUserExist('google');
                    //             if (userExist == 0) {
                    //               final phoneResponse =
                    //                   await Get.toNamed(Routes.PHONE_LOGIN);
                    //               if (phoneResponse != null && phoneResponse) {
                    //                 if (SessionManager.instance.accessToken ==
                    //                     null) {
                    //                   final loginResponse =
                    //                       await _googleFacebookController
                    //                           .googleRegister();
                    //                   if (loginResponse) {
                    //                     await controller.saveToken().then((_) =>
                    //                         Get.offAllNamed(Routes.DASHBOARD));
                    //                   } else {
                    //                     CustomSnackbar.showCustomSnackBar(
                    //                         message: "Social login service is unavailable. Please try again!");
                    //                   }
                    //                 } else {
                    //                   final updateResponse =
                    //                       await _googleFacebookController
                    //                           .saveGoogleId();
                    //                   if (updateResponse) {
                    //                     CustomSnackbar.showCustomSnackBar(
                    //                         message: _googleFacebookController
                    //                             .authError);
                    //                   } else {
                    //                     await controller.saveToken().then((_) =>
                    //                         Get.offAllNamed(Routes.DASHBOARD));
                    //                   }
                    //                 }
                    //               }
                    //             } else if (userExist == 1) {
                    //               await controller.saveToken().then(
                    //                   (_) => Get.offAllNamed(Routes.DASHBOARD));
                    //             } else {
                    //               CustomSnackbar.showCustomSnackBar(
                    //                   message:
                    //                       "Internet is not available. Please try again!");
                    //             }
                    //           } else {
                    //             CustomSnackbar.showCustomSnackBar(
                    //                 message:
                    //                 "Internet is not available. Please try again!");
                    //           }
                    //         },
                    //       ),
                    //     ),
                    //     SizedBox(
                    //       width: 16,
                    //     ),
                    //     Expanded(
                    //       child: FacebookGoogleLoginButton(
                    //         title: LocaleKeys.buttons_facebook.tr,
                    //         iconUrl: 'svg_assets/fb.svg',
                    //         onTap: () async{
                    //           final status = false;
                    //               // await _googleFacebookController.facebookLogin();
                    //           if (status) {
                    //             final userExist =
                    //                 await _googleFacebookController
                    //                 .checkUserExist('facebook');
                    //             if (userExist == 0) {
                    //               final phoneResponse =
                    //                   await Get.toNamed(Routes.PHONE_LOGIN);
                    //               if (phoneResponse != null && phoneResponse) {
                    //                 if (SessionManager.instance.accessToken ==
                    //                     null) {
                    //                   final loginResponse =
                    //                       await _googleFacebookController
                    //                       .facebookRegister();
                    //                   if (loginResponse) {
                    //                     await controller.saveToken().then((_) =>
                    //                         Get.offAllNamed(Routes.DASHBOARD));
                    //                   } else {
                    //                     CustomSnackbar.showCustomSnackBar(
                    //                         message: 'Internet failed to establish proper connection. Try again.');
                    //                   }
                    //                 } else {
                    //                   final updateResponse =
                    //                       await _googleFacebookController
                    //                       .saveFacebookId();
                    //                   if (updateResponse) {
                    //                     CustomSnackbar.showCustomSnackBar(
                    //                         message: 'Internet failed to establish proper connection. Try again.');
                    //                   } else {
                    //                     await controller.saveToken().then((_) =>
                    //                         Get.offAllNamed(Routes.DASHBOARD));
                    //                   }
                    //                 }
                    //               }
                    //             } else if (userExist == 1) {
                    //               await controller.saveToken().then(
                    //                       (_) => Get.offAllNamed(Routes.DASHBOARD));
                    //             } else {
                    //               CustomSnackbar.showCustomSnackBar(
                    //                   message:
                    //                   'Internet failed to establish proper connection. Try again.');
                    //             }
                    //           } else {
                    //             CustomSnackbar.showCustomSnackBar(
                    //                 message: 'Internet failed to establish proper connection. Try again.');
                    //                 // _googleFacebookController.authError);
                    //           }
                    //         },
                    //       ),
                    //     ),
                    //   ],
                    // ),
                    // SizedBox(height: Get.height * 0.05),
                    SizedBox(height: Get.height * 0.15),
                    _buildTermsAndConditions()
                  ],
                ),
              ),
              Obx(() => controller.progressStatus.value
                  ? CustomProgressBar()
                  : Container())
            ],
          ),
        ),
      ),
    );
  }

  RichText _buildTermsAndConditions() {
    return RichText(
      textAlign: TextAlign.center,
      text: TextSpan(
        children: <TextSpan>[
          TextSpan(
              text: LocaleKeys.text_by_tapping.tr,
              style: Get.textTheme.bodyText2),
          TextSpan(
              text: LocaleKeys.buttons_terms_and_condition.tr,
              style: Get.textTheme.bodyText2
                  .copyWith(color: Get.theme.primaryColor),
              recognizer: TapGestureRecognizer()
                ..onTap = () {
                  print('Clicked signup page.');
                  // Get.to(SignUpScreen());
                }),
          TextSpan(
              text: LocaleKeys.text_and.tr, style: Get.textTheme.bodyText2),
          TextSpan(
              text: LocaleKeys.buttons_privacy_policy.tr,
              style: Get.textTheme.bodyText2
                  .copyWith(color: Get.theme.primaryColor),
              recognizer: TapGestureRecognizer()
                ..onTap = () {
                  print('Clicked signup page.');
                  // Get.to(SignUpScreen());
                }),
          TextSpan(
              text: 'of Puryaideu',
              style: Get.textTheme.bodyText2),
        ],
      ),
    );
  }
}
