import 'package:get/get.dart';
import 'package:puryaideu/app/modules/extra_trip/controllers/extra_trip_map_controller.dart';

import '../controllers/extra_trip_controller.dart';

class ExtraTripBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<ExtraTripController>(
      () => ExtraTripController(),
    );
    Get.lazyPut<ExtraTripMapController>(
          () => ExtraTripMapController(),
    );
  }
}
