import 'dart:async';

import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:puryaideu/app/enums/extra_trip_events.dart';
import 'package:puryaideu/app/enums/ride_type.dart';
import 'package:puryaideu/app/enums/trip_events.dart';
import 'package:puryaideu/app/routes/app_pages.dart';

import 'extra_trip_map_controller.dart';

class ExtraTripController extends GetxController {

  LatLng pickupLocation = LatLng(0, 0);
  LatLng destinationLocation = LatLng(0, 0);

  LatLng driverLocation = LatLng(27.681777547278386, 85.34157486563986);
  final waitingDuration = '10'.obs;
  String errorMessage;
  Timer tripStatusTimer;
  String status = 'pending';
  ExtraTripMapController _tripMapController;
  final originName = "koteshwor".obs;
  final destinationName = "Sanepa".obs;

  final _bookingList = [].obs;
  String price = "100";
  String distance = "3";
  final rideType = RideType.AMBULANCE.obs;

  final _tripEvent = ExtraTripEvents.PENDING.obs;

  ExtraTripEvents get tripEvent => _tripEvent.value;

  void updateTripStatus(ExtraTripEvents event) => _tripEvent.value = event;

  void setBooking(RxList bookingList) {
    print('set booking called====');
    _bookingList.value = bookingList;
    pickupLocation =
        LatLng(_bookingList[2], _bookingList[3]);
    destinationLocation = LatLng(_bookingList[4],
        _bookingList[5]);
    rideType.value = _bookingList[0];
    originName.value = _bookingList[6].toString();
    destinationName.value = _bookingList[7].toString();
    price = (bookingList[1]).toString();
    distance = (bookingList[8]).toString();
    print(_bookingList);
    Future.delayed(Duration(seconds: 10)).then((value) async{
      status = "accepted";
      updateTripStatus(ExtraTripEvents.ACCEPTED);

    });
    Future.delayed(Duration(seconds: 25)).then((value) async{
      status = "running";
      updateTripStatus(ExtraTripEvents.RUNNING);

    });
    Future.delayed(Duration(seconds: 40)).then((value) async{
      status = "completed";
      if(rideType == RideType.AMBULANCE ){
        updateTripStatus(ExtraTripEvents.RATINGS);
      }else{
        updateTripStatus(ExtraTripEvents.COMPLETED);
      }
    });

    @override
    void onClose() {}

  }
}
