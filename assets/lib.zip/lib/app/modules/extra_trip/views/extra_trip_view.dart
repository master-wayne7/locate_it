import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'package:get/get.dart';
import 'package:puryaideu/app/data/models/booking.dart';

import '../controllers/extra_trip_controller.dart';
import 'extra_trip_dialogs.dart';
import 'extra_trip_map_container.dart';

class ExtraTripView extends GetView<ExtraTripController> {
  setBooking(context) {
    controller.setBooking(Get.arguments);
  }

  Future<bool> onWillPop() async {
    SystemNavigator.pop();
    return true;
  }

  @override
  Widget build(BuildContext context) {
    setBooking(context);
    return WillPopScope(
      onWillPop: onWillPop,
      child: Scaffold(
        body: SafeArea(
          child: Stack(
            children: [
              ExtraTripMapContainer(),
              ExtraTripDialogs(),
            ],
          ),
        ),
      ),
    );
  }
}
