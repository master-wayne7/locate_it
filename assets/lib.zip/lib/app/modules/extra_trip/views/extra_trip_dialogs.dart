import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/enums/extra_trip_events.dart';
import 'package:puryaideu/app/enums/trip_events.dart';
import 'package:puryaideu/app/modules/extra_trip/controllers/extra_trip_controller.dart';
import 'package:puryaideu/app/modules/extra_trip/controllers/extra_trip_map_controller.dart';
import 'package:puryaideu/app/modules/trip/controllers/trip_controller.dart';

import 'dialogs/payment_dialog.dart';
import 'dialogs/rating_dialog.dart';
import 'dialogs/trip_accepted_dialog.dart';
import 'dialogs/trip_running_dialog.dart';
import 'dialogs/waiting_dialog.dart';

class ExtraTripDialogs extends GetView<ExtraTripController> {

  @override
  Widget build(BuildContext context) {
    return Obx(
            () {
          switch (controller.tripEvent) {
            case ExtraTripEvents.PENDING:
              WaitingDialog();
              break;
            case ExtraTripEvents.ACCEPTED:
              return TripAcceptedDialog();

            case ExtraTripEvents.RUNNING:
              return TripRunningDialog();
            case ExtraTripEvents.COMPLETED:
              return PaymentDialog();
            case ExtraTripEvents.RATINGS:
              return RatingDialog();
          }
          return WaitingDialog();
        }
    );
  }
}

