import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/enums/ride_type.dart';
import 'package:puryaideu/app/modules/extra_trip/controllers/extra_trip_controller.dart';
import 'package:puryaideu/app/modules/trip/controllers/trip_controller.dart';
import 'package:puryaideu/app/modules/trip/views/cancel_reason.dart';
import 'package:puryaideu/app/widgets/custom_button.dart';
import 'package:puryaideu/app/widgets/sliding_up_panel.dart';
import 'package:puryaideu/generated/locales.g.dart';
import 'package:url_launcher/url_launcher.dart';

import 'package:puryaideu/app/widgets/banner.dart' as ban;

import 'cancel_dialog.dart';


class TripAcceptedDialog extends GetView<ExtraTripController> {

  final PanelController _pc = new PanelController();

  @override
  Widget build(BuildContext context) {
    return SlidingUpPanel(
      controller: _pc,
      minHeight: Get.height * 0.1,
      maxHeight: Get.height * 0.52,
      renderPanelSheet: false,
      defaultPanelState: PanelState.OPEN,
      panel: ClipRRect(
        child: controller.rideType.value == RideType.AMBULANCE
        ? ban.BannerApp(
        layoutDirection: TextDirection.ltr,
        color: Get.theme.primaryColor,
        message: "Emergency",
        textStyle: Get.textTheme.headline5.copyWith(
        color: Colors.white,
        fontSize: getResponsiveFont(12),
    fontWeight: FontWeight.w600),
    location: ban.BannerLocation.topEnd,
    child: Container(
          padding: EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.all(Radius.circular(24.0)),
              boxShadow: [
                BoxShadow(
                  blurRadius: 20.0,
                  color: Colors.transparent,
                ),
              ]),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _floatingCollapsed(),
              Divider(
                height: 1,
                color: Colors.grey.withOpacity(0.7),
              ),
              SizedBox(height: 16),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 0),
                color: Colors.white,
                width: Get.width,
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(5),
                      child: CachedNetworkImage(
                          imageUrl:
                          '$BASE_URL/${"uploads/user/abf70e41fce3cd7381119cac7cd858bcb7c399f1.jpg"}',
                          height: 60,
                          width: 60,
                          fit: BoxFit.cover,
                        ),
                      ),

                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                              'Rhythm B.',
                              style: Get.textTheme.bodyText2.copyWith(color: Colors.black, fontSize:getResponsiveFont(16), fontWeight: FontWeight.w600),
                            ),

                          SizedBox(height: 8),
                          InkWell(
                            onTap: () async {
                              if (await canLaunch(
                                  'tel: ${"9869191572"}')) {
                                await launch('tel:${"9869191572"}');
                              } else {
                                throw 'Could not launch url';
                              }
                            },
                            child: Row(
                              children: [
                                Icon(
                                  Icons.phone,
                                  color: Get.theme.primaryColor,
                                  size: 24,
                                ),
                                SizedBox(width: 8),
                                Text(LocaleKeys.buttons_call.tr,
                                    style: Get.textTheme.bodyText2.copyWith(color: Get.theme.primaryColor, fontSize:getResponsiveFont(14), fontWeight: FontWeight.w600)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 8),
              // Text('Ba 2 Kha 2020', style: Get.textTheme.bodyText2,),
              // SizedBox(height: 8),
              // Text('BIKE'),
              // SizedBox(height: 16),
              Divider(
                height: 1,
                color: Colors.grey.withOpacity(0.7),
              ),
              SizedBox(height: 8),
              Text(
                'Trip Detail',
                style: Get.textTheme.bodyText2.copyWith(color: Colors.black, fontSize:getResponsiveFont(16), fontWeight: FontWeight.w600),
              ),
              SizedBox(height: 16),
              Row(
                children: [
                  Icon(Icons.my_location,color: Get.theme.primaryColor,),
                  SizedBox(width: 16),
                  Expanded(
                      child: Text(
                        controller.originName.value,
                        maxLines: 1,
                        style: Get.textTheme.bodyText2.copyWith(color: Colors.black, fontSize:getResponsiveFont(14), fontWeight: FontWeight.w600),
                        overflow: TextOverflow.ellipsis,
                      )),
                ],
              ),
              SizedBox(height: 8),
              Row(
                children: [
                  Icon(Icons.location_pin,color: Get.theme.primaryColor,),
                  SizedBox(width: 16),
                  Expanded(
                      child: Text(
                        controller.destinationName.value,
                        maxLines: 1,
                        style: Get.textTheme.bodyText2.copyWith(color: Colors.black, fontSize:getResponsiveFont(14), fontWeight: FontWeight.w600),
                        overflow: TextOverflow.ellipsis,
                      )),
                ],
              ),
              SizedBox(height: 16),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.receipt,color: Get.theme.primaryColor,),
                  SizedBox(width: 16),
                  Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            LocaleKeys.units_rs.tr +
                                ' ${controller.price}',
                            style: Get.textTheme.headline6,
                          ),
                          SizedBox(height: 4),
                          Text(
                            'This is the estimated fare. It may vary.',
                            style: Get.textTheme.bodyText2
                                .copyWith(fontSize: getResponsiveFont(12)),
                          ),
                        ],
                      )),
                ],
              ),
              SizedBox(height: 16),
              Container(
                width: Get.width,
                child: CustomButton(
                  backgroundColor: Get.theme.primaryColor,
                  onPressed: () {
                      showDialog(
                          context: context,
                          builder: (_) {
                            return CancelDialog();
                          });
                  },
                  text: 'Cancel',
                ),
              ),
            ],
          ),
        ),
      ):Container(
          padding: EdgeInsets.symmetric(horizontal: 16),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.all(Radius.circular(24.0)),
              boxShadow: [
                BoxShadow(
                  blurRadius: 20.0,
                  color: Colors.transparent,
                ),
              ]),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _floatingCollapsed(),
              Divider(
                height: 1,
                color: Colors.grey.withOpacity(0.7),
              ),
              SizedBox(height: 16),
              Container(
                padding: EdgeInsets.symmetric(horizontal: 0),
                color: Colors.white,
                width: Get.width,
                child: Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(5),
                      child: CachedNetworkImage(
                        imageUrl:
                        '$BASE_URL/${"uploads/user/abf70e41fce3cd7381119cac7cd858bcb7c399f1.jpg"}',
                        height: 60,
                        width: 60,
                        fit: BoxFit.cover,
                      ),
                    ),

                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Rhythm B.',
                            style: Get.textTheme.bodyText2.copyWith(color: Colors.black, fontSize:getResponsiveFont(16), fontWeight: FontWeight.w600),
                          ),

                          SizedBox(height: 8),
                          InkWell(
                            onTap: () async {
                              if (await canLaunch(
                                  'tel: ${"9869191572"}')) {
                                await launch('tel:${"9869191572"}');
                              } else {
                                throw 'Could not launch url';
                              }
                            },
                            child: Row(
                              children: [
                                Icon(
                                  Icons.phone,
                                  color: Get.theme.primaryColor,
                                  size: 24,
                                ),
                                SizedBox(width: 8),
                                Text(LocaleKeys.buttons_call.tr,
                                    style: Get.textTheme.bodyText2.copyWith(color: Get.theme.primaryColor, fontSize:getResponsiveFont(14), fontWeight: FontWeight.w600)),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              SizedBox(height: 8),
              // Text('Ba 2 Kha 2020', style: Get.textTheme.bodyText2,),
              // SizedBox(height: 8),
              // Text('BIKE'),
              // SizedBox(height: 16),
              Divider(
                height: 1,
                color: Colors.grey.withOpacity(0.7),
              ),
              SizedBox(height: 8),
              Text(
                'Trip Detail',
                style: Get.textTheme.bodyText2.copyWith(color: Colors.black, fontSize:getResponsiveFont(16), fontWeight: FontWeight.w600),
              ),
              SizedBox(height: 16),
              Row(
                children: [
                  Icon(Icons.my_location,color: Get.theme.primaryColor,),
                  SizedBox(width: 16),
                  Expanded(
                      child: Text(
                        controller.originName.value,
                        maxLines: 1,
                        style: Get.textTheme.bodyText2.copyWith(color: Colors.black, fontSize:getResponsiveFont(14), fontWeight: FontWeight.w600),
                        overflow: TextOverflow.ellipsis,
                      )),
                ],
              ),
              SizedBox(height: 8),
              Row(
                children: [
                  Icon(Icons.location_pin,color: Get.theme.primaryColor,),
                  SizedBox(width: 16),
                  Expanded(
                      child: Text(
                        controller.destinationName.value,
                        maxLines: 1,
                        style: Get.textTheme.bodyText2.copyWith(color: Colors.black, fontSize:getResponsiveFont(14), fontWeight: FontWeight.w600),
                        overflow: TextOverflow.ellipsis,
                      )),
                ],
              ),
              SizedBox(height: 16),
              Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Icon(Icons.receipt,color: Get.theme.primaryColor,),
                  SizedBox(width: 16),
                  Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          controller.rideType != RideType.AMBULANCE ? Text(
                            LocaleKeys.units_rs.tr +
                                ' ${controller.price}',
                            style: Get.textTheme.headline6,
                          ):Text(
                    "No app charges*",
                    style: Get.textTheme.headline6.copyWith(
                        fontSize: getResponsiveFont(16)),
                  ),
                          SizedBox(height: 4),
                          controller.rideType != RideType.AMBULANCE ? Text(
                            'This is the estimated fare. It may vary.',
                            style: Get.textTheme.bodyText2
                                .copyWith(fontSize: getResponsiveFont(12)),
                          ): Text(''),
                        ],
                      )),
                ],
              ),
              SizedBox(height: 16),
              Container(
                width: Get.width,
                child: CustomButton(
                  backgroundColor: Get.theme.primaryColor,
                  onPressed: () {
                    showDialog(
                        context: context,
                        builder: (_) {
                          return CancelDialog();
                        });
                  },
                  text: 'Cancel',
                ),
              ),
            ],
          ),
        )),
      collapsed: _floatingCollapsed(),
      body: Container(),
    );
  }


  Widget _floatingCollapsed() {
    return Container(
      margin: EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(24.0), topRight: Radius.circular(24.0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Center(
            child: Container(
              height: 3,
              width: 40,
              color: Colors.black,
            ),
          ),
          SizedBox(height: 16),
          Text(
            'Rider is on the way...',
              style: Get.textTheme.bodyText2.copyWith(color: Colors.black, fontSize:getResponsiveFont(20), fontWeight: FontWeight.w700)
          ),
        ],
      ),
    );
  }
}