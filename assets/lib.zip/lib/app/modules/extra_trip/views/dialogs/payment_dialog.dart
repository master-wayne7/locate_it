import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/enums/extra_trip_events.dart';
import 'package:puryaideu/app/modules/extra_trip/controllers/extra_trip_controller.dart';
import 'package:puryaideu/app/widgets/custom_button.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:puryaideu/generated/locales.g.dart';

class PaymentDialog extends GetView<ExtraTripController> {

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Text(
          LocaleKeys.text_payment.tr,
          style: Get.textTheme.headline6,
        ),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Stack(
          children: [
            Container(
              width: Get.width,
              color: Colors.white,
              child: Column(
                children: [
                  Expanded(
                    child: Container(
                      margin:
                      EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                      child: Card(
                        elevation: 4,
                        child: Container(
                          width: Get.width,
                          padding: EdgeInsets.all(16),
                          child: Column(
                            children: [
                              Text(
                                LocaleKeys.text_trip_finish.tr,
                                style: Get.textTheme.bodyText2.copyWith(fontSize: getResponsiveFont(18), fontWeight: FontWeight.w600),
                              ),
                              SizedBox(
                                height: Get.height * 0.1,
                              ),
                              Container(
                                  padding: EdgeInsets.all(16),
                                  margin: EdgeInsets.all(16),
                                  decoration: BoxDecoration(
                                    color: Color(0xffD7D7D7),
                                    borderRadius: BorderRadius.circular(100),
                                  ),
                                  child: Icon(
                                    Icons.check,
                                    color: Get.theme.primaryColor,
                                    size: 60,
                                  )),
                              SizedBox(
                                height: Get.height * 0.1,
                              ),
                              Container(
                                decoration: BoxDecoration(
                                  border: Border.all(color: Color(0xffD7D7D7)),
                                  borderRadius: BorderRadius.circular(15),
                                ),
                                padding: EdgeInsets.all(16),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Row(
                                      children: [
                                        Icon(Icons.my_location),
                                        SizedBox(width: 16),
                                        Expanded(
                                            child: Text(
                                                '${controller.originName}')),
                                      ],
                                    ),
                                    SizedBox(height: Get.height * 0.02),
                                    Row(
                                      children: [
                                        Icon(Icons.location_pin),
                                        SizedBox(width: 16),
                                        Expanded(
                                            child: Text(
                                                '${controller.destinationName}')),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              SizedBox(height: Get.height * 0.05),
                              Row(
                                mainAxisAlignment:
                                MainAxisAlignment.spaceBetween,
                                children: [
                                  Text(
                                    '${controller.distance} ' + LocaleKeys.units_km.tr,
                                    style: Get.textTheme.headline6,
                                  ),
                                  Text(LocaleKeys.units_rs.tr +
                                      ' ${controller.price}',
                                      //'200',
                                      style: Get.textTheme.headline6),
                                ],
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  ),
                  Container(
                    margin: EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      children: [
                        Expanded(
                          child: CustomButton(
                              backgroundColor: Get.theme.primaryColor,
                              onPressed: () async {
                                //final status = await controller.payOffline();
                                final status = true;
                                if (status) {
                                  CustomSnackbar.showCustomSnackBar(
                                      message: 'Payment Success.');
                                  controller.updateTripStatus(ExtraTripEvents.RATINGS);
                                  // Future.delayed(Duration(seconds: 3))
                                  //     .then((value) => Get.back());
                                } else {
                                  CustomSnackbar.showCustomSnackBar(message: controller.errorMessage);
                                }
                              },
                              text: LocaleKeys.buttons_offline_payment.tr),
                        ),
                        // SizedBox(width: 16),
                        // Expanded(
                        //   child: CustomButton(
                        //     onPressed: () async {
                        //       final status = await showModalBottomSheet(
                        //           context: context,
                        //           backgroundColor: Colors.transparent,
                        //           builder: (context) {
                        //             return Container(
                        //               decoration: BoxDecoration(
                        //                 borderRadius: BorderRadius.only(
                        //                   topLeft: Radius.circular(10),
                        //                   topRight: Radius.circular(10),
                        //                 ),
                        //                 color: Colors.white,
                        //               ),
                        //               padding: EdgeInsets.symmetric(
                        //                   vertical: 16, horizontal: 8),
                        //               child: Obx(
                        //                 () => Column(
                        //                   mainAxisSize: MainAxisSize.min,
                        //                   children: [
                        //                     SizedBox(height: Get.height * 0.02),
                        //                     Row(
                        //                       children: [
                        //                         GestureDetector(
                        //                           onTap: () {
                        //                             Navigator.pop(context);
                        //                           },
                        //                           child: Icon(Icons.arrow_back,
                        //                               color: Get
                        //                                   .theme.primaryColor),
                        //                         ),
                        //                         Expanded(
                        //                           child: Text(
                        //                             'select_a_gateway'.tr,
                        //                             style: Get
                        //                                 .textTheme.headline6
                        //                                 .copyWith(
                        //                                     color: Get.theme
                        //                                         .primaryColor),
                        //                             textAlign: TextAlign.center,
                        //                           ),
                        //                         ),
                        //                       ],
                        //                     ),
                        //                     SizedBox(height: Get.height * 0.02),
                        //                     GestureDetector(
                        //                       onTap: () {
                        //                         controller
                        //                             .updateSelectedPaymentGateway(
                        //                                 2);
                        //                       },
                        //                       child: Card(
                        //                         child: Container(
                        //                           color: controller
                        //                                       .selectedPaymentGatewayType
                        //                                       .value ==
                        //                                   2
                        //                               ? Colors.grey
                        //                                   .withOpacity(
                        //                                       0.4)
                        //                               : Colors.white,
                        //                           padding:
                        //                               EdgeInsets.all(16),
                        //                           child: Image.asset(
                        //                               'assets/esewa.png',
                        //                               height: Get.height *
                        //                                   0.1,
                        //                               width: Get.height *
                        //                                   0.1),
                        //                         ),
                        //                       ),
                        //                     ),
                        //                     SizedBox(height: 16),
                        //                     Container(
                        //                       width: Get.width,
                        //                       child: CustomButton(
                        //                         text: LocaleKeys.buttons_proceed.tr,
                        //                         onPressed: () async {},
                        //                       ),
                        //                     ),
                        //                     SizedBox(height: 16),
                        //                   ],
                        //                 ),
                        //               ),
                        //             );
                        //           });
                        //       if (status != null && status) {
                        //         // Get.offNamed(BillingScreen.id);
                        //       }
                        //       // final status = await paymentController.topUpWallet();
                        //       // if(status) {
                        //       //   CustomSnackbar.showCusotmSnackBar(message: 'Payment successful.');
                        //       //   Get.back();
                        //       //   Get.offNamed(BillingScreen.id);
                        //       //
                        //       // } else {
                        //       //   CustomSnackbar.showCusotmSnackBar(message: paymentController.error);
                        //       // }
                        //     },
                        //     text: LocaleKeys.buttons_online_payment.tr,
                        //     backgroundColor: Colors.red,
                        //   ),
                        // ),
                      ],
                    ),
                  ),
                  SizedBox(height: 16),
                ],
              ),
            ),
            // paymentController.progressBarStatus.value ? CustomProgressBar(): Container()
          ],
        ),
      ),
    );
  }
}
