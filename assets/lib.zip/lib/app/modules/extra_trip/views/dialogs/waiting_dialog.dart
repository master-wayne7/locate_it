import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/theme.dart';

import 'package:puryaideu/app/widgets/banner.dart' as ban;
import 'package:puryaideu/app/enums/ride_type.dart';
import 'package:puryaideu/app/modules/extra_trip/controllers/extra_trip_controller.dart';
import 'package:puryaideu/app/modules/trip/controllers/trip_controller.dart';
import 'package:puryaideu/app/widgets/custom_button.dart';
import 'package:puryaideu/app/widgets/sliding_up_panel.dart';
import 'package:puryaideu/generated/locales.g.dart';

import 'cancel_dialog.dart';

class WaitingDialog extends StatefulWidget {
  @override
  State<WaitingDialog> createState() => _WaitingDialogState();
}

class _WaitingDialogState extends State<WaitingDialog>
    with SingleTickerProviderStateMixin {
  final ExtraTripController controller = Get.find();

  AnimationController _animationController;
  Animation _animation;
  final PanelController _pc = new PanelController();

  @override
  void initState() {
    _animationController =
        AnimationController(vsync: this, duration: Duration(seconds: 1));
    _animationController.repeat(reverse: true);
    _animation = Tween(begin: 2.0, end: 15.0).animate(_animationController)
      ..addListener(() {
        setState(() {});
      });
    super.initState();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        SlidingUpPanel(
          controller: _pc,
          minHeight: Get.height * 0.1,
          maxHeight: Get.height * 0.45,
          renderPanelSheet: false,
          defaultPanelState: PanelState.CLOSED,
          panel: _floatingPanel(),
          collapsed: _floatingCollapsed(),
          body: Container(
            height: Get.height,
            width: Get.width,
            color: Colors.black12,
            child: Center(
              child: Container(
                width: 100,
                height: 100,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Image.asset(
                    controller.rideType.value == RideType.AMBULANCE
                        ? 'assets/new_ambulance.png'
                        : controller.rideType.value == RideType.FOOD_DELIVERY
                            ? 'assets/food_truck.png'
                            : controller.rideType.value == RideType.COURIER
                                ? 'assets/delivery.png'
                                : 'assets/new_ambulance.png',
                    fit: BoxFit.contain,
                  ),
                ),
                decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    boxShadow: [
                      BoxShadow(
                          color: Colors.black54,
                          blurRadius: _animation.value,
                          spreadRadius: _animation.value)
                    ]),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _floatingCollapsed() {
    return Container(
      margin: EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.only(
            topLeft: Radius.circular(24.0), topRight: Radius.circular(24.0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Center(
            child: Container(
              height: 3,
              width: 40,
              color: Colors.black,
            ),
          ),
          SizedBox(height: 16),
          GestureDetector(
            onTap: () {
              print('Test');
            },
            child: Text('Searching for riders...',
                style: Get.textTheme.bodyText2.copyWith(
                    color: Colors.black,
                    fontSize: getResponsiveFont(20),
                    fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }

  Widget _floatingPanel() {
    return ClipRRect(
      child: controller.rideType.value == RideType.AMBULANCE
          ? ban.BannerApp(
              layoutDirection: TextDirection.ltr,
              color: Get.theme.primaryColor,
              message: "Emergency",
              textStyle: Get.textTheme.headline5.copyWith(
                  color: Colors.white,
                  fontSize: getResponsiveFont(12),
                  fontWeight: FontWeight.w600),
              location: ban.BannerLocation.topEnd,
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 16),
                decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.only(
                        topLeft: Radius.circular(24.0),
                        topRight: Radius.circular(24.0)),
                    boxShadow: [
                      BoxShadow(
                        blurRadius: 20.0,
                        color: Colors.transparent,
                      ),
                    ]),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _floatingCollapsed(),
                    Divider(
                      height: 1,
                      color: Colors.black.withOpacity(0.7),
                    ),
                    SizedBox(height: 16),
                    Text('Trip Detail',
                        style: Get.textTheme.bodyText2.copyWith(
                            color: Colors.black,
                            fontSize: getResponsiveFont(16),
                            fontWeight: FontWeight.w600)),
                    SizedBox(height: 16),
                    Row(
                      children: [
                        Icon(Icons.my_location, color: Get.theme.primaryColor),
                        SizedBox(width: 16),
                        Expanded(
                            child: Text(
                          controller.originName.value,
                          style: Get.textTheme.bodyText2.copyWith(
                              color: Colors.black,
                              fontSize: getResponsiveFont(14),
                              fontWeight: FontWeight.w600),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        )),
                      ],
                    ),
                    SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(Icons.location_pin, color: Get.theme.primaryColor),
                        SizedBox(width: 16),
                        Expanded(
                            child: Text(
                          controller.destinationName.value,
                          style: Get.textTheme.bodyText2.copyWith(
                              color: Colors.black,
                              fontSize: getResponsiveFont(14),
                              fontWeight: FontWeight.w600),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        )),
                      ],
                    ),
                    SizedBox(height: 16),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(Icons.receipt, color: Get.theme.primaryColor),
                        SizedBox(width: 16),
                        Expanded(
                            child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            controller.rideType != RideType.AMBULANCE ? Text(
                                LocaleKeys.units_rs.tr + ' ${controller.price}',
                                style: Get.textTheme.bodyText2.copyWith(
                                    color: Colors.black,
                                    fontSize: getResponsiveFont(20),
                                    fontWeight: FontWeight.w700)): Text(
                          "No app charges*",
                          style: Get.textTheme.headline6.copyWith(
                              fontSize: getResponsiveFont(16)),
                        ),
                            SizedBox(height: 4),
                            controller.rideType != RideType.AMBULANCE ? Text('This is the estimated fare. It may vary.',
                                style: Get.textTheme.bodyText2.copyWith(
                                    color: Colors.black,
                                    fontSize: getResponsiveFont(12),
                                    fontWeight: FontWeight.w500)): Text(''),
                          ],
                        )),
                      ],
                    ),
                    SizedBox(height: 16),
                    Container(
                      width: Get.width,
                      child: CustomButton(
                        backgroundColor: Get.theme.primaryColor,
                        onPressed: () {
                          showDialog(
                              context: context,
                              builder: (_) {
                                return CancelDialog();
                              });
                        },
                        text: 'Cancel',
                      ),
                    ),
                  ],
                ),
              ))
          : Container(
              padding: EdgeInsets.symmetric(horizontal: 16),
              decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(24.0),
                      topRight: Radius.circular(24.0)),
                  boxShadow: [
                    BoxShadow(
                      blurRadius: 20.0,
                      color: Colors.transparent,
                    ),
                  ]),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _floatingCollapsed(),
                  Divider(
                    height: 1,
                    color: Colors.black.withOpacity(0.7),
                  ),
                  SizedBox(height: 16),
                  Text('Trip Detail',
                      style: Get.textTheme.bodyText2.copyWith(
                          color: Colors.black,
                          fontSize: getResponsiveFont(16),
                          fontWeight: FontWeight.w600)),
                  SizedBox(height: 16),
                  Row(
                    children: [
                      Icon(Icons.my_location, color: Get.theme.primaryColor),
                      SizedBox(width: 16),
                      Expanded(
                          child: Text(
                        controller.originName.value,
                        style: Get.textTheme.bodyText2.copyWith(
                            color: Colors.black,
                            fontSize: getResponsiveFont(14),
                            fontWeight: FontWeight.w600),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      )),
                    ],
                  ),
                  SizedBox(height: 8),
                  Row(
                    children: [
                      Icon(Icons.location_pin, color: Get.theme.primaryColor),
                      SizedBox(width: 16),
                      Expanded(
                          child: Text(
                        controller.destinationName.value,
                        style: Get.textTheme.bodyText2.copyWith(
                            color: Colors.black,
                            fontSize: getResponsiveFont(14),
                            fontWeight: FontWeight.w600),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      )),
                    ],
                  ),
                  SizedBox(height: 16),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Icon(Icons.receipt, color: Get.theme.primaryColor),
                      SizedBox(width: 16),
                      Expanded(
                          child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(LocaleKeys.units_rs.tr + ' ${controller.price}',
                              style: Get.textTheme.bodyText2.copyWith(
                                  color: Colors.black,
                                  fontSize: getResponsiveFont(20),
                                  fontWeight: FontWeight.w700)),
                          SizedBox(height: 4),
                          Text('This is the estimated fare. It may vary.',
                              style: Get.textTheme.bodyText2.copyWith(
                                  color: Colors.black,
                                  fontSize: getResponsiveFont(12),
                                  fontWeight: FontWeight.w500)),
                        ],
                      )),
                    ],
                  ),
                  SizedBox(height: 16),
                  Container(
                    width: Get.width,
                    child: CustomButton(
                      backgroundColor: Get.theme.primaryColor,
                      onPressed: () {
                        showDialog(
                            context: context,
                            builder: (_) {
                              return CancelDialog();
                            });
                      },
                      text: 'Cancel',
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
