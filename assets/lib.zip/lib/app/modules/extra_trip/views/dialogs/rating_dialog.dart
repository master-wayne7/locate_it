import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/modules/ratings/controllers/ratings_controller.dart';
import 'package:puryaideu/app/routes/app_pages.dart';
import 'package:puryaideu/app/widgets/custom_button.dart';
import 'package:puryaideu/app/widgets/custom_progress_bar.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:shimmer/shimmer.dart';

class RatingDialog extends StatelessWidget {
  final RatingController ratingController = Get.put(RatingController());



  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
          child: GetBuilder<RatingController>(
            builder: (myController) => Stack(
              children: [
                Column(
                  children: [
                    SizedBox(height: 16),
                    GestureDetector(
                      onTap: (){
                      },
                      child: Center(
                        child: Text(
                          'Rate Rider'.tr,
                          style: Get.textTheme.headline6,
                        ),
                      ),
                    ),
                    SizedBox(height: Get.height * 0.05),
                    ClipRRect(
                        borderRadius: BorderRadius.circular(50),
                        child: CachedNetworkImage(
                          imageUrl:
                          '$BASE_URL/${"uploads/user/abf70e41fce3cd7381119cac7cd858bcb7c399f1.jpg"}',
                          height: 100,
                          width: 100,
                          fit: BoxFit.cover,
                        )),
                    SizedBox(height: 8),
                    Text(
                      'Rhythm B.',
                      style: Get.textTheme.headline5,
                    ),
                    SizedBox(height: 8),
                    Text(
                      'User'.tr,
                      style: Get.textTheme.bodyText2.copyWith(color: Colors.grey),
                    ),
                    SizedBox(height: 16),
                    RatingBar(
                        minRating: 1.0,
                        initialRating: ratingController.rating,
                        glow: false,
                        direction: Axis.horizontal,
                        allowHalfRating: true,
                        itemCount: 5,
                        ratingWidget: RatingWidget(
                            full: Icon(Icons.star, color:  Color(0xffFFD700)),
                            half: Icon(
                              Icons.star_half,
                              color:  Color(0xffFFD700),
                            ),
                            empty: Icon(Icons.star_outline,
                                color:  Color(0xffFFD700))),
                        onRatingUpdate: (value) {
                          ratingController.setRating(value);
                        }),
                    SizedBox(height: 16),
                    Obx(() => Text(ratingController.ratingResponse)),
                    SizedBox(height: 16), Expanded(
                      child: Container(
                          child: ratingController.ratingSuggestions.length > 0 ? ListView.builder(
                            padding: EdgeInsets.symmetric(horizontal: 16),
                            itemBuilder: (context, index) {
                              return Card(
                                child: Container(
                                  padding: EdgeInsets.all(16),
                                  child: Row(
                                    children: [
                                      CachedNetworkImage(
                                        height: 40,
                                        width: 40,
                                        imageUrl:
                                        '$BASE_URL/${myController.ratingSuggestions[index].imagePath}',
                                      ),
                                      SizedBox(width: 16),
                                      Expanded(
                                        child: Text(
                                          myController
                                              .ratingSuggestions[index].text,
                                          style: Get.textTheme.bodyText2,
                                        ),
                                      ),
                                      SizedBox(width: 16),
                                      Radio(
                                        value: myController
                                            .ratingSuggestions[index].id,
                                        groupValue: myController.groupValue,
                                        onChanged: (value) {
                                          myController.updateGroupValue(value);
                                        },
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                            itemCount: myController.ratingSuggestions.length,
                          ): ListView.builder(
                              padding: EdgeInsets.symmetric(horizontal: 16),
                              itemBuilder: (context, index) {
                                return Shimmer.fromColors(
                                    baseColor: Color(0xffeeeff3),
                                highlightColor: Colors.white,
                                enabled: true,
                                child: Card(
                                  child: Container(
                                    padding: EdgeInsets.all(16),
                                    child: Row(
                                      children: [
                                        ClipRRect(
                                            borderRadius: BorderRadius.circular(10),
                                            child: Container(
                                                height: 40,
                                                width: 40,
                                                color:Colors.white
                                            )),
                                        SizedBox(width: 16),
                                        Expanded(
                                          child: Container(
                                            width: 100,
                                            height: 14,
                                            decoration: BoxDecoration(
                                              color: Colors.white,
                                              borderRadius: BorderRadius.circular(16),
                                            ),
                                          ),
                                        ),
                                        SizedBox(width: 16),
                                      ],
                                    ),
                                  ),
                                ));
                              },
                              itemCount: 3,
                            ),
                          )
                      ),
                    SizedBox(height: 4),
                    Container(
                      margin: EdgeInsets.symmetric(horizontal: 16),
                      width: Get.width,
                      child: CustomButton(
                        backgroundColor: Get.theme.primaryColor,
                        onPressed: () async {
                          final response = true;
                          if (response) {
                            Get.offAllNamed(Routes.DASHBOARD);
                            CustomSnackbar.showCustomSnackBar(message: 'Rider rated successfully. Thank you!');
                            // await homeController.getAvailableBookings();
                            // await historyController.getBookingHistory();

                          } else {
                            CustomSnackbar.showCustomSnackBar(
                                message: 'something_went_wrong'.tr);
                          }
                        },
                        text: 'Rate'.tr,
                      ),
                    ),
                    SizedBox(height: 8),
                    Container(
                        margin: EdgeInsets.symmetric(horizontal: 16),
                        width: Get.width,
                        child: TextButton(
                            style: ButtonStyle(
                                backgroundColor: MaterialStateProperty.all<Color>(
                                    Get.theme.accentColor.withOpacity(1)),
                                overlayColor: MaterialStateProperty.all<Color>(
                                    Get.theme.accentColor.withOpacity(0.1)),
                                padding: MaterialStateProperty.all<EdgeInsets>(
                                    EdgeInsets.symmetric(vertical: 16))),
                            onPressed: () async{
                              Get.offAllNamed(Routes.DASHBOARD);
                              // await homeController.getAvailableBookings();
                              // await historyController.getBookingHistory();
                            },
                            child: Text(
                              'Later'.tr,
                              style: Get.textTheme.headline5
                                  .copyWith(fontSize: getResponsiveFont(14), color: Colors.white),
                            ))),
                    SizedBox(height: 16),
                  ],
                ),
                Obx(
                      () => ratingController.showProgress
                      ? CustomProgressBar()
                      : Container(),
                ),
              ],
            ),
          ),
        ));
  }
}
