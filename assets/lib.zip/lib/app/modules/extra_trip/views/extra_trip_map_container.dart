import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/modules/extra_trip/controllers/extra_trip_controller.dart';
import 'package:puryaideu/app/modules/extra_trip/controllers/extra_trip_map_controller.dart';
import 'package:puryaideu/app/modules/trip/controllers/trip_controller.dart';
import 'package:puryaideu/app/modules/trip/controllers/trip_map_controller.dart';
import 'package:puryaideu/app/utils/local_notifications_singleton.dart';

class ExtraTripMapContainer extends StatefulWidget {
  @override
  _ExtraTripMapContainerState createState() => _ExtraTripMapContainerState();
}

class _ExtraTripMapContainerState extends State<ExtraTripMapContainer>
    with WidgetsBindingObserver {
  ExtraTripMapController controller = Get.find();
  ExtraTripController tripController = Get.find();

  @override
  void initState() {
    WidgetsBinding.instance.addObserver(this);
    super.initState();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) {
      controller.updateMapStyle();
    }
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<ExtraTripMapController>(
      builder: (myController) =>
          Obx(
            () =>
                GoogleMap(
          initialCameraPosition:
          CameraPosition(zoom: 16, target: SessionManager.instance.currentLocation),
          myLocationEnabled: true,
          myLocationButtonEnabled: false,
          compassEnabled: false,
          mapType: MapType.normal,
          padding: EdgeInsets.only(bottom: controller.googlePadding),
          polylines: myController.polylines,
          zoomGesturesEnabled: true,
          // polygons: PolygonPoints.myPolygon(),
          zoomControlsEnabled: false,
          markers: controller.markers.value,
          onMapCreated: (GoogleMapController _controller) {
            controller.updateMapController(_controller);
          },
        ),
      ),
    );
  }
}
