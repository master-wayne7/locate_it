import 'dart:typed_data';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:flutter_svg/svg.dart';

import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:intl/intl.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/data/models/booking.dart';
import 'package:puryaideu/app/data/models/rider.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/enums/ride_type.dart';
import 'package:puryaideu/app/modules/history/controllers/history_controller.dart';
import 'package:puryaideu/app/modules/history/model/booking_history.dart';
import 'package:puryaideu/app/modules/payment_options/invoice/billings/information.dart' as i;
import 'package:puryaideu/app/modules/payment_options/invoice/billings/invoice_generator.dart';
import 'package:puryaideu/app/modules/payment_options/invoice/billings/pdf_generator.dart';
import 'package:puryaideu/app/routes/app_pages.dart';
import 'package:puryaideu/app/utils/date_time_converter.dart';
import 'package:puryaideu/app/widgets/custom_button.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:puryaideu/app/widgets/notifications_shimmer.dart';
import 'package:puryaideu/app/widgets/trip_detail_shimmer.dart';
import 'package:shimmer/shimmer.dart';

import '../controllers/history_detail_controller.dart';

class HistoryDetailView extends GetView<HistoryDetailController> {
  final BookingHistory booking;
  final Rider rider;
  String rideType;
  final HistoryController historyController = Get.find();

  // final Color color;
  // final IconData icon;
  HistoryDetailView({this.booking, this.rider, this.rideType});

  int num = 10;

  generatePdf() async {
    num = num + 1;
    final date = DateTime.now();


    final price = booking.priceDetail;
    final invoice = i.Invoice(
        company: i.Company(
          name: 'Puryaideu',
          email: 'puryaideu@gmail.com',
          address: 'Sanepa, Nepal',
        ),
        customer: i.Customer(
          name: SessionManager.instance.user.name,
          address: SessionManager.instance.user.phone,
          paymentInfo:'Cash',
        ),
        rider: i.Rider(
          name: '${historyController.rider.value.firstName} ${historyController.rider.value.lastName}',
          address: '',
        ),
        info: i.InvoiceInfo(
            date: date,
            description: 'Below is the invoice',
            //number: '${DateTime.now().year}-00-00$num',
            number: booking.booking.tripId),
        items: i.InvoiceItem(
          rideType: booking.booking.vehicleTypeId ==
              null
              ? 'Bike'
              : booking.booking.vehicleTypeId ==
              '2'
              ? 'Car'
              : booking.booking.vehicleTypeId ==
              '3'
              ? 'City Safari'
              : booking.booking.vehicleTypeId ==
              '4'
              ? 'Ambulance'
              : 'Bike',
          date:
          '${DateTime.now().year}/${DateTime.now().month}/${DateTime.now().day} '
              ' ${DateTime.now().hour}:${DateTime.now().minute}:${DateTime.now().second}',
          origin: booking.location.origin.name,
          destination:
          booking.location.destination.name,
          distance: double.parse(booking.distance)/1000,
          price: double.parse(booking.price.toString()),
        ),
        price: i.InvoicePrice(
            minimumCharge: price.baseFare.toStringAsFixed(2),
            perKMFare: (price.priceAfterDistance).toStringAsFixed(2),
            appCharges: price.appCharge.toStringAsFixed(2),
            appChargesRate: booking.priceDetail.appChargePercent
                .toStringAsFixed(2),
            surgePerKM: booking.priceDetail.chargedKm
                .toStringAsFixed(2),
            surgeRate: booking.priceDetail.pricePerKmAfterSurge
                .toStringAsFixed(2),
            priceAfterDistance: booking.priceDetail.priceAfterDistance
                .toStringAsFixed(2),
            surge: booking.priceDetail.surge
                .toStringAsFixed(2),
            chargedKm: booking.priceDetail.chargedKm
                .toStringAsFixed(2),
            priceAfterSurge: booking.priceDetail.priceAfterSurge.toStringAsFixed(2),
            perMinuteChargeRate: booking.priceDetail.pricePerMin.toStringAsFixed(2),
            perKMRate: booking.priceDetail.pricePerKm.toStringAsFixed(2),
            perMinuteCharge: booking.priceDetail.durationCharge.toStringAsFixed(2),
            takenTime: booking.duration,
            total: booking.priceDetail.totalPrice.toStringAsFixed(2),
            baseFare: booking.priceDetail.minimumCharge.toStringAsFixed(2)));

    print('We are here');

    final ByteData bytes = await rootBundle.load('assets/logo.png');
    final Uint8List byteList = bytes.buffer.asUint8List();

    final pdfFile = await InvoiceGenerator.generate(invoice, byteList);
    PdfApi.openFile(pdfFile);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(0xffeeeff3),
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Text(
          'Trip details'.tr,
          style: Get.textTheme.headline5.copyWith(
              color: Get.theme.primaryColor,
              fontSize: getResponsiveFont(20),
              fontWeight: FontWeight.w600),
        ),
        centerTitle: true,
        backgroundColor: Colors.white,
        elevation: 0.6,
        leading: IconButton(
          icon: Icon(Icons.arrow_back, color: Get.theme.primaryColor),
          onPressed: () {
            Get.back();
          },
        ),
      ),
      body: SafeArea(
        child: FutureBuilder<bool>(
            future: historyController.getRiderDetail(booking.riderId),
            builder: (context, AsyncSnapshot<bool> snapshot) {
              if (snapshot.data == true) {
                return Column(
                  children: [
                    Expanded(
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            Container(
                              width: Get.width,
                              padding: EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: Colors.white,
                              ),
                              child: Row(
                                children: [
                                  Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        'Trip ID',
                                        style: Get.textTheme.headline5.copyWith(
                                            fontWeight: FontWeight.w500,
                                            color: Colors.grey[600],
                                            fontSize: getResponsiveFont(15)),
                                      ),
                                      SizedBox(height: getResponsiveFont(8)),
                                      Text(
                                        booking.booking.tripId,
                                        style: Get.textTheme.headline5.copyWith(
                                            fontWeight: FontWeight.w600,
                                            color: Colors.black,
                                            fontSize: getResponsiveFont(20)),
                                      ),
                                    ],
                                  ),
                                  Expanded(
                                    child: SizedBox(),
                                  ),
                                  IconButton(
                                      icon: Icon(Icons.copy),
                                      onPressed: () {
                                        Clipboard.setData(ClipboardData(
                                            text: booking.booking.tripId));
                                        CustomSnackbar.showCustomSnackBar(
                                            message:
                                                'Trip ID successfully copied.');
                                      }),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: Get.height * (getResponsiveFont(0.01)),
                            ),
                            Container(
                              color: Colors.white,
                              padding: EdgeInsets.only(
                                  left: 16, right: 16, top: 16, bottom: 16),
                              child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  children: [
                                    Text(
                                      'Trip Info',
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: Get.textTheme.headline5.copyWith(
                                          fontWeight: FontWeight.w600,
                                          fontSize: getResponsiveFont(20),
                                          color: Colors.black),
                                    ),
                                    Expanded(
                                        child: SizedBox(
                                      width: getResponsiveFont(Get.width * 0.5),
                                    )),
                                    Container(
                                      decoration: BoxDecoration(
                                        borderRadius: BorderRadius.circular(15),
                                        color: Colors.transparent,
                                      ),
                                      child: Image.asset(
                                        rideType == "bike"
                                            ? "assets/bike.png"
                                            : rideType == "car"
                                                ? "assets/car.png"
                                                : "assets/city_safari.png",
                                        height: 30,
                                        width: 30,
                                      ),
                                    ),
                                  ]),
                            ),
                            Container(
                              color: Colors.white,
                              padding: EdgeInsets.only(
                                  left: 16, right: 16, top: 4, bottom: 16),
                              child: Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  children: [
                                    Text(
                                      DateTimeConverter.tripDateFormatter(
                                          booking.endTime),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: Get.textTheme.headline5.copyWith(
                                          fontWeight: FontWeight.w500,
                                          fontSize: getResponsiveFont(18),
                                          color: Colors.black),
                                    ),
                                    Expanded(
                                        child: SizedBox(
                                      width: getResponsiveFont(Get.width * 0.5),
                                    )),
                                    Text(
                                      DateFormat.jm().format(booking.endTime),
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: Get.textTheme.headline5.copyWith(
                                          fontWeight: FontWeight.w500,
                                          fontSize: getResponsiveFont(18),
                                          color: Colors.black),
                                    ),
                                  ]),
                            ),
                            Container(
                              color: Colors.white,
                              padding: EdgeInsets.only(
                                  left: 16, right: 16, top: 4, bottom: 16),
                              child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceEvenly,
                                  children: [
                                    Row(
                                      children: [
                                        Icon(Icons.my_location),
                                        SizedBox(width: getResponsiveFont(16)),
                                        Expanded(
                                          child: Text(
                                            booking.location.origin.name,
                                            maxLines: 3,
                                            overflow: TextOverflow.ellipsis,
                                            style: Get.textTheme.headline5
                                                .copyWith(
                                                    fontWeight: FontWeight.w500,
                                                    fontSize:
                                                        getResponsiveFont(16),
                                                    color: Colors.grey[800]),
                                          ),
                                        ),
                                      ],
                                    ),
                                    SizedBox(height: getResponsiveFont(16)),
                                    Row(
                                      children: [
                                        Icon(Icons.location_pin,
                                            color: Get.theme.primaryColor),
                                        SizedBox(width: getResponsiveFont(16)),
                                        Expanded(
                                          child: Text(
                                            booking.location.destination.name,
                                            maxLines: 1,
                                            overflow: TextOverflow.ellipsis,
                                            style: Get.textTheme.headline5
                                                .copyWith(
                                                    fontWeight: FontWeight.w500,
                                                    fontSize:
                                                        getResponsiveFont(16),
                                                    color: Colors.grey[800]),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ]),
                            ),
                            SizedBox(
                              height: Get.height * (getResponsiveFont(0.01)),
                            ),
                            historyController.rider.value.firstName == null ? Container() : Container(
                              color: Colors.white,
                              padding: EdgeInsets.only(
                                  left: 16, right: 16, top: 16, bottom: 16),
                              child: Row(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(10),
                                    child: CachedNetworkImage(
                                      height:
                                          Get.width * getResponsiveFont(0.12),
                                      width:
                                          Get.width * getResponsiveFont(0.12),
                                      imageUrl:
                                          '$BASE_URL/${historyController.rider.value.imagePath}',
                                      placeholder: (context, url) =>
                                          Icon(Icons.person),
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  SizedBox(width: 16),
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                            '${historyController.rider.value.firstName} ${historyController.rider.value.lastName}',
                                            style: Get.textTheme.headline5
                                                .copyWith(
                                                    fontWeight: FontWeight.w500,
                                                    fontSize:
                                                        getResponsiveFont(16),
                                                    color: Colors.grey[900])),
                                      ],
                                    ),
                                  ),
                                  IgnorePointer(
                                    child: RatingBar(
                                        initialRating:
                                            booking.booking.review != null
                                                ? booking.booking.review.rate
                                                    .toDouble()
                                                : 0,
                                        glow: false,
                                        direction: Axis.horizontal,
                                        allowHalfRating: true,
                                        tapOnlyMode: false,
                                        updateOnDrag: false,
                                        itemCount: 5,
                                        itemSize: getResponsiveFont(16.0),
                                        ratingWidget: RatingWidget(
                                            full: Icon(Icons.star,
                                                color: Color(0xffFFD700)),
                                            half: Icon(
                                              Icons.star_half,
                                              color: Color(0xffFFD700),
                                            ),
                                            empty: Icon(Icons.star_outline,
                                                color: Color(0xffFFD700))),
                                        onRatingUpdate: (value) {}),
                                  ),
                                ],
                              ),
                            ),
                            SizedBox(
                              height: Get.height * (getResponsiveFont(0.01)),
                            ),
                            Container(
                              color: Colors.white,
                              padding: EdgeInsets.only(
                                  left: 16, right: 16, top: 16, bottom: 16),
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      "Bill Breakdown",
                                      maxLines: 1,
                                      overflow: TextOverflow.ellipsis,
                                      style: Get.textTheme.headline5.copyWith(
                                          fontWeight: FontWeight.w600,
                                          fontSize: getResponsiveFont(20),
                                          color: Colors.black),
                                    ),
                                  ),
                                  GestureDetector(
                                      onTap: () {
                                        generatePdf();
                                      },
                                      child: Icon(Icons.download_rounded)),
                                  SizedBox(width: 16),
                                ],
                              ),
                            ),
                            Container(
                              color: Colors.white,
                              padding: EdgeInsets.only(
                                  left: 16, right: 16, bottom: 16),
                              child: Column(
                                children: [
                                  Row(
                                    children: [
                                      Text(
                                        "Base fare: ",
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: Get.textTheme.headline5.copyWith(
                                            fontWeight: FontWeight.w600,
                                            fontSize: getResponsiveFont(16),
                                            color: Colors.grey[800]),
                                      ),
                                      Expanded(child: SizedBox()),
                                      Text(
                                        "Rs. " + booking.priceDetail.baseFare.toStringAsFixed(2),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: Get.textTheme.headline5.copyWith(
                                            fontWeight: FontWeight.w600,
                                            fontSize: getResponsiveFont(16),
                                            color: Colors.grey[800]),
                                      ),
                                    ],
                                  ),
                                  Divider(),
                                  Row(
                                    children: [
                                      Text(
                                        (double.parse(booking.distance)/1000).toStringAsFixed(2) +" Kilometers ",
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: Get.textTheme.headline5.copyWith(
                                            fontWeight: FontWeight.w600,
                                            fontSize: getResponsiveFont(16),
                                            color: Colors.grey[800]),
                                      ),
                                      Expanded(child: SizedBox()),
                                      Text(
                                        "Rs. " + booking.priceDetail.priceAfterDistance.toStringAsFixed(2),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: Get.textTheme.headline5.copyWith(
                                            fontWeight: FontWeight.w600,
                                            fontSize: getResponsiveFont(16),
                                            color: Colors.grey[800]),
                                      ),
                                    ],
                                  ),
                                  Divider(),
                                  Row(
                                    children: [
                                      Text(
                                        (double.parse(booking.duration)).toStringAsFixed(2) + " Minutes: ",
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: Get.textTheme.headline5.copyWith(
                                            fontWeight: FontWeight.w600,
                                            fontSize: getResponsiveFont(16),
                                            color: Colors.grey[800]),
                                      ),
                                      Expanded(child: SizedBox()),
                                      Text(
                                        "Rs. " + booking.priceDetail.pricePerMin.toStringAsFixed(2),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: Get.textTheme.headline5.copyWith(
                                            fontWeight: FontWeight.w600,
                                            fontSize: getResponsiveFont(16),
                                            color: Colors.grey[800]),
                                      ),
                                    ],
                                  ),
                                  Divider(),

                                  Row(
                                    children: [
                                      Text(
                                        "Surge: ",
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: Get.textTheme.headline5.copyWith(
                                            fontWeight: FontWeight.w600,
                                            fontSize: getResponsiveFont(16),
                                            color: Colors.grey[800]),
                                      ),
                                      Expanded(child: SizedBox()),
                                      Text(
                                        "Rs. " + booking.priceDetail.surge.toStringAsFixed(2),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: Get.textTheme.headline5.copyWith(
                                            fontWeight: FontWeight.w600,
                                            fontSize: getResponsiveFont(16),
                                            color: Colors.grey[800]),
                                      )
                                    ],
                                  ),
                                  Divider(),
                                  Row(
                                    children: [
                                      Text(
                                        "App charges: ",
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: Get.textTheme.headline5.copyWith(
                                            fontWeight: FontWeight.w600,
                                            fontSize: getResponsiveFont(16),
                                            color: Colors.grey[800]),
                                      ),
                                      Expanded(child: SizedBox()),
                                      Text(
                                        "Rs. " + booking.priceDetail.appCharge.toStringAsFixed(2),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: Get.textTheme.headline5.copyWith(
                                            fontWeight: FontWeight.w600,
                                            fontSize: getResponsiveFont(16),
                                            color: Colors.grey[800]),
                                      ),
                                    ],
                                  ),
                                  Divider(),
                                  // Row(
                                  //   children: [
                                  //     Text(
                                  //       "Subtotal: ",
                                  //       maxLines: 1,
                                  //       overflow: TextOverflow.ellipsis,
                                  //       style: Get.textTheme.headline5.copyWith(
                                  //           fontWeight: FontWeight.w600,
                                  //           fontSize: getResponsiveFont(17),
                                  //           color: Colors.grey[900]),
                                  //     ),
                                  //     Expanded(child: SizedBox()),
                                  //     Text(
                                  //       "Rs. " + "148.00",
                                  //       maxLines: 1,
                                  //       overflow: TextOverflow.ellipsis,
                                  //       style: Get.textTheme.headline5.copyWith(
                                  //           fontWeight: FontWeight.w600,
                                  //           fontSize: getResponsiveFont(17),
                                  //           color: Colors.grey[900]),
                                  //     )
                                  //   ],
                                  // ),
                                  // Divider(),
                                  Row(
                                    children: [
                                      Text(
                                        "Total: ",
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: Get.textTheme.headline5.copyWith(
                                            fontWeight: FontWeight.w600,
                                            fontSize: getResponsiveFont(19),
                                            color: Colors.grey[900]),
                                      ),
                                      Expanded(child: SizedBox()),
                                      Text(
                                        "Rs. " + booking.priceDetail.totalPrice.toStringAsFixed(2),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: Get.textTheme.headline5.copyWith(
                                            fontWeight: FontWeight.w600,
                                            fontSize: getResponsiveFont(19),
                                            color: Colors.grey[900]),
                                      )
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                    GestureDetector(
                      onTap: () async {
                      },
                      child: Container(
                        width: Get.width,
                        height: Get.height * (getResponsiveFont(0.07)),
                        child: MaterialButton(
                          color: Get.theme.primaryColor,
                          child: Text('Request Again',
                              style: TextStyle(
                                  fontSize: getResponsiveFont(18),
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600)),
                          onPressed: () {
                            print('Request again');
                            Get.toNamed(Routes.BOOKING, arguments: [
                              RideType.BIKE,
                              booking.location.origin.name,
                              booking.location.destination.name,
                              LatLng(booking.location.origin.latitude,
                                  booking.location.origin.longitude),
                              LatLng(booking.location.destination.latitude,
                                  booking.location.destination.longitude)
                            ]);
                            // SessionManager.instance.
                            // Get.toNamed(Routes.BOOKING, arguments: RideType.BIKE);
                          },
                        ),
                      ),
                    ),
                  ],
                );
              } else {
                return TripDetailShimmer();
              }
            }),
      ),
    );
  }
}
