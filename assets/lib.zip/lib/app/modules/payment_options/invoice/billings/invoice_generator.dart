import 'dart:io';
import 'package:intl/intl.dart';

import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart';

import 'dart:typed_data';

import 'information.dart';
import 'pdf_generator.dart';

class InvoiceGenerator {
  var format = DateFormat.yMd('en');

  InvoiceGenerator();

  testFunction() {}

  static Future<File> generate(Invoice invoice, byteList) async {
    final pdf = Document();

    pdf.addPage(MultiPage(
      build: (context) => [
        buildTop(invoice),
        Divider(),
        buildHeader(invoice, byteList),
        SizedBox(height: 1 * PdfPageFormat.cm),
        buildTitle(invoice),
      ],
    ));

    return PdfApi.saveDocument(name: 'user_invoice.pdf', pdf: pdf);
  }

  static Widget buildTop(Invoice invoice) => Column(
    children: [
      Text("Invoice",
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
          ),
          textAlign: TextAlign.center),
    ],
  );

  static Widget buildHeader(Invoice invoice, byteList) {
    final Uint8List image = byteList;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        //SizedBox(height: 1 * PdfPageFormat.cm),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            buildCompanyAddress(invoice.company),
            Container(
                height: 50,
                width: 100,
                child: Image(
                    MemoryImage(
                      image,
                    ),
                    fit: BoxFit.fitHeight)),
          ],
        ),
        //SizedBox(height: 1 * PdfPageFormat.cm),
        Row(
          crossAxisAlignment: CrossAxisAlignment.end,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            buildCustomerAddress(invoice.customer),
            buildInvoiceInfo(invoice.info),
          ],
        ),
      ],
    );
  }

  static Widget buildCompanyAddress(Company company) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Text(company.name,
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      SizedBox(height: 1 * PdfPageFormat.mm),
      Text(company.address,
          style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
    ],
  );

  static Widget buildCustomerAddress(Customer customer) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      RichText(
        text: new TextSpan(
          children: <TextSpan>[
            new TextSpan(
                text: 'Customer Name: ',
                style: new TextStyle(fontWeight: FontWeight.bold)),
            new TextSpan(text: customer.name),
          ],
        ),
      ),
      RichText(
        text: new TextSpan(
          children: <TextSpan>[
            new TextSpan(
                text: 'Customer Phone: ',
                style: new TextStyle(fontWeight: FontWeight.bold)),
            new TextSpan(text: customer.address),
          ],
        ),
      ),
      RichText(
        text: new TextSpan(
          children: <TextSpan>[
            new TextSpan(
                text: 'Payment Method: ',
                style: new TextStyle(fontWeight: FontWeight.bold)),
            new TextSpan(text: customer.paymentInfo ),
          ],
        ),
      ),
    ],
  );

  static Widget buildInvoiceInfo(InvoiceInfo info) {
    final titles = <String>[
      'Trip Id:',
      'Invoice Date:',
    ];
    final data = <String>[
      info.number,
      Utils.formatDate(info.date),
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: List.generate(titles.length, (index) {
        final title = titles[index];
        final value = data[index];

        return buildText(title: title, value: value, width: 200);
      }),
    );
  }

/*
  static Widget buildContainer(Invoice invoice) => Container(
  margin: const EdgeInsets.all(15.0),
  padding: const EdgeInsets.all(3.0),
  decoration: BoxDecoration(
    border: Border.all(color: PdfColor.fromHex('FFA500'))
  ),
  child: buildTitle(invoice),
  );
*/
  static Widget buildTitle(Invoice invoice) => Column(
    crossAxisAlignment: CrossAxisAlignment.start,
    //mainAxisAlignment: MainAxisAlignment.spaceBetween,
    children: [
      Text(
        'Ride Description',
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      Divider(),
      buildInvoiceRideType(invoice.items),
      SizedBox(height: 0.5 * PdfPageFormat.cm),
      // buildInvoiceRiderName(invoice.rider),
      // SizedBox(height: 0.5 * PdfPageFormat.cm),
      buildInvoiceRideDate(invoice.items),
      SizedBox(height: 0.5 * PdfPageFormat.cm),
      buildInvoiceRideOrigin(invoice.items),
      SizedBox(height: 0.5 * PdfPageFormat.cm),
      buildInvoiceRideDestination(invoice.items),
      SizedBox(height: 0.5 * PdfPageFormat.cm),
      buildInvoiceRideDistance(invoice.items),
      //SizedBox(height: 0.8 * PdfPageFormat.cm),
      //buildInvoiceRidePrice(invoice.items),
      SizedBox(height: 8 * PdfPageFormat.mm),
      Text(
        'Price Breakdown',
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      Divider(),
      buildInvoiceMinimumFare(invoice.price),
      SizedBox(height: 0.5 * PdfPageFormat.cm),
      buildInvoiceMinimumCharge(invoice.price),
      SizedBox(height: 0.5 * PdfPageFormat.cm),
      buildInvoicePerKMTotal(invoice.price, invoice.items),
      SizedBox(height: 0.5 * PdfPageFormat.cm),
      buildInvoiceSurge(invoice.price),
      SizedBox(height: 0.5 * PdfPageFormat.cm),
      buildInvoiceAppCharge(invoice.price),
      SizedBox(height: 0.5 * PdfPageFormat.cm),
      buildInvoicePerMinCharge(invoice.price),
      SizedBox(height: 0.5 * PdfPageFormat.cm),
      Divider(),
      buildInvoiceTotal(invoice.price),
      SizedBox(height: 0.5 * PdfPageFormat.cm),
      buildFooter(invoice),
    ],
  );

  static Widget buildInvoiceRideType(InvoiceItem item) {
    return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: Text('Booking Type: ',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center),
          ),
          Container(
            child: Text(item.rideType,
                style: TextStyle(fontSize: 16), textAlign: TextAlign.center),
          ),
        ]);
  }

  static Widget buildInvoiceRiderName(Rider rider) {
    return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: Text('Driver Name: ',
                style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center),
          ),
          Container(
            child: Text(rider.name,
                style: TextStyle(fontSize: 16), textAlign: TextAlign.center),
          ),
        ]);
  }


  static Widget buildInvoiceRideDate(InvoiceItem item) {
    return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: Text('Ride Date: ',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center),
          ),
          Container(
            child: Text(item.date,
                style: TextStyle(fontSize: 16), textAlign: TextAlign.center),
          ),
        ]);
  }

  static Widget buildInvoiceRideOrigin(InvoiceItem item) {
    return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: Text('Ride Origin: ',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Container(
              child: Text(item.origin,
                  style: TextStyle(fontSize: 16), textAlign: TextAlign.right),
            ),
          ),
        ]);
  }

  static Widget buildInvoiceRideDestination(InvoiceItem item) {
    return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: Text('Ride Destination: ',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center),
          ),
          SizedBox(width: 16),
          Expanded(
            child: Container(
              child: Text(item.destination,
                  style: TextStyle(fontSize: 16 ), textAlign: TextAlign.right),
            ),
          ),
        ]);
  }

  static Widget buildInvoiceRideDistance(InvoiceItem item) {
    return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: Text('Total Distance: ',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center),
          ),
          Container(
            child: Text(item.distance.toString() + " Km",
                style: TextStyle(fontSize: 16), textAlign: TextAlign.center),
          ),
        ]);
  }

  static buildText({
    String title,
    String value,
    double width = double.infinity,
    TextStyle titleStyle,
    bool unite = false,
  }) {
    final style = titleStyle ?? TextStyle(fontWeight: FontWeight.bold);

    return Container(
      width: width,
      child: Row(
        children: [
          Expanded(child: Text(title, style: style)),
          Text(value, style: unite ? style : null),
        ],
      ),
    );
  }

  static Widget buildInvoiceMinimumCharge(InvoicePrice price) {
    return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: Text("Base Fare: ",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 40.0),
            child: Container(
              child: Text(price.chargedKm.toString() + ' KM',
                  style: TextStyle(fontSize: 16),
                  textAlign: TextAlign.center),
            ),
          ),
          Container(
            child: Text("= " + 'NPR ' + price.minimumCharge.toString(),
                style: TextStyle(fontSize: 16), textAlign: TextAlign.center),
          ),
        ]);
  }

  static Widget buildInvoicePerKMTotal(InvoicePrice price, InvoiceItem item) {
    return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: Text("Per KM Fare: ",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 40.0),
            child: Container(
              child: Text(
                  '(' + item.distance.toStringAsFixed(2) + ' - ' +price.chargedKm.toString()+ ')'  +
                      " KM * " +
                      price.perKMRate.toString() +
                      ' NPR',
                  style: TextStyle(fontSize: 16),
                  textAlign: TextAlign.center),
            ),
          ),
          Container(
            child: Text("= " + 'NPR ' + price.perKMFare.toString(),
                style: TextStyle(fontSize: 16), textAlign: TextAlign.center),
          ),
        ]);
  }

  static Widget buildInvoiceSurge(InvoicePrice price) {
    return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: Text("Surge: ",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 90.0),
            child: Container(
              child: Text(
                  '( ' +
                      price.surgePerKM +
                      ' * ' +
                      price.surgeRate +
                      ' ) - ' +
                      price.priceAfterDistance,
                  style: TextStyle(fontSize: 16),
                  textAlign: TextAlign.center),
            ),
          ),
          Container(
            child: Text('= NPR   ' + '${(double.parse(price.surge) * 1.00).toStringAsFixed(2)}',
                style: TextStyle(fontSize: 16), textAlign: TextAlign.center),
          ),
        ]);
  }

  static Widget buildInvoiceAppCharge(InvoicePrice price) {
    return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: Text("App charges:",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center),
          ),
          Padding(
            padding: const EdgeInsets.only(left: 30.0),
            child: Container(
              child: Text(price.priceAfterSurge.toString() + ' * ${price.appChargesRate}% ',
                  style: TextStyle(fontSize: 16), textAlign: TextAlign.center),
            ),
          ),
          Container(
            child: Text('= NPR   ' + price.appCharges.toString(),
                style: TextStyle(fontSize: 16), textAlign: TextAlign.center),
          ),
        ]);
  }

  static Widget buildInvoicePerMinCharge(InvoicePrice price) {
    return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: Text("Per Minute Charge:",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center),
          ),
          Container(
            child: Text(
                price.takenTime.toString() +
                    ' mins * ' +
                    price.perMinuteChargeRate.toString() +
                    ' NPR',
                style: TextStyle(fontSize: 16),
                textAlign: TextAlign.center),
          ),
          Container(
            child: Text('= NPR   ' + '${(double.parse(price.takenTime) * double.parse(price.perMinuteChargeRate)).toStringAsFixed(2)}',
                style: TextStyle(fontSize: 16), textAlign: TextAlign.center),
          ),
        ]);
  }

  static Widget buildInvoiceTotal(InvoicePrice price) {
    return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: Text("Total:",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center),
          ),
          Container(
            child: Text('NPR  ' + price.total.toString(),
                style: TextStyle(fontSize: 16), textAlign: TextAlign.center),
          ),
        ]);
  }

  static Widget buildInvoiceMinimumFare(InvoicePrice price) {
    return Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            child: Text("Minimum Fare:",
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                textAlign: TextAlign.center),
          ),
          Container(
            child: Text('= NPR ' + price.baseFare.toString(),
                style: TextStyle(fontSize: 16), textAlign: TextAlign.center),
          ),
        ]);
  }

  static Widget buildFooter(Invoice invoice) => Column(
    crossAxisAlignment: CrossAxisAlignment.center,
    children: [
      // SizedBox(height: 2 * PdfPageFormat.mm),
      // Divider(),
      // buildSimpleText(title: 'Email: ', value: invoice.company.email),
      SizedBox(height: 1 * PdfPageFormat.mm),
      //buildSimpleText(title: 'Address: ', value: invoice.company.address),
    ],
  );

  static buildSimpleText({
    String title,
    String value,
  }) {
    final style = TextStyle(fontWeight: FontWeight.bold);

    return Row(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.end,
      children: [
        Text(title, style: style),
        SizedBox(width: 2 * PdfPageFormat.mm),
        Text(value),
      ],
    );
  }
}

class Utils {
  static formatDate(DateTime date) => DateFormat.yMd().format(date);
}
