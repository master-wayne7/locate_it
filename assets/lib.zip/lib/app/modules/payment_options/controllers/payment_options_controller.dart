import 'dart:async';
import 'dart:typed_data';

import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/data/models/booking.dart';
import 'package:puryaideu/app/data/models/completed_trip.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/data/repositories/booking_repository.dart';
import 'package:puryaideu/app/data/repositories/payment_repository.dart';
import 'package:puryaideu/app/data/repositories/user_repository.dart';
import 'package:puryaideu/app/modules/payment_options/invoice/billings/information.dart';
import 'package:puryaideu/app/modules/payment_options/invoice/billings/invoice_generator.dart';
import 'package:puryaideu/app/modules/payment_options/invoice/billings/pdf_generator.dart';
import 'package:puryaideu/app/routes/app_pages.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PaymentOptionsController extends GetxController {
  CompletedTrip _completedTrip;
  String errorMessage;

  Timer paymentStatusTimer;


  CompletedTrip get completedTrip => _completedTrip;

  final selectedPaymentGatewayType = 1.obs;

  @override
  void onInit() {
    super.onInit();
  }

  @override
  void onReady() {
    super.onReady();
    listenPaymentStatus();
  }

  @override
  void onClose() {
    if (paymentStatusTimer != null) {
      paymentStatusTimer.cancel();
    }
  }

  void setCompletedTrip(completedTrip) => _completedTrip = completedTrip;

  void updateSelectedPaymentGateway(int paymentType) =>
      selectedPaymentGatewayType.value = paymentType;

  Future<bool> payOffline() async {
    final response =
        await PaymentRepository.payOffline(_completedTrip.id).catchError((error) {
      errorMessage = error;
    });

    return (response == null) ? false : true;
  }

  void listenPaymentStatus() async {
    if (paymentStatusTimer != null && paymentStatusTimer.isActive) {
      return;
    }



    paymentStatusTimer = Timer.periodic(Duration(seconds: 10), (timer) async {
      final status = await BookingRepository.getPaymentByID(_completedTrip.bookingId)
          .catchError((error) {
        errorMessage = "Payment status could not be updated. Please try again!";
      });
      print('Here');
      print('Status is === ${status.id}');

      if (status == null) {
        CustomSnackbar.showCustomSnackBar(message: errorMessage);
        return;
      }
      print('Payment id ==== ${status.id}');
      print('Status ==== ${status.paymentStatus}');
      if (status.customerPaymentStatus == 'paid') {
        if (paymentStatusTimer != null) {
          paymentStatusTimer.cancel();
        }
        SharedPreferences sharedPreferences =
        await SharedPreferences.getInstance();
        UserRepository userRepository = UserRepository(prefs: sharedPreferences);
        userRepository.setPaymentStatus('paid');
        Get.offNamed(Routes.RATINGS, arguments: [completedTrip]);
        return;
      }
    });
  }
}
