import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';
import 'package:puryaideu/app/config/custom_colors.dart';
import 'package:puryaideu/app/config/theme.dart';

class OTPTextField extends StatelessWidget {
  final TextEditingController textEditingController;
  final Function onChanged;
  final bool autofocus;
  final FocusNode focusNode;

  OTPTextField(
      {this.textEditingController,
      this.onChanged,
      this.autofocus = false,
      this.focusNode});

  @override
  Widget build(BuildContext context) {
    final length = 5;
    final borderColor = Color(0xffe5e2f5).withOpacity(0.2);
    const errorColor = Color.fromRGBO(255, 234, 238, 1);
    const fillColor = Color.fromRGBO(222, 231, 240, .57);
    final defaultPinTheme = PinTheme(
      width: 56,
      height: 60,
      textStyle: Theme.of(context).textTheme.bodyText2.copyWith(
          color: Colors.grey[700],
          letterSpacing: 1.2,
          fontWeight: FontWeight.w600,
          fontSize: getResponsiveFont(18)),
      decoration: BoxDecoration(
        color: fillColor,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: Colors.transparent),
      ),
    );

    return SizedBox(
      height: 68,
      child: Pinput(
        androidSmsAutofillMethod: AndroidSmsAutofillMethod.smsRetrieverApi,
        length: length,
        controller: textEditingController,
        focusNode: focusNode,
        autofocus: autofocus,
        defaultPinTheme: defaultPinTheme,
        onCompleted: onChanged,
        focusedPinTheme: defaultPinTheme.copyWith(
          height: 68,
          width: 64,
          decoration: defaultPinTheme.decoration.copyWith(
            border: Border.all(color: borderColor),
          ),
        ),
        errorPinTheme: defaultPinTheme.copyWith(
          decoration: BoxDecoration(
            color: errorColor,
            borderRadius: BorderRadius.circular(8),
          ),
        ),
      ),
    );
  }
}

// class OTPTextField extends StatelessWidget {
//   final TextEditingController textEditingController;
//   final Function onChanged;
//   final bool autofocus;
//   final FocusNode focusNode;
//
//   OTPTextField(
//       {this.textEditingController,
//       this.onChanged,
//       this.autofocus = false,
//       this.focusNode});
//
//   @override
//   Widget build(BuildContext context) {
//     return Container(
//       margin: EdgeInsets.symmetric(horizontal: 8),
//     decoration: BoxDecoration(
//         borderRadius: BorderRadius.circular(10),
//         border: Border.all(color: Color(0xffe5e2f5).withOpacity(0.2)),
//         boxShadow: [
//           BoxShadow(
//             offset: const Offset(3.0, 3.0),
//             blurRadius: 2,
//             color: Get.theme.primaryColor.withOpacity(0.41),
//             spreadRadius: 0.5,
//           ),
//         ]),
//       child: TextField(
//         maxLength: 1,
//         autofocus: autofocus,
//         focusNode: focusNode,
//         textAlign: TextAlign.center,
//         keyboardType: TextInputType.number,
//         onChanged: onChanged,
//         style: Theme.of(context).textTheme.bodyText2.copyWith(
//           fontSize: getResponsiveFont(18),
//           color: Colors.black,
//           letterSpacing: 2.0,
//           fontWeight: FontWeight.w600,
//         ),
//         controller: textEditingController,
//         decoration: InputDecoration(
//           counterText: '',
//           filled: true,
//           fillColor: Color(0xfff6f5fa),
//           border: UnderlineInputBorder(
//               borderSide: BorderSide(width: 2, color: Color(0xffe5e2f5))),
//           enabledBorder: UnderlineInputBorder(
//               borderSide: BorderSide(width: 2, color: Color(0xffe5e2f5))),
//           disabledBorder: UnderlineInputBorder(
//               borderSide: BorderSide(width: 2, color: Color(0xffe5e2f5))),
//           focusedBorder: UnderlineInputBorder(
//               borderSide: BorderSide(width: 2, color: Color(0xffe5e2f5))),
//         ),
//       ),
//     );
//   }
// }
