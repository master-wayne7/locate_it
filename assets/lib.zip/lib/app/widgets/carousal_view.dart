import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:shimmer/shimmer.dart';

import 'carousal.dart';

class CarousalView extends StatelessWidget {
  final List<String> imageUrlList;
  final List<String> promoCode;

  CarousalView({this.imageUrlList, this.promoCode});

  @override
  Widget build(BuildContext context) {
    return Container(
      height: Get.height * 0.25,
      child: Carousel(
        radius: Radius.circular(15),
        borderRadius: true,
        boxFit: BoxFit.cover,
        autoplay: true,
        indicatorBgPadding: 14,
        animationCurve: Curves.fastOutSlowIn,
        animationDuration: Duration(milliseconds: 1500),
        dotSize: 6.0,
        dotBgColor: Colors.transparent,
        showIndicator: true,
        images: [
          ...imageUrlList
              .map(
                (imageUrl) => CachedNetworkImage(
                  imageUrl: imageUrl,
                  progressIndicatorBuilder: (context, url, downloadProgress) =>
                      Shimmer.fromColors(
                    baseColor: Color(0xffeeeff3),
                    highlightColor: Colors.white,
                    enabled: true,
                    child: Card(
                      margin: EdgeInsets.zero,
                    ),
                  ),
                  errorWidget: (context, url, error) =>
                      Icon(Icons.error, size: 10),
                  fit: BoxFit.cover,
                ),
                // (imageUrl) => Image.asset(
                //   imageUrl,
                //   fit: BoxFit.cover,
                //   height: Get.height * 0.25,
                // ),
              )
              .toList()
        ],
        promo: promoCode,
      ),
    );
  }
}
