
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:shimmer/shimmer.dart';


class BookingShimmer extends StatelessWidget {
  const BookingShimmer({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: <Widget>[
          Expanded(
            child: Shimmer.fromColors(
              baseColor: Color(0xffeeeff3),
              highlightColor: Colors.white,
              enabled: true,
              child: ListView(
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  _buildImage(),
                  const SizedBox(height: 4),
                  _buildImage(),
                  const SizedBox(height: 4),
                  _buildImage(),
                  const SizedBox(height: 4),
                  _buildImage(),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

Widget _buildImage() {
  return Column(
    children: [
      Container(
        margin: EdgeInsets.only(top: 0),
        width: Get.width,
        height: getResponsiveFont(Get.height * 0.2),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(0),
            color: Colors.white70,
            border: Border.all(color: Colors.white70.withOpacity(0.2)),
            boxShadow: [
              BoxShadow(
                offset: const Offset(3.0, 3.0),
                blurRadius: 2.0,
                color: Colors.white70.withOpacity(0.5),
                spreadRadius: 0.8,
              ),
            ]),
      ),
    ],
  );
}