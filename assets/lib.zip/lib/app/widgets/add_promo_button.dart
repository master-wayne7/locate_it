import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/modules/booking/views/ride_type_dialog.dart';
import 'package:puryaideu/app/modules/splash/controllers/all_data_controller.dart';

import 'custom_button.dart';
import 'custom_snackbar.dart';

class AddPromoButton extends StatelessWidget {
  final TextEditingController reasonController;
  final FocusNode pickUpNode = FocusNode();

  final Function onPressed;

  AddPromoButton({this.onPressed, this.reasonController});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(),
        Padding(
          padding: const EdgeInsets.only(right: 16, bottom: 16),
          child: CircleAvatar(
            backgroundColor: Colors.white,
            child: IconButton(
                icon: Icon(Icons.card_giftcard, color: Colors.green),
                onPressed: () async =>
                    buildPromoAdder(context, reasonController, pickUpNode)),
          ),
        ),
      ],
    );
  }
}

buildPromoAdder(BuildContext context, TextEditingController promoController,
    FocusNode focusNode) async {
  final AllDataController dataController = Get.find();
  //final node = FocusScope.of(context);
  showGeneralDialog(
      barrierColor: Colors.black.withOpacity(0.5),
      transitionBuilder: (context, a1, a2, widget) {
        final curvedValue = Curves.easeInOutBack.transform(a1.value) - 1.0;
        return Transform(
          transform: Matrix4.translationValues(
              curvedValue * 1, -curvedValue * 100, 0.0),
          child: Opacity(
            opacity: a1.value,
            child: Stack(
              children: [
                Positioned(
                  bottom: 0,
                  left: 0,
                  right: 0,
                  child: Padding(
                    padding: EdgeInsets.only(
                        bottom: MediaQuery.of(context).viewInsets.bottom),
                    child: Card(
                      child: Container(
                          // height: Get.height * 0.3,
                          padding: EdgeInsets.all(16),
                          decoration: BoxDecoration(color: Colors.white),
                          child: SingleChildScrollView(
                            physics: NeverScrollableScrollPhysics(),
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.start,
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: <Widget>[
                                SizedBox(height: getResponsiveFont(4)),
                                Text(
                                  'Add Promo code:',
                                  style: Get.textTheme.bodyText2.copyWith(
                                    color: Colors.grey[800],
                                    fontWeight: FontWeight.w500,
                                    fontSize: getResponsiveFont(20),
                                  ),
                                ),
                                Center(
                                  child: SvgPicture.asset(
                                    'svg_assets/promo.svg',
                                    height: Get.height * 0.15,
                                    width: Get.width * 0.2,
                                    fit: BoxFit.contain,
                                  ),
                                ),
                                Container(
                                  // height: Get.height * 0.06,
                                  child: TextField(
                                    controller: dataController.promoController,
                                    textAlign: TextAlign.left,
                                    // autofocus: true,
                                    style: Get.textTheme.headline5.copyWith(
                                        fontFamily: 'Roboto',
                                        fontSize: getResponsiveFont(18),
                                        color: Colors.grey[800]),
                                    maxLines: 1,
                                    decoration: InputDecoration(
                                      contentPadding: EdgeInsets.fromLTRB(
                                          10.0, 10.0, 20.0, 10.0),
                                      hintStyle: Get.textTheme.headline5
                                          .copyWith(
                                              fontSize: getResponsiveFont(18),
                                              fontFamily: 'Roboto',
                                              color: Colors.grey[600]),
                                      hintText: 'Enter promo code'.tr,
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(
                                            width: 1, color: Colors.grey[600]),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(
                                            width: 1, color: Colors.grey[600]),
                                      ),
                                      focusedBorder: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                        borderSide: BorderSide(
                                            width: 1, color: Colors.grey[600]),
                                      ),
                                    ),
                                  ),
                                ),
                                SizedBox(height: getResponsiveFont(8)),
                                Row(
                                  children: [
                                    Expanded(
                                      child: Container(
                                        height: Get.height * 0.06,
                                        decoration:
                                            BoxDecoration(color: Colors.white),
                                        child: CustomButton(
                                          radius: 7,
                                          textColor: Colors.grey[800],
                                          text: 'Cancel'.tr,
                                          backgroundColor: Colors.blueGrey[50],
                                          onPressed: () async {
                                            Navigator.pop(context);
                                          },
                                        ),
                                      ),
                                    ),
                                    SizedBox(width: 16),
                                    Expanded(
                                      child: Container(
                                        height: Get.height * 0.06,
                                        decoration:
                                            BoxDecoration(color: Colors.white),
                                        child: CustomButton(
                                          radius: 7,
                                          text: 'Apply'.tr,
                                          backgroundColor:
                                              Get.theme.primaryColor,
                                          onPressed: () async {
                                            Loader.show(context);
                                            final status = await dataController
                                                .checkPromoCode(dataController
                                                    .promoController.text);
                                            print('Status is $status ');
                                            if (status) {
                                              SessionManager.instance.setVoucherCode(dataController.promoController.text);
                                              dataController.promoController.text = '';
                                              Navigator.pop(context);
                                              Loader.hide();
                                              CustomSnackbar.showCustomSnackBar(
                                                message: 'Promo code successfully added.'
                                              );
                                            }else{
                                              PromoCodeInvalid.show(context);
                                              Loader.hide();
                                              CustomSnackbar.showCustomSnackBar(
                                                  message: 'Promo code is invalid.',
                                              );
                                              Future.delayed(Duration(milliseconds: 1500)).then((_) =>  PromoCodeInvalid.hide());

                                            }
                                          },
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          )),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
      transitionDuration: Duration(milliseconds: 330),
      barrierDismissible: true,
      barrierLabel: '',
      context: context,
      pageBuilder: (context, animation1, animation2) {});
}

class InsuranceButton extends StatelessWidget {
  final Function onPressed;

  InsuranceButton({this.onPressed});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Container(),
        Padding(
          padding: const EdgeInsets.only(right: 16, bottom: 16),
          child: CircleAvatar(
            backgroundColor: Colors.white,
            child: IconButton(
                icon: Icon(Icons.verified_user_rounded, color: Colors.green),
                onPressed: () async {
                  await buildShowGeneralDialog(context);
                }),
          ),
        ),
      ],
    );
  }
}

class Loader extends StatelessWidget {
  static OverlayEntry currentLoader;
  static void show(BuildContext context) {
    currentLoader = new OverlayEntry(
        builder: (context) => Stack(
          children: <Widget>[
            Container(
              color: Color(0x99ffffff),
            ),
            Center(
              child: Loader(),
            ),
          ],
        ));
    Overlay.of(context).insert(currentLoader);
  }
  static void hide() {
    currentLoader?.remove();
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      height: Get.height * 0.1,
      width: Get.width * 0.25,
      padding: EdgeInsets.all(32.0),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: Colors.grey.withOpacity(0.3)),
        color:Colors.white
      ),
      child: Center(
        child: CupertinoActivityIndicator(
          radius: 15,

        ),
      ),
    );
  }
}

class PromoCodeInvalid extends StatelessWidget {
  static OverlayEntry currentLoader;
  static void show(BuildContext context) {
    currentLoader = new OverlayEntry(
        builder: (context) => Stack(
          children: <Widget>[
            Container(
              color: Color(0x99ffffff),
            ),
            Center(
              child: PromoCodeInvalid(),
            ),
          ],
        ));
    Overlay.of(context).insert(currentLoader);
  }
  static void hide() {
    currentLoader?.remove();
  }
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(16.0),
      decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(5),
          border: Border.all(color: Colors.grey.withOpacity(0.3)),
          color:Colors.white
      ),
      child: Text(
        'Promo code is invalid.', style: Get.textTheme.bodyText2.copyWith(
        fontSize: getResponsiveFont(16),
        fontWeight: FontWeight.w500,
      )
      ),
    );
  }
}