import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/theme.dart';

class CustomTextInputField extends StatelessWidget {
  final TextEditingController textController;
  final String label;
  final FocusNode focusNode;
  final TextInputType inputType;
  final Function onSubmit;
  final bool enabled;

  CustomTextInputField(
      {this.textController,
        this.label,
        this.focusNode,
        this.inputType,
        this.enabled = true,
        this.onSubmit});

  @override
  Widget build(BuildContext context) {
    return TextField(
      style: Get.textTheme.headline5.copyWith(color: Colors.black),
      focusNode: focusNode,
      keyboardType: inputType,
      onSubmitted: onSubmit,
      enabled: enabled,
      decoration: InputDecoration(
        labelText: label,
        labelStyle: Theme.of(context).textTheme.headline6.copyWith(
          color: Theme.of(context).primaryColor,
          fontSize: getResponsiveFont(14),
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Get.theme.primaryColor),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Get.theme.primaryColor),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(10),
          borderSide: BorderSide(color: Get.theme.primaryColor),
        ),
      ),
      controller: textController,
    );
  }
}