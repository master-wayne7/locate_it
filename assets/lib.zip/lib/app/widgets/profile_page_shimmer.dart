import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:shimmer/shimmer.dart';

import 'icon_text.dart';
import 'icon_text_button.dart';

class ProfilePageShimmer extends StatelessWidget {
  const ProfilePageShimmer({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 0.0, vertical: 0.0),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        children: <Widget>[
          Expanded(
              child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
            child: ListView(
              physics: const NeverScrollableScrollPhysics(),
              children: [
                _buildImage(),
              ],
            ),
          )),
        ],
      ),
    );
  }
}

Widget _buildImage() {
  return Column(
    children: [
      SizedBox(height: getResponsiveFont(4)),
      Card(
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero, ),
        child: Container(
          margin: EdgeInsets.all(16),
          padding: EdgeInsets.symmetric(horizontal: 0),
          child: Shimmer.fromColors(
            baseColor: Color(0xffeeeff3),
            highlightColor: Colors.white,
            enabled: true,
            child: Column(
              children: [
                Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(Get.width * 0.25 / 2),
                      child: Container(
                        height: Get.width * 0.25,
                        width: Get.width * 0.25,
                        color: Colors.red,
                      ),
                    ),
                    SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 150,
                            height: 15,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                            ),
                          ),
                          SizedBox(height: 8),
                          Container(
                            width: 50,
                            height: 15,
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                            ),
                          ),
                        ],
                      ),
                    ),
                    SizedBox(width: 16),
                    Align(
                      alignment: Alignment.topLeft,
                      child: IconButton(
                        onPressed: null,
                        icon: Icon(
                          Icons.edit,
                          color: Get.theme.primaryColor,
                        ),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 14),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.phone,
                      color: Get.theme.primaryColor,
                    ),
                    SizedBox(width: 14),
                    Container(
                      width: 100,
                      height: 14,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                  ],
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.mail_outline,
                      color: Get.theme.primaryColor,
                    ),
                    SizedBox(width: 14),
                    Container(
                      width: 100,
                      height: 14,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                  ],
                ),
                SizedBox(height: 8),
              ],
            ),
          ),
        ),
      ),
      Row(
        children: [
          Expanded(
            child: Card(
              margin: EdgeInsets.symmetric(vertical: 1),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
              child: Container(
                padding: EdgeInsets.all(16),
                child: Shimmer.fromColors(
                  baseColor: Color(0xffeeeff3),
                  highlightColor: Colors.white,
                  enabled: true,
                  child: Column(
                    children: [
                      Container(
                        width: 100,
                        height: 12,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                      SizedBox(height: 8),
                      Container(
                        width: 100,
                        height: 12,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          SizedBox(width: 1),
          Expanded(
            child: Card(
              margin: EdgeInsets.symmetric(vertical: 1),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
              child: Container(
                padding: EdgeInsets.all(16),
                child: Shimmer.fromColors(
                  baseColor: Color(0xffeeeff3),
                  highlightColor: Colors.white,
                  enabled: true,
                  child: Column(
                    children: [
                      Container(
                        width: 100,
                        height: 12,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                      SizedBox(height: 8),
                      Container(
                        width: 100,
                        height: 12,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
      Card(
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
        child: Shimmer.fromColors(
          baseColor: Color(0xffeeeff3),
          highlightColor: Colors.white,
          enabled: true,
          child: Column(
            children: [
              Container(
                padding: EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.payment,
                      color: Get.theme.primaryColor,
                    ),
                    SizedBox(width: 14),
                    Container(
                      width: 100,
                      height: 14,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.money_outlined,
                      color: Get.theme.primaryColor,
                    ),
                    SizedBox(width: 14),
                    Container(
                      width: 100,
                      height: 14,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.settings,
                      color: Get.theme.primaryColor,
                    ),
                    SizedBox(width: 14),
                    Container(
                      width: 100,
                      height: 14,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                  ],
                ),
              ),

              Container(
                padding: EdgeInsets.all(16),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.info_outline,
                      color: Get.theme.primaryColor,
                    ),
                    SizedBox(width: 14),
                    Container(
                      width: 100,
                      height: 14,
                      decoration: BoxDecoration(
                        color: Colors.white,
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
      SizedBox(height: 1),
      Card(
          margin: EdgeInsets.zero,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.zero),
          child: Shimmer.fromColors(
            baseColor: Color(0xffeeeff3),
            highlightColor: Colors.white,
            enabled: true,
            child: Container(
                padding: EdgeInsets.all(16),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.logout,
                        color: Get.theme.primaryColor,
                      ),
                      SizedBox(width: 14),
                      Container(
                        width: 100,
                        height: 14,
                        decoration: BoxDecoration(
                          color: Colors.white,
                          borderRadius: BorderRadius.circular(16),
                        ),
                      )
                    ])),
          )),
    ],
  );
}
