
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/theme.dart';
import 'package:shimmer/shimmer.dart';


class TripDetailShimmer extends StatelessWidget {
  const TripDetailShimmer({Key key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      child: Column(
        children: [
          Expanded(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Container(
                    width: Get.width,
                    padding: EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                    ),
                    child: Shimmer.fromColors(
                      baseColor: Color(0xffeeeff3),
                      highlightColor: Colors.white,
                      enabled: true,
                      child: Row(
                        children: [
                          Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                                Container(
                                  width: 60,
                                  height: 14,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                ),
                                SizedBox(height: getResponsiveFont(10)),
                                Container(
                                  width: 100,
                                  height: 22,
                                  decoration: BoxDecoration(
                                    color: Colors.white,
                                    borderRadius: BorderRadius.circular(16),
                                  ),
                                )
                              ],

                          ),
                          Expanded(
                            child: SizedBox(),
                          ),
                          IconButton(
                              icon: Icon(Icons.copy),
                              onPressed: () {

                              }),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: Get.height * (getResponsiveFont(0.01)),
                  ),
                  Container(
                    color: Colors.white,
                    padding: EdgeInsets.only(
                        left: 16, right: 16, top: 16, bottom: 16),
                    child: Shimmer.fromColors(
                      baseColor: Color(0xffeeeff3),
                      highlightColor: Colors.white,
                      enabled: true,
                      child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment:
                          MainAxisAlignment.spaceEvenly,
                          children: [
                            Container(
                              width: 100,
                              height: getResponsiveFont(20),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16),
                              ),
                            ),
                            Expanded(
                                child: SizedBox(
                                  width: getResponsiveFont(Get.width * 0.5),
                                )),
                            Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(15),
                                color: Colors.transparent,
                              ),
                              child: Image.asset("assets/city_safari.png",
                                height: 30,
                                width: 30,
                              ),
                            ),
                          ]),
                    ),
                  ),
                  Container(
                    color: Colors.white,
                    padding: EdgeInsets.only(
                        left: 16, right: 16, top: 4, bottom: 16),
                    child: Shimmer.fromColors(
                      baseColor: Color(0xffeeeff3),
                      highlightColor: Colors.white,
                      enabled: true,
                      child: Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment:
                          MainAxisAlignment.spaceEvenly,
                          children: [
                            Container(
                              width: 150,
                              height: getResponsiveFont(16),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16),
                              ),
                            ),
                            Expanded(
                                child: SizedBox(
                                  width: getResponsiveFont(Get.width * 0.5),
                                )),
                            Container(
                              width: 75,
                              height: getResponsiveFont(16),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16),
                              ),
                            ),
                          ]),
                    ),
                  ),
                  Container(
                    color: Colors.white,
                    padding: EdgeInsets.only(
                        left: 16, right: 16, top: 4, bottom: 16),
                    child: Shimmer.fromColors(
                      baseColor: Color(0xffeeeff3),
                      highlightColor: Colors.white,
                      enabled: true,
                      child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          mainAxisAlignment:
                          MainAxisAlignment.spaceEvenly,
                          children: [
                            Row(
                              children: [
                                Icon(Icons.my_location),
                                SizedBox(width: getResponsiveFont(16)),
                                Column(
                                  children: [
                                    Container(
                                      width: getResponsiveFont(Get.width * 0.8),
                                      height: getResponsiveFont(16),
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(16),
                                      ),
                                    ),
                                    SizedBox(height:8),
                                    Container(
                                      width: getResponsiveFont(Get.width * 0.8),
                                      height: getResponsiveFont(16),
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(16),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                            SizedBox(height: getResponsiveFont(16)),
                            Row(
                              children: [
                                Icon(Icons.location_pin,
                                    color: Get.theme.primaryColor),
                                SizedBox(width: getResponsiveFont(16)),
                                Column(
                                  children: [
                                    Container(
                                      width: getResponsiveFont(Get.width * 0.8),
                                      height: getResponsiveFont(16),
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(16),
                                      ),
                                    ),
                                    SizedBox(height:8),
                                    Container(
                                      width: getResponsiveFont(Get.width * 0.8),
                                      height: getResponsiveFont(16),
                                      decoration: BoxDecoration(
                                        color: Colors.white,
                                        borderRadius: BorderRadius.circular(16),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ]),
                    ),
                  ),
                  SizedBox(
                    height: Get.height * (getResponsiveFont(0.01)),
                  ),
                  Container(
                    color: Colors.white,
                    padding: EdgeInsets.only(
                        left: 16, right: 16, top: 16, bottom: 16),
                    child: Shimmer.fromColors(
                      baseColor: Color(0xffeeeff3),
                      highlightColor: Colors.white,
                      enabled: true,
                      child: Row(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: Container(
                              color: Colors.red,
                              height:
                              Get.width * getResponsiveFont(0.12),
                              width:
                              Get.width * getResponsiveFont(0.12),
                            ),
                          ),
                          SizedBox(width: 16),
                          Expanded(
                            child: Column(
                              crossAxisAlignment:
                              CrossAxisAlignment.start,
                              children: [
                              Container(
                              width: 100,
                              height: getResponsiveFont(16),
                              decoration: BoxDecoration(
                                color: Colors.white,
                                borderRadius: BorderRadius.circular(16),
                              ),
                            ),
                              ],
                            ),
                          ),
                          IgnorePointer(
                            child: RatingBar(
                                initialRating: 5,
                                glow: false,
                                direction: Axis.horizontal,
                                allowHalfRating: true,
                                tapOnlyMode: false,
                                updateOnDrag: false,
                                itemCount: 5,
                                itemSize: getResponsiveFont(16.0),
                                ratingWidget: RatingWidget(
                                    full: Icon(Icons.star,
                                        color: Color(0xffFFD700)),
                                    half: Icon(
                                      Icons.star_half,
                                      color: Color(0xffFFD700),
                                    ),
                                    empty: Icon(Icons.star_outline,
                                        color: Color(0xffFFD700))),
                                onRatingUpdate: (value) {}),
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(
                    height: Get.height * (getResponsiveFont(0.01)),
                  ),
                  Container(
                    color: Colors.white,
                    padding: EdgeInsets.only(
                        left: 16, right: 16, top: 16, bottom: 16),
                    child: Shimmer.fromColors(
                      baseColor: Color(0xffeeeff3),
                      highlightColor: Colors.white,
                      enabled: true,
                      child: Row(
                        children: [
                          Container(
                            width: 170,
                            height: getResponsiveFont(24),
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(16),
                            ),
                          ),
                          Expanded(child: SizedBox(width: 16)),
                        ],
                      ),
                    ),
                  ),
                  Container(
                    color: Colors.white,
                    padding: EdgeInsets.only(
                        left: 16, right: 16, bottom: 16),
                    child: Shimmer.fromColors(
                      baseColor: Color(0xffeeeff3),
                      highlightColor: Colors.white,
                      enabled: true,
                      child: Column(
                        children: [
                          Row(
                            children: [
                              Container(
                                width: 100,
                                height: getResponsiveFont(16),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                              Expanded(child: SizedBox()),
                              Container(
                                width: 75,
                                height: getResponsiveFont(16),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                            ],
                          ),
                          Divider(),
                          Row(
                            children: [
                              Container(
                                width: 140,
                                height: getResponsiveFont(16),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                              Expanded(child: SizedBox()),
                              Container(
                                width: 75,
                                height: getResponsiveFont(16),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                            ],
                          ),
                          Divider(),
                          Row(
                            children: [
                              Container(
                                width: 130,
                                height: getResponsiveFont(16),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                              Expanded(child: SizedBox()),
                              Container(
                                width: 50,
                                height: getResponsiveFont(16),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                            ],
                          ),
                          Divider(),
                          Row(
                            children: [
                              Container(
                                width: 75,
                                height: getResponsiveFont(17),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                              Expanded(child: SizedBox()),
                              Container(
                                width: 75,
                                height: getResponsiveFont(17),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                            ],
                          ),
                          Divider(),
                          Row(
                            children: [
                              Container(
                                width: 100,
                                height: getResponsiveFont(19),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                              Expanded(child: SizedBox()),
                              Container(
                                width: 50,
                                height: getResponsiveFont(19),
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Container(
            width: Get.width,
            height: Get.height * (getResponsiveFont(0.07)),
            child: Shimmer.fromColors(
              baseColor: Get.theme.primaryColor,
              highlightColor: Colors.white,
              enabled: true,
              child: MaterialButton(
                color: Get.theme.primaryColor,
                child: new Text('Request Again',
                    style: new TextStyle(
                        fontSize: getResponsiveFont(18),
                        color: Colors.white,
                        fontWeight: FontWeight.w600)),
                onPressed: () {},
              ),
            ),
          ),
        ],
      )
    );
  }
}

Widget _buildImage() {
  return Column(
    children: [
      Container(
        margin: EdgeInsets.only(top: 0),
        width: Get.width,
        height: getResponsiveFont(Get.height * 0.15),
        decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(0),
            color: Colors.white70,
            border: Border.all(color: Colors.white70.withOpacity(0.2)),
            boxShadow: [
              BoxShadow(
                offset: const Offset(3.0, 3.0),
                blurRadius: 2.0,
                color: Colors.white70.withOpacity(0.5),
                spreadRadius: 0.8,
              ),
            ]),
      ),
    ],
  );
}