import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/theme.dart';

class LocationText extends StatelessWidget {

  final String text;

  LocationText({this.text});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4,
      shape:
          RoundedRectangleBorder(borderRadius: BorderRadius.circular(30)),
      child: Container(
        padding: EdgeInsets.symmetric(horizontal: 8, vertical: 8),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          color: Colors.white,
        ),
        child: Text(
          text,
          textAlign: TextAlign.center,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: Get.textTheme.bodyText2.copyWith(fontSize: getResponsiveFont(12)),
        ),
      ),
    );
  }
}