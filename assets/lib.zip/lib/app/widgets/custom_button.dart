import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:puryaideu/app/config/theme.dart';

class CustomButton extends StatelessWidget {
  final Function onPressed;
  final String text;
  final Color textColor;
  final Color backgroundColor;
  final double radius;

  CustomButton({
    @required this.onPressed,
    @required this.text,
    this.radius = 0.0,
    this.textColor = Colors.white,
    // this.backgroundColor = const Color(0xffEB2027)}
    this.backgroundColor,
  });

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        color: backgroundColor != null ? backgroundColor : Colors.black87,
        borderRadius: BorderRadius.circular(radius),
        // gradient: LinearGradient(
        //     colors: [Get.theme.accentColor, Get.theme.primaryColor],
        //     begin: Alignment.centerLeft,
        //     end: Alignment.centerRight),
        // gradient: LinearGradient(colors: [Color(0xff374ABE), Color(0xff64B6FF)]),
      ),
      child: ElevatedButton(
        onPressed: onPressed,
        style: ButtonStyle(
          shape: MaterialStateProperty.all<OutlinedBorder>(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(radius),
              // side: BorderSide(color: Get.theme.primaryColor, width: 2),`
            ),
          ),
          backgroundColor: MaterialStateProperty.all<Color>(backgroundColor != null? backgroundColor: Colors.transparent),
          padding:
              MaterialStateProperty.all<EdgeInsetsGeometry>(EdgeInsets.all(16)),
        ),
        child: Text(
          text,
          style: Theme.of(context)
              .textTheme
              .headline5
              .copyWith(fontSize: getResponsiveFont(14), color: textColor),
        ),
      ),
    );
  }
}
