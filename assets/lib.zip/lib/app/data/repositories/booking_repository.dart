import 'dart:convert';

import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/data/models/booking.dart';
import 'package:puryaideu/app/data/models/completed_trip.dart' as ct;
import 'package:puryaideu/app/data/models/estimated_price.dart';
import 'package:puryaideu/app/data/network/constant_headers.dart';
import 'package:puryaideu/app/data/network/network_helper.dart';
import 'package:puryaideu/app/enums/header_type.dart';
import 'package:puryaideu/app/modules/booking/model/booking_request_model.dart';
import 'package:puryaideu/app/widgets/custom_snackbar.dart';

import 'SessionManager.dart';

class BookingRepository {
  static Future<List<EstimatedPrice>> getEstimatedPrice(
      LatLng pickupLocation, String distance, String duration) async {
    String url = '$BASE_URL/api/booking/estimated_price';
    final body = jsonEncode({
      "origin_latitude":
          double.parse((pickupLocation.latitude).toStringAsFixed(10)),
      "origin_longitude":
          double.parse((pickupLocation.longitude).toStringAsFixed(10)),
      "distance": distance,
      "duration": duration,
      "voucher": SessionManager.instance.voucherCode == null ? null : SessionManager.instance.voucherCode
    });
    print(body);
    final response = await NetworkHelper().postRequest(url,
        data: body,
        contentType:
            ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
    final data = response.data;
    print(response);
    // print('data is===== $data');
    // print();
    if (response.statusCode == 200) {
      print('HEHEHEHEHEH');
      List<EstimatedPrice> estimatedPrices = (data['estimated_price'] as List)
          .map((i) => EstimatedPrice.fromJson(i))
          .toList();

      print(estimatedPrices);
      return estimatedPrices;
    } else {
      return Future.error(data['message']);
    }
  }

  static Future<Booking> bookRide(BookingRequestModel bookingResponse) async {
    String url = '$BASE_URL/api/booking/create';
    print('data request==== ${bookingResponse.toJson()}');
    final response = await NetworkHelper().postRequest(url,
        data: bookingResponse.toJson(),
        contentType:
            ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
    print("Response: ${response}");
    final data = response.data["booking"];
    print(response.statusCode);
    if (response.statusCode == 201) {
      Booking booking = Booking.fromJson(data);
      return booking;
    } else if (response.statusCode == 400) {
      print('hehe');
      return Future.error("You already have booking.");
    } else {
      return Future.error(data['message']);
    }
  }

  static Future<bool> cancelBooking(int id) async {
    final url = '$BASE_URL/api/booking/change_status';

    print(id);
    final body = jsonEncode({
      'booking_id': id,
      'new_status': 'cancelled',
    });
    print(body);

    final response = await NetworkHelper().postRequest(url,
        data: body,
        contentType:
            ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
    final data = response.data;
    print('data is=== ${data}');
    print('response code is=== ${response.statusCode}');
    print('response message === ${response.statusMessage}');
    if (response.statusCode == 201) {
      return true;
    } else {
      return Future.error(data['message']);
    }
  }



  static Future<Booking> getBookingById(int bookingId) async {
    String url = '$BASE_URL/api/booking/${bookingId}';
    print('url is=== $url');
    final response = await NetworkHelper().getRequest(url,
        contentType:
            ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
    final data = response.data;
    print('response code=== ${response.statusCode}');
    print('response status=== ${response.statusMessage}');
    if (response.statusCode == 200) {
      print('Did not parse');
      Booking booking = Booking.fromJson(data['booking']);
      print('Parsed');
      print('Booking is $booking');
      return booking;
    } else if (response.statusCode == 404) {
      return Future.error('The requested booking could not be found.');
    } else {
      return Future.error(data['message']);
    }
  }

  static Future<dynamic> getPaymentByID(int bookingId) async {
    String url = '$BASE_URL/api/booking/${bookingId}/payment';
    print('url is=== $url');
    print('Payment id is $bookingId');
    final response = await NetworkHelper().getRequest(url,
        contentType:
        ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
    final data = response.data;
    print('response code=== ${response.statusCode}');
    print('response status=== ${data}');
    if (response.statusCode == 200) {
      Payment payment = Payment.fromJson(data['payment']);
      return payment;
    } else if (response.statusCode == 404) {
      return Future.error('The requested booking could not be found.');
    } else {
      return Future.error(data['message']);
    }
  }

  static Future<ct.CompletedTrip> getCompletedTripByID(int completedTripId) async {
    String url = '$BASE_URL/api/completed_trip/${completedTripId}';
    print('url is=== $url');
    final response = await NetworkHelper().getRequest(url,
        contentType:
        ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
    final data = response.data;
    print('response code=== ${response.statusCode}');
    print('completed trip response status=== ${data}');
    if (response.statusCode == 200) {
      ct.CompletedTrip completedTrip = ct.CompletedTrip.fromJson(data['completed_trip']);
      SessionManager.instance.setCompletedBooking(completedTrip);
      print("Completed Trip is == $completedTrip");
      return completedTrip;
    } else if (response.statusCode == 404) {
      return Future.error('The requested booking could not be found.');
    } else {
      return Future.error(data['message']);
    }
  }


  static Future<Booking> getActiveBooking() async {
    String url = '$BASE_URL/api/user/booking/active';
    final response = await NetworkHelper().getRequest(url,
        contentType:
            ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
    final data = response.data;
    print('active booking=== $data');
    // print(data);
    // print(response.statusMessage);
    // print('response code === ${response.statusCode}');
    if (response.statusCode == 200) {
      final booking = Booking.fromJson(data['booking']);
      return booking;
    } else if (response.statusCode == 404) {
      return Booking(id: -1);
    } else {
      return Future.error(data['message']);
    }
  }

  static Future<bool> notifyAdmin(int id) async {
    final url = '$BASE_URL/api/booking/$id/timed_out';
    print('id  of booking is=== $id');
    try {
      final response = await NetworkHelper().getRequest(url,
          contentType:
          ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
      print('response from admin is=== $response');
      final data = response.data;
      if (response.statusCode == 200) {
        return true;
      } else {
        return Future.error(response.statusMessage);
      }
    } catch (e) {
      print('error ==== $e');
      return Future.error(e.toString());
    }
  }
}


