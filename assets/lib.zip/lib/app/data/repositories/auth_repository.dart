import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/data/network/constant_headers.dart';
import 'package:puryaideu/app/data/network/network_helper.dart';
import 'package:puryaideu/app/data/repositories/user_repository.dart';
import 'package:puryaideu/app/enums/header_type.dart';
import 'package:puryaideu/app/modules/signup/models/register_request_model_model.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'SessionManager.dart';

class AuthRepository {
  static Future<bool> callRegisterApi(RegisterRequestModel user) async {
    String url = '/api/user/register';
    final body = FormData.fromMap(user.toJson());
    print('user json==== ${user.toJson()}');
    final response = await NetworkHelper().postRequest(url,
        contentType: ConstantHeaders.fetchHeaders(HeaderType.MULTIPART),
        data: body);
    print('body is=== $body');
    final data = response.data;
    // print(data);
    // print(response.statusCode);
    if (response.statusCode == 201) {
      print('data is=== $data');
      String parsedData = data['access_token'];
      SessionManager.instance.setAccessToken(parsedData);
      return true;
    } else if(response.statusCode == 401) {
      return Future.error(data['message']);
    }
    else if (response.statusCode == 422) {
      return Future.error(data['message']);
    } else {
      final errorMessage = data['message'];
      return Future.error(errorMessage.toString());
    }
  }

  static Future<int> checkUserExist(String authType, socialId) async {
    final url = '$BASE_URL/api/social/login';
    final body = jsonEncode({
      "social_id": socialId,
      "social_type": authType,
      "login_type": "customer"
    });

    final response = await NetworkHelper().postRequest(url, data: body);
    final data = response.data;
    print('check data=== $data');
    if(response.statusCode == 404) {
      return 0;
    } else if(response.statusCode == 200) {
      SessionManager.instance.setAccessToken(data['access_token']);
      return 1;
    } else {
      return Future.error(data['message'].toString());
    }
  }

  static Future<bool> saveGoogleId(String userId) async{
    final url = '$BASE_URL/api/user/profile/update';
    final body = jsonEncode({
      "google_id": userId
    });
    print('body is=== $body');
    final response = await NetworkHelper().postRequest(url, data: body, contentType: ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
    final data = response.data;
    print('google response data is=== $data');
    if(response.statusCode == 201) {
      return true;
    } else {
      return Future.error(data['message']);
    }

  }

  static Future<bool> saveFacebookId(String userId) async{
    final url = '$BASE_URL/api/user/profile/update';
    final body = jsonEncode({
      "facebook_id": userId
    });
    print('body is=== $body');
    final response = await NetworkHelper().postRequest(url, data: body, contentType: ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
    final data = response.data;
    print('google response data is=== $data');
    if(response.statusCode == 201) {
      return true;
    } else {
      return Future.error(data['message']);
    }

  }
}
