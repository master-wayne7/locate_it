import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:puryaideu/app/data/models/booking.dart';
import 'package:shared_preferences/shared_preferences.dart';

class UserRepository {
  SharedPreferences prefs;

  UserRepository({this.prefs});

  static const String _IS_LOGGED_IN = "is_logged_in";
  static const String _ACCESS_TOKEN = "accessToken";
  static const String _BIOMETRIC_TOKEN = "biometricToken";
  static const String _BIOMETRIC_LOGIN = "biometric_login";
  static const String _LATITUDE = "latitude";
  static const String _LONGITUDE = "longitude";
  static const String _PHONE = "phone";
  static const String _LANGUAGE = 'language';
  static const String _APP_LAUNCHED_PREVIOUSLY = "is_app_launched_previously";
  static const String _BOOKING_ID = "booking_id";
  static const String _PAYMENT_ID = "payment_id";
  static const String _COMPLETED_TRIP_ID = "completed_trip_id";
  static const String _RIDER_ID = "rider_id";
  static const String _PAYMENT_STATUS = "paid";
  static const String _CITY_NAME = "kathmandu";
  static const String _CITY_SAFARI_STATUS = "false";
  static const String _SOS_REQUEST = "no";



  appLaunched() async {
    await prefs.setBool(_APP_LAUNCHED_PREVIOUSLY, false);
  }

  Future<void> setCitySafariStatus(bool status) async {
    await prefs.setBool(_CITY_SAFARI_STATUS, status);
  }

  Future<bool> isCitySafariRegion() async {
    return prefs.containsKey(_CITY_SAFARI_STATUS);
  }


  Future<void> login(String accessToken) async {
    await prefs.setBool(_IS_LOGGED_IN, true);
    await prefs.setString(_ACCESS_TOKEN, accessToken);
  }

  Future<void> setCityName(String cityName) async{
    await prefs.setString(_CITY_NAME, cityName);
  }

  Future<void> setSosId(String sosId) async{
    await prefs.setString(_SOS_REQUEST, sosId);
  }

  Future<String> getSosId() async {
    return prefs.getString(_SOS_REQUEST);
  }

  Future<String> getCityName() async {
    return prefs.getString(_CITY_NAME);
  }

  Future<void> setBookingId(String id) async {
    await prefs.setString(_BOOKING_ID, id);
  }

  Future<void> setPaymentId(String id) async {
    await prefs.setString(_PAYMENT_ID, id);
  }

  Future<void> setPaymentStatus(String status) async {
    await prefs.setString(_PAYMENT_STATUS, status);
  }

  Future<String> getPaymentStatus() async {
    return prefs.getString(_PAYMENT_STATUS);
  }

  Future<void> setCompletedTripId(String id) async {
    await prefs.setString(_COMPLETED_TRIP_ID, id);
  }

  Future<void> setRiderId(String id) async {
    await prefs.setString(_RIDER_ID, id);
  }

  Future<String> getCompletedTripId() async {
    return prefs.getString(_COMPLETED_TRIP_ID);
  }

  Future<String> getRiderId() async {
    return prefs.getString(_RIDER_ID);
  }

  Future<String> getPaymentId() async {
    return prefs.getString(_PAYMENT_ID);
  }



  Future<void> saveLanguageIndex(int index) async {
    await prefs.setInt(_LANGUAGE, index);
  }

  Future<void> saveBiometricLogin(String accessToken) async {
    await prefs.setBool(_BIOMETRIC_LOGIN, true);
    await prefs.setString(_BIOMETRIC_TOKEN, accessToken);
  }

  savePhone(String phone) async {
    print('Phone value is==== $phone');
    await prefs.setString(_PHONE, phone);
  }

  saveLatLng(LatLng latLng) async {
    await prefs.setDouble(_LATITUDE, latLng.latitude);
    await prefs.setDouble(_LONGITUDE, latLng.longitude);
  }

  Future<bool> isLoggedIn() async {
    return prefs.containsKey(_IS_LOGGED_IN);
  }

  Future<bool> isBiometricEnabled() async {
    return prefs.containsKey(_BIOMETRIC_LOGIN);
  }

  Future<bool> isAppLaunchedPreviously() async {
    return prefs.containsKey(_APP_LAUNCHED_PREVIOUSLY);
  }

  Future<bool> isLocationSaved() async {
    return prefs.containsKey(_LATITUDE);
  }

  Future<String> getAccessToken() async {
    return prefs.getString(_ACCESS_TOKEN);
  }

  Future<String> getBookingId() async {
    return prefs.getString(_BOOKING_ID);
  }

  Future<int> getLanguageIndex() async {
    return prefs.getInt(_LANGUAGE);
  }

  Future<String> getBiometricToken() async {
    return prefs.getString(_BIOMETRIC_TOKEN);
  }

  Future<String> getPhone() async {
    return prefs.getString(_PHONE);
  }

  Future<LatLng> getlatLong() async {
    double lat = prefs.getDouble(_LATITUDE);
    double long = prefs.getDouble(_LONGITUDE);
    return LatLng(lat, long);
  }

  Future logout() async {
    bool status = false;
    await prefs.remove(_IS_LOGGED_IN).then((value) {
      if (value) {
        status = true;
        print('Login in removed===');
      } else {
        print('Login remove problem===');
      }
    });
    await prefs.remove(_ACCESS_TOKEN).then((value) {
      if (value) {
        status = true;
        print('Access token removde===');
      } else {
        print('Access token problem===');
      }
    });
    await prefs.remove(_LATITUDE).then((value) {
      if (value) {
        status = true;
        print('latitude removed===');
      } else {
        print('Latitude problem===');
      }
    });
    await prefs.remove(_LONGITUDE).then((value) {
      if (value) {
        status = true;
        print('Longitude removed===');
      } else {
        print('Longitude problem===');
      }
    });
    return status;
  }
}
