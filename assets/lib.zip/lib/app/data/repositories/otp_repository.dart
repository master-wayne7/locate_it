import 'dart:convert';

import 'package:puryaideu/app/data/network/network_helper.dart';

import 'SessionManager.dart';

class OtpRepository {
  static Future<bool> callServerForOtp(String number) async {
    String url = '/api/sms/send';
    String body = json.encode({'phone': number});
    final response = await NetworkHelper().postRequest(url, data: body);
    final data = response.data;
    if (response.statusCode == 200) {
      return true;
    } else if (response.statusCode == 400) {
      return Future.error(
          'The entered number is invalid. Please check the number and try again.');
    } else if (response.statusCode == 422) {
      return Future.error('This number cannot be validated.');
    } else {
      final errorMessage = data['message'];
      return Future.error(errorMessage.toString());
    }
  }

  static Future<bool> verifyOtp(phone, String code) async {
    String url = '/api/sms/verify_user';
    String body = json.encode({'phone': phone, 'code': code});
    final response = await NetworkHelper().postRequest(url, data: body);
    final data = response.data;
    print('data is== $data');
    if(response.statusCode == 200) {
      String token = data['access_token'];
      SessionManager.instance.setAccessToken(token);
      return true;
    } else if(response.statusCode == 401) {
      SessionManager.instance.setPhone(phone);
      return true;
    } else if(response.statusCode == 404) {
      return Future.error('You entered wrong otp.');
    } else {
      final errorMessage = data['message'];
      return Future.error(errorMessage.toString());
    }
  }
}
