import 'dart:convert';

import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/data/network/constant_headers.dart';
import 'package:puryaideu/app/data/network/network_helper.dart';
import 'package:puryaideu/app/enums/header_type.dart';

import 'SessionManager.dart';

class PaymentRepository {
  static Future<bool> payOffline(int id) async {
    final url = '$ALTERNATIVE_URL/bookings/$id';
    final body = jsonEncode({'payment_mode': 'offline'});
    final response = await NetworkHelper().patchRequest(url,
        data: body,
        contentType:
            ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
    final data = response.data;
    if (response.statusCode == 200) {
      return true;
    } else {
      return Future.error(data['message']);
    }
  }
}
