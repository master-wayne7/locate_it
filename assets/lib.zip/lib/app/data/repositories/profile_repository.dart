import 'dart:convert';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/data/models/emergency_contacts.dart';
import 'package:puryaideu/app/data/models/user.dart';
import 'package:puryaideu/app/data/network/constant_headers.dart';
import 'package:puryaideu/app/data/network/network_helper.dart';
import 'package:puryaideu/app/enums/header_type.dart';
import 'package:dio/dio.dart' as dio;
import 'package:puryaideu/app/modules/profile_edit/model/profile_update_request.dart';

import 'SessionManager.dart';

class ProfileRepository {

  static Future<String> getTotalDistanceTravelled() async {
    String url = '/api/customer/total_distance';

    final response = await NetworkHelper().getRequest(url,
        contentType:
        ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
    final data = response.data;
    //print('data is=== $data');
    if (response.statusCode == 200) {
      //print("Status is");
      final total_distance = data['total_distance'];
      double distance_in_km = double.parse(total_distance.toString())/1000;
      //print("Total distance travelled is === ${distance_in_km}");
      return distance_in_km.toString();
    } else {
      Future.error(data['message']);
    }
    return "0";
  }

  static Future<String> getTotalTripsCompleted() async {
    String url = '/api/customer/total_trips';

    final response = await NetworkHelper().getRequest(url,
        contentType:
        ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
    final data = response.data;
    //print('data is=== $data');
    if (response.statusCode == 200) {
      //print(data['total_trips']);
      final total_trips = data['total_trips'];
      return total_trips.toString();
    } else {
      Future.error(data['message']);
    }
    return "0";
  }


  static Future<User> getUserDetailFromServer() async{

    final _firebaseMessaging = FirebaseMessaging.instance;
    String deviceToken = await _firebaseMessaging.getToken();

    final headersWithToken = {
      'Content-Type': 'application/json',
      "Accept": "application/json",
      "device_token": deviceToken,
      "Authorization": "Bearer ${SessionManager.instance.accessToken}"
    };
    print('Device token: ' + deviceToken);

    String url = '/api/user/details';
    final response = await NetworkHelper().getRequest(url, contentType: headersWithToken);
    final data = response.data;
    if(response.statusCode == 200) {
      User user = User.fromJson(data['user']);
      return user;
    } else if(response.statusCode == 401) {
      return Future.error('Unauthenticated.');
    }
    else {
      return Future.error(data['message']);
    }
  }

  static Future<dynamic> getEmergencyContacts() async{


    String url = '/api/user/emergency_contacts';
    final response = await NetworkHelper().getRequest(url, contentType: ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
    final data = response.data["emergency_contacts"];
    if(response.statusCode == 200) {
      final str = response.data["emergency_contacts"].length;
      final value = response.data["emergency_contacts"];
      print(str);
      if(str>0){
        return value;
      }
      return true;

    } else if(response.statusCode == 401) {
      return Future.error('Unauthenticated.');
    }
    else {
      return Future.error(data['message']);
    }
  }

  static Future<bool> updateUserDetail(ProfileUpdateRequest user) async{

    String url = '/api/user/profile/update';
    var formData = dio.FormData.fromMap({
      "first_name": user.firstName,
      "last_name": user.lastName,
      "image": user.image == null
          ? null
          : await dio.MultipartFile.fromFile(user.image.path),
      "dob": user.dob,
      "gender": user.gender

    });

    final response = await NetworkHelper().postRequest(url, data: formData, contentType: ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
    final data = response.data;
    return (response.statusCode == 200)? true: Future.error(data['message']);
  }

  static Future<bool> sendEmergencyContacts(List<EmergencyContacts> list) async {
    final url = '/api/user/emergency_contacts/update';

    final formData = dio.FormData.fromMap({
      "emergency_contacts": [
        ...list.map(
              (contact) {
            final jsonData = {
              "name" : contact.name,
              "contact": contact.contact
            };
            return jsonData;
          },
        ).toList()
      ]
    });

    final response = await NetworkHelper().postRequest(url, data: formData, contentType: ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));

    final data = response.data;
    return (response.statusCode == 200)? true: Future.error(data['message']);
  }
}