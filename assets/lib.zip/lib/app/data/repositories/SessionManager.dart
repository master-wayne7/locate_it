import 'dart:typed_data';

import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:puryaideu/app/data/models/booking.dart';
import 'package:puryaideu/app/data/models/completed_trip.dart' as completed_trip;
import 'package:puryaideu/app/data/models/emergency_contacts.dart';
import 'package:puryaideu/app/data/models/rider.dart';
import 'package:puryaideu/app/data/models/user.dart';

class SessionManager {
  SessionManager._privateConstructor();

  static final SessionManager _instance = SessionManager._privateConstructor();

  static SessionManager get instance => _instance;

  String _accessToken;
  String _phone;
  bool _rebooked;
  User _user;
  Rider _rider;
  Rider _historyRider;
  LatLng _currentLocation;
  Uint8List _bikeIcon;
  Uint8List _carIcon;
  Uint8List _citySafariIcon;
  Uint8List _foodIcon;
  Uint8List _ambulanceIcon;
  Uint8List _medicalIcon;
  Uint8List _pickupIcon;
  Uint8List _destinationIcon;
  bool _citySafariArea;
  List<EmergencyContacts> _contactList;
  completed_trip.CompletedTrip _completedTrip;
  String _voucherCode;

  Booking _booking;

  String _paymentId;
  String _unpaidBookingId;
  LatLng _homeLocation;
  String _home;
  LatLng _workLocation;
  String _work;

  Booking get booking => _booking;

  bool get rebooked => _rebooked;

  bool get citySafariArea => _citySafariArea;

  String get paymentId => _paymentId;

  String get unpaidBookingId => _unpaidBookingId;

  String get accessToken => _accessToken;

  String get phone => _phone;

  String get voucherCode => _voucherCode;

  User get user => _user;

  LatLng get currentLocation => _currentLocation;

  Uint8List get pickupIcon => _pickupIcon;

  Rider get rider => _rider;

  Rider get historyRider => _historyRider;

  Uint8List get destinationIcon => _destinationIcon;

  Uint8List get bikeIcon => _bikeIcon;

  Uint8List get carIcon => _carIcon;

  Uint8List get citySafariIcon => _citySafariIcon;

  Uint8List get foodIcon => _foodIcon;

  Uint8List get ambulanceIcon => _ambulanceIcon;

  Uint8List get medicalIcon => _medicalIcon;

  LatLng get homeLocation => _homeLocation;

  LatLng get workLocation => _workLocation;

  String get home => _home;

  String get work => _work;

  List<EmergencyContacts> get  contactList =>_contactList;

  completed_trip.CompletedTrip get completedTrip => _completedTrip;

  void setAccessToken(String accessToken) => _accessToken = accessToken;

  void setPhone(String phone) => _phone = phone;

  void setRebooked(bool rebooked) => _rebooked = rebooked;

  void setUser(User user) => _user = user;

  void setCitySafariArea(bool citySafariArea) =>
      _citySafariArea = citySafariArea;

  void setVoucherCode(String voucherCode) => _voucherCode = voucherCode;

  void setPaymentId(String paymentId) => _paymentId = paymentId;

  void setUnpaidBookingId(String unpaidBookingId) =>
      _unpaidBookingId = unpaidBookingId;

  void setRider(Rider rider) => _rider = rider;

  void setBooking(Booking booking) => _booking = booking;

  void setCompletedBooking(completed_trip.CompletedTrip completedTrip) => _completedTrip = completedTrip;


  void setHistoryRider(Rider historyRider) => _historyRider = historyRider;

  void setCurrentLocation(LatLng currentLocation) =>
      _currentLocation = currentLocation;

  void setHomeLocation(LatLng location) => _homeLocation = location;

  void setWorkLocation(LatLng location) => _workLocation = location;

  void setHome(String name) => _home = name;

  void setWork(name) => _work = name;

  void setMapIcons(
      pickup, destination, bike, car, citySafari, food, ambulance, medical) {
    print('icon set===');
    _pickupIcon = pickup;
    _destinationIcon = destination;
    _bikeIcon = bike;
    _carIcon = car;
    _citySafariIcon = citySafari;
    _foodIcon = food;
    _ambulanceIcon = ambulance;
    _medicalIcon = medical;
  }

  void setContactList(List<EmergencyContacts> list) =>  _contactList = list;
}
