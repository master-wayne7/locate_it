import 'dart:convert';

import 'package:google_maps_flutter/google_maps_flutter.dart';
import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/data/models/available_rider.dart';
import 'package:puryaideu/app/data/models/rider.dart';
import 'package:puryaideu/app/data/network/constant_headers.dart';
import 'package:puryaideu/app/data/network/network_helper.dart';
import 'package:puryaideu/app/enums/header_type.dart';

import 'SessionManager.dart';

class RiderRepository {
  static Future<Rider> getRiderDetail(int id) async {
    print('Rider id is');
    final url = '$BASE_URL/api/rider/$id/details';
    final response = await NetworkHelper().getRequest(url,
        contentType:
            ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
    final data = response.data;
    print('data is=== $data');
    if (response.statusCode == 200) {
      final rider = Rider.fromJson(data['user']);
      SessionManager.instance.setRider(rider);
      print(
          'Rider repository ===== ${SessionManager.instance.rider.imagePath}');
      return rider;
    } else {
      return Future.error(data['message']);
    }
  }

  static Future<double> getRiderRating(int id) async {
    final url = '$BASE_URL/api/rider/$id/reviews';
    final response = await NetworkHelper().getRequest(url,
        contentType:
            ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
    final data = response.data;
    print('Rider rating data is : $data');
    if(response.statusCode == 200) {
      final riderRating = data["data"]["average_rating"];
      print('Rider rating is : $riderRating');
      return riderRating.toDouble();;
    }else{
      return 0.0;
    }
  }

  static Future<Rider> getRiderDetailForHistory(int id) async {
    final url = '$BASE_URL/api/rider/$id/details';
    final response = await NetworkHelper().getRequest(url,
        contentType:
            ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
    final data = response.data;
    print('data is=== $data');
    if (response.statusCode == 200) {
      final rider = Rider.fromJson(data['user']);
      return rider;
    } else {
      return Future.error(data['message']);
    }
  }

  static Future<LatLng> getRiderLocation(int id) async {
    final url = '$BASE_URL/api/rider/$id/location';
    final response = await NetworkHelper().getRequest(url,
        contentType:
            ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
    final data = response.data;
    print('location data=== $data');
    if (response.statusCode == 200) {
      final latitude = data['rider_location']['latitude'];
      final longitude = data['rider_location']['longitude'];
      return LatLng(latitude, longitude);
    } else {
      return Future.error(data['message'].toString());
    }
  }

  static Future<List<AvailableRider>> getAvailableRiders(
      LatLng location, int vehicleTypeId) async {
    final url = '$BASE_URL/api/riders/available';
    final body = jsonEncode({
      "origin_latitude": location.latitude,
      "origin_longitude": location.longitude,
      "vehicle_type_id": vehicleTypeId
    });

    final response = await NetworkHelper().postRequest(url,
        data: body,
        contentType:
            ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));

    final data = response.data;
    // final data = [
    //     {
    //       "id": 1,
    //       "longitude": 27.686216,
    //       "latitude": 85.303862,
    //       "rider_id": 1,
    //       "status": "active",
    //       "availability": "available",
    //       "deleted_at": null,
    //       "created_at": "2021-11-28T06:27:35.000000Z",
    //       "updated_at": "2021-12-30T13:46:08.000000Z",
    //       "status_text": "Active"
    //     },
    //   {
    //     "id": 2,
    //     "longitude": 27.686862,
    //     "latitude": 85.303980,
    //     "rider_id": 2,
    //     "status": "active",
    //     "availability": "available",
    //     "deleted_at": null,
    //     "created_at": "2021-11-28T06:27:35.000000Z",
    //     "updated_at": "2021-12-30T13:46:08.000000Z",
    //     "status_text": "Active"
    //   },
    //   {
    //     "id": 3,
    //     "longitude": 27.687945,
    //     "latitude": 85.304076,
    //     "rider_id": 3,
    //     "status": "active",
    //     "availability": "available",
    //     "deleted_at": null,
    //     "created_at": "2021-11-28T06:27:35.000000Z",
    //     "updated_at": "2021-12-30T13:46:08.000000Z",
    //     "status_text": "Active"
    //   }
    //   ];

    print('Available riders===== $data');
    if (response.statusCode == 200) {
      // final response = true;
      // if(response) {
      List<AvailableRider> availableRiders = (data['available_riders'] as List)
          .map((i) => AvailableRider.fromJson(i))
          .toList();
      // List<AvailableRider> availableRiders = (data)
      //     .map((i) => AvailableRider.fromJson(i))
      //     .toList();
      return availableRiders;
    } else {
      return Future.error('Something went wrong.');
    }
  }
}
