import 'dart:io';

import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/data/models/notifications.dart';
import 'package:puryaideu/app/data/models/promo.dart';
import 'package:puryaideu/app/enums/header_type.dart';

import 'constant_headers.dart';
import 'network_helper.dart';

class PromoRequest {
  static Future<dynamic> getPromoList() async {
    final headersWithoutToken = {
      'Content-Type': 'application/json',
      "Accept": "application/json",
    };
    String url = '$BASE_URL/api/customer/promotion_voucher/list';
    try {
      final response = await NetworkHelper().getRequest(url,
          contentType:
              ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
      if (response.statusCode == 200) {
        final data = response.data["promotion_vouchers"];
        return data;
      } else {
        return Future.error(response.statusMessage);
      }
    } catch (e) {
      return Future.error(e.toString());
    }
  }

  static Future<List<Promo>> getPromotionList(
      int currentPage) async {
    String url =
        '$BASE_URL/api/user/customer/notifications/push_promo_notification?page=$currentPage';
    try {
      final response = await NetworkHelper().getRequest(url,
          contentType:
          ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
      if (response.statusCode == 200) {
        List<Promo> notificationList =
        (response.data['notifications']['data'] as List)
            .map((i) => Promo.fromJson(i))
            .toList();
        print('Notification parse ${notificationList}');
        return notificationList;
      } else {
        return Future.error(response.statusMessage);
      }
    } on SocketException {
      return Future.error(
          'Please check your internet connection and try again.');
    } catch (e) {
      return Future.error(e.toString());
    }
  }

  static Future<List<Notifications>> getNotificationList(
      int currentPage) async {
    String url =
        '$BASE_URL/api/user/customer/notifications/push_notification?page=$currentPage';
    try {
      final response = await NetworkHelper().getRequest(url,
          contentType:
          ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
      if (response.statusCode == 200) {
        List<Notifications> notificationList =
        (response.data['notifications']['data'] as List)
            .map((i) => Notifications.fromJson(i))
            .toList();
        print('Notification parse ${notificationList}');
        return notificationList;
      } else {
        return Future.error(response.statusMessage);
      }
    } on SocketException {
      return Future.error(
          'Please check your internet connection and try again.');
    } catch (e) {
      return Future.error(e.toString());
    }
  }

  static Future<dynamic>checkPromoValidity(String promoCodeCheck) async {
    //promoCodeCheck = "%232AQCAFX1";
    String url = '$BASE_URL/api/customer/promotion_voucher/$promoCodeCheck/check';
    print('promo code is $promoCodeCheck');
    try {
      final response = await NetworkHelper().getRequest(url,
          contentType:
              ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
      print(response);
      if (response.statusCode == 200) {
        print('It is true');
        return true;
      } else if (response.statusCode == 400) {
        return Future.error('Promotion code has expired. Sorry!');
      } else if (response.statusCode == 404) {
        return Future.error(
            'Promotion code is invalid. Please check the entered code and try again!');
      }
      {
        return Future.error(
            'Internet failed to establish proper connection. Try again!');
      }
    } catch (e) {
      return Future.error(
          'Internet failed to establish proper connection. Try again!');
    }
  }
}

class PromoRequestModel {
  PromoRequestModel({
    this.id,
    this.code,
    this.name,
    this.description,
    this.worth,
    this.imagePath,
  });

  int id;
  String code;
  String name;
  String description;
  int worth;
  String imagePath;

  factory PromoRequestModel.fromJson(Map<String, dynamic> json) =>
      PromoRequestModel(
        id: json["id"],
        code: json["code"],
        name: json["name"],
        description: json["description"],
        worth: json["worth"],
        imagePath: json["image_path"],
      );

  Map<String, dynamic> toJson() => {
        "id": id,
        "code": code,
        "name": name,
        "description": description,
        "worth": worth,
        "image_path": imagePath,
      };
}
