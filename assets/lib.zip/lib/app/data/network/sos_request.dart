import 'dart:convert';

import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/data/repositories/user_repository.dart';
import 'package:puryaideu/app/enums/header_type.dart';
import 'package:shared_preferences/shared_preferences.dart';

import './network_helper.dart';

import 'package:get/get.dart';
import 'package:google_maps_flutter/google_maps_flutter.dart';

import 'constant_headers.dart';

class SosRequest {

  static Future<bool> sendSosRequest(LatLng location, String message, int Id, String name) async {
    final url = '$BASE_URL/api/user/sos/create';

    final body = jsonEncode({
        "title": "SOS Request",
        "message": message,
        "booking_id": Id,
        "location": {
          "name": name,
          "latitude": location.longitude,
          "longitude": location.latitude
        }
    });

    try {
      final response = await NetworkHelper().postRequest(url,
          data: body,
          contentType:
          ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
      //print('Response is=== $response');
      if (response.statusCode == 201) {
        final data = response.data['sos']['id'];
        print('Data is ${data}');
        SharedPreferences sharedPreferences =
        await SharedPreferences.getInstance();
        UserRepository userRepository = UserRepository(prefs: sharedPreferences);
        userRepository.setSosId(data.toString());
        return true;
      } else {
        return false;
      }
    } catch (e) {
      return Future.error(e.toString());
    }
  }

  static Future<bool> continueSosEvent(String message, int Id) async {
    final url = '$BASE_URL/api/user/sos/event/create';

    final body = jsonEncode({
      "message": message,
      "sos_id": Id
    });

    try {
      final response = await NetworkHelper().postRequest(url,
          data: body,
          contentType:
          ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
      print('Response is=== $response');
      if (response.statusCode == 201) {
        return true;
      } else {
        return false;
      }
    } catch (e) {
      return Future.error(e.toString());
    }
  }
}
