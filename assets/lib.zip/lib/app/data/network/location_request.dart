import 'dart:convert';
import 'dart:io';

import 'package:puryaideu/app/config/constants.dart';
import 'package:puryaideu/app/data/repositories/SessionManager.dart';
import 'package:puryaideu/app/enums/header_type.dart';

import 'constant_headers.dart';
import 'network_helper.dart';

class LocationRequest {
  static Future<bool> updateUserHomeAndWorkLocation() async {
    String url = '$BASE_URL/api/user/profile/update';
    print(
        {
          "location": {
            "home": {
              "name": SessionManager.instance.home == null
                  ? ''
              :SessionManager.instance.home,
              "latitude": SessionManager.instance.homeLocation == null
                  ? 0.0
                  : SessionManager.instance.homeLocation.latitude,
              "longitude": SessionManager.instance.homeLocation == null
                  ? 0.0
                  : SessionManager.instance.homeLocation.longitude
            },
            "work": {
              "name": SessionManager.instance.work == null
                  ? ''
              : SessionManager.instance.work,
              "latitude": SessionManager.instance.workLocation == null
                  ? 0.0
                  : SessionManager.instance.workLocation.latitude,
              "longitude": SessionManager.instance.workLocation == null
                  ? 0.0
                  : SessionManager.instance.workLocation.longitude
            }
          }
        }
    );
    final body = jsonEncode({
      "location": {
        "home": {
          "name": SessionManager.instance.home,
          "latitude": SessionManager.instance.homeLocation == null
              ? ''
              : SessionManager.instance.homeLocation.latitude,
          "longitude": SessionManager.instance.homeLocation == null
              ? ''
              : SessionManager.instance.homeLocation.longitude
        },
        "work": {
          "name": SessionManager.instance.work,
          "latitude": SessionManager.instance.workLocation == null
              ? ''
              : SessionManager.instance.workLocation.latitude,
          "longitude": SessionManager.instance.workLocation == null
              ? ''
              : SessionManager.instance.workLocation.longitude
        }
      }
    });

    try {
      final response = await NetworkHelper().postRequest(url,
          data: body,
          contentType:
          ConstantHeaders.fetchHeaders(HeaderType.HEADER_WITH_TOKEN));
      print('response==== $response');
      if (response.statusCode == 200){
        return true;
      } else {
        return Future.error('No internet connection');
      }
    } on SocketException {
      return Future.error('No internet connection');
    }
    catch (e) {
      return Future.error(e.toString());
    }
  }
}