class Company {
  final String name;
  final String address;
  final String email;

  const Company({
    this.name,
    this.address,
    this.email,
  });
}

class Customer {
  final String name;
  final String address;
  final String paymentInfo;

  const Customer({
    this.name,
    this.address,
    this.paymentInfo,
  });
}

class Rider {
  final String name;
  final String address;

  const Rider({
    this.name,
    this.address,
  });
}

class Invoice {
  final InvoiceInfo info;
  final Rider rider;
  final Company company;
  final Customer customer;
  final InvoiceItem items;
  final InvoicePrice price;

  const Invoice({
    this.info,
    this.rider,
    this.company,
    this.customer,
    this.items,
    this.price,
  });
}

class InvoiceInfo {
  final String description;
  final String number;
  final DateTime date;

  const InvoiceInfo({
    this.description,
    this.number,
    this.date,
  });
}

class InvoiceItem {
  final String rideType;
  final String date;
  final String origin;
  final String destination;
  final double distance;
  final double price;

  const InvoiceItem({
    this.rideType,
    this.date,
    this.origin,
    this.destination,
    this.distance,
    this.price,
  });
}

class InvoicePrice {
  final String minimumCharge;
  final String perKMRate;
  final String perKMFare;
  final String surgeRate;
  final String surge;
  final String appChargesRate;
  final String perMinuteChargeRate;
  final String appCharges;
  final String surgePerKM;
  final String takenTime;
  final String perMinuteCharge;
  final String total;

  const InvoicePrice({
    this.minimumCharge,
    this.perKMFare,
    this.surgeRate,
    this.surgePerKM,
    this.surge,
    this.appCharges,
    this.takenTime,
    this.appChargesRate,
    this.perKMRate,
    this.perMinuteChargeRate,
    this.perMinuteCharge,
    this.total,
  });
}
