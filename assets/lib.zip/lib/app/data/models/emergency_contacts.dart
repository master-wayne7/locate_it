import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class EmergencyContactsForm {
  TextEditingController firstNameController;
  TextEditingController lastNameController;
  TextEditingController phoneController;
  FocusNode firstNameNode;
  FocusNode lastNameNode;
  FocusNode phoneNode;

  EmergencyContactsForm({
    @required this.firstNameController,
    @required this.lastNameController,
    @required this.firstNameNode,
    @required this.lastNameNode,
    @required this.phoneNode,
    @required this.phoneController
  });
}

class EmergencyContacts {
  EmergencyContacts({
    this.contact,
    this.name
  });

  String contact;
  String name;

  factory EmergencyContacts.fromJson(Map<String, dynamic> json) => EmergencyContacts(
      contact: json["contact"],
    name: json["name"]
  );

  Map<String, dynamic> toJson() => {
    "phone": contact,
    "name" : name
  };
}