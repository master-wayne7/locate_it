// To parse this JSON data, do
//
//     final user = userFromJson(jsonString);

import 'dart:convert';

User userFromJson(String str) => User.fromJson(json.decode(str));

String userToJson(User data) => json.encode(data.toJson());

class User {
    User({
        this.id,
        this.firstName,
        this.lastName,
        this.dob,
        this.gender,
        this.googleId,
        this.facebookId,
        this.phone,
        this.email,
        this.status,
        this.name,
        this.imagePath,
        this.location,
    });

    int id;
    String firstName;
    String lastName;
    DateTime dob;
    Location location;
    dynamic gender;
    dynamic googleId;
    dynamic facebookId;
    String phone;
    String email;
    dynamic status;
    String name;
    String imagePath;

    factory User.fromJson(Map<String, dynamic> json) => User(
        id: json["id"],
        firstName: json["first_name"],
        lastName: json["last_name"],
        location: json["location"] == null ? null : Location.fromJson(json["location"]),
        dob: json["dob"] == null? null: DateTime.parse(json["dob"]),
        gender: json["gender"],
        googleId: json["google_id"],
        facebookId: json["facebook_id"],
        phone: json["phone"],
        email: json["email"],
        status: json["status"],
        // createdAt: DateTime.parse(json["created_at"]),
        // updatedAt: DateTime.parse(json["updated_at"]),
        name: json["name"],
        imagePath: json["image_path"]
    );

    Map<String, dynamic> toJson() => {
        "id": id,
        "first_name": firstName,
        "last_name": lastName,
        "dob": "${dob.year.toString().padLeft(4, '0')}-${dob.month.toString().padLeft(2, '0')}-${dob.day.toString().padLeft(2, '0')}",
        "gender": gender,
        "location": location.toJson(),
        "google_id": googleId,
        "facebook_id": facebookId,
        "phone": phone,
        "email": email,
        "status": status,
        "name": name,
        "image_path": imagePath,
    };
}

class Location {
    Location({
        this.home,
        this.work,
    });

    Home home;
    Home work;

    factory Location.fromJson(Map<String, dynamic> json) => Location(
        home: json["home"]== null ? null: Home.fromJson(json["home"]),
        work:  json["work"]== null ? null: Home.fromJson(json["work"]),
    );

    Map<String, dynamic> toJson() => {
        "home": home.toJson(),
        "work": work.toJson(),
    };
}

class Home {
    Home({
        this.name,
        this.latitude,
        this.longitude,
    });

    String name;
    double latitude;
    double longitude;

    factory Home.fromJson(Map<String, dynamic> json) => Home(
        name: json["name"] == null ? null : json["name"],
        latitude: json["latitude"] == null ? null :json["latitude"].toDouble(),
        longitude: json["longitude"] == null ? null :json["longitude"].toDouble(),
    );

    Map<String, dynamic> toJson() => {
        "name": name == null ? null : name,
        "latitude": latitude,
        "longitude": longitude,
    };
}
