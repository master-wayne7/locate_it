class Booking {
  Booking({
    this.id,
    this.stoppage,
    this.userId,
    this.vehicleTypeId,
    this.riderId,
    this.locationId,
    this.startTime,
    this.endTime,
    this.distance,
    this.duration,
    this.passengerNumber,
    this.status,
    this.price,
    this.paymentType,
    this.deletedAt,
    this.createdAt,
    this.updatedAt,
    this.location,
    this.payment,
    this.priceDetail
  });

  int id;
  List<Stoppage> stoppage;
  int userId;
  int vehicleTypeId;
  dynamic riderId;
  int locationId;
  dynamic startTime;
  dynamic endTime;
  int distance;
  int duration;
  int passengerNumber;
  String status;
  double price;
  String paymentType;
  dynamic deletedAt;
  DateTime createdAt;
  DateTime updatedAt;
  Payment payment;
  Location location;
  PriceDetail priceDetail;



  factory Booking.fromJson(Map<String, dynamic> json) => Booking(
    id: json["id"],
    stoppage: json["stoppage"] == null? null : List<Stoppage>.from(json["stoppage"].map((x) => Stoppage.fromJson(x))),
    userId: json["user_id"],
    vehicleTypeId: json["vehicle_type_id"],
    riderId: json["rider_id"] == null? null: json["rider_id"],
    locationId: json["location_id"],
    startTime: json["start_time"]  == null? null:json["start_time"],
    endTime: json["end_time"]  == null? null: json["end_time"],
    distance: json["distance"],
    duration: json["duration"],
    passengerNumber: json["passenger_number"]  == null? null : json["passenger_number"],
    status: json["status"],
    price: json["price"].toDouble(),
    paymentType: json["payment_type"]  == null? null : json["payment_type"],
    deletedAt: json["deleted_at"]  == null? null : json["deleted_at"],
    createdAt: DateTime.parse(json["created_at"])  == null? null : DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]) == null? null: DateTime.parse(json["updated_at"]) ,
    location: json["location"] == null? null:Location.fromJson(json["location"]),
    payment: json["payment"] == null ? null : Payment.fromJson(json["payment"]),
    priceDetail: json["price_detail"] == null ? null : PriceDetail.fromJson(json["price_detail"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "stoppage": List<dynamic>.from(stoppage.map((x) => x.toJson())),
    "user_id": userId,
    "vehicle_type_id": vehicleTypeId,
    "rider_id": riderId,
    "location_id": locationId,
    "start_time": startTime,
    "end_time": endTime,
    "distance": distance,
    "duration": duration,
    "passenger_number": passengerNumber,
    "status": status,
    "price": price,
    "payment_type": paymentType,
    "deleted_at": deletedAt,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
    "location": location.toJson(),
    "payment": payment.toJson(),
    "price_detail": priceDetail.toJson(),
  };
}

class Location {
  Location({
    this.origin,
    this.destination,
  });

  LocationDetail origin;
  LocationDetail destination;

  factory Location.fromJson(Map<String, dynamic> json) => Location(
    origin: LocationDetail.fromJson(json["origin"]),
    destination: LocationDetail.fromJson(json["destination"]),
  );

  Map<String, dynamic> toJson() => {
    "origin": origin.toJson(),
    "destination": destination.toJson(),
  };
}

class LocationDetail {
  LocationDetail({
    this.name,
    this.latitude,
    this.longitude,
  });

  String name;
  double latitude;
  double longitude;

  factory LocationDetail.fromJson(Map<String, dynamic> json) => LocationDetail(
    name: json["name"],
    latitude: json["latitude"].toDouble(),
    longitude: json["longitude"].toDouble(),
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "latitude": latitude,
    "longitude": longitude,
  };
}


class Stoppage {
  Stoppage({
    this.name,
    this.latitude,
    this.longitude,
  });

  String name;
  double latitude;
  dynamic longitude;

  factory Stoppage.fromJson(Map<String, dynamic> json) => Stoppage(
    name: json["name"],
    latitude: json["latitude"].toDouble(),
    longitude: json["longitude"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "latitude": latitude,
    "longitude": longitude,
  };
}


class Payment {
  Payment({
    this.id,
    this.completedTripId,
    this.commissionAmount,
    this.paymentStatus,
    this.commissionPaymentStatus,
    this.createdAt,
    this.updatedAt,
    this.customerPaymentStatus,
  });

  int id;
  int completedTripId;
  int commissionAmount;
  String paymentStatus;
  String commissionPaymentStatus;
  DateTime createdAt;
  DateTime updatedAt;
  String customerPaymentStatus;

  factory Payment.fromJson(Map<String, dynamic> json) => Payment(
    id: json["id"],
    completedTripId: json["completed_trip_id"],
    commissionAmount: json["commission_amount"],
    paymentStatus: json["payment_status"],
    commissionPaymentStatus: json["commission_payment_status"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
    customerPaymentStatus: json["customer_payment_status"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "completed_trip_id": completedTripId,
    "commission_amount": commissionAmount,
    "payment_status": paymentStatus,
    "commission_payment_status": commissionPaymentStatus,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
    "customer_payment_status": customerPaymentStatus,
  };
}


class PriceDetail {
  int id;
  int completedTripId;
  double baseFare;
  double baseCoveredKm;
  double minimumCharge;
  double pricePerKm;
  double priceAfterDistance;
  double shiftSurge;
  double densitySurge;
  double surgeRate;
  double pricePerKmAfterSurge;
  double surge;
  double priceAfterSurge;
  double appChargePercent;
  double appCharge;
  double priceAfterAppCharge;
  double pricePerMin;
  double pricePerMinAfterBase;
  double durationCharge;
  double priceAfterDuration;
  double priceAfterBaseFare;
  double totalPrice;

  PriceDetail(
      {this.baseFare,
        this.completedTripId,
        this.id,
        this.baseCoveredKm,
        this.minimumCharge,
        this.pricePerKm,

        this.priceAfterDistance,
        this.shiftSurge,
        this.densitySurge,
        this.surgeRate,
        this.pricePerKmAfterSurge,
        this.surge,
        this.priceAfterSurge,
        this.appChargePercent,
        this.appCharge,
        this.priceAfterAppCharge,
        this.pricePerMin,
        this.pricePerMinAfterBase,
        this.durationCharge,
        this.priceAfterDuration,
        this.priceAfterBaseFare,
        this.totalPrice});

  PriceDetail.fromJson(Map<String, dynamic> json) {
    id = json["id"];
    completedTripId =  json["completed_trip_id"];
    baseFare = json["base_fare"] is int? double.parse(json["base_fare"].toString()): json["base_fare"].toDouble();
    baseCoveredKm = json['base_covered_km'] is int? double.parse(json["base_covered_km"].toString()): json["base_covered_km"].toDouble();
    minimumCharge = json['minimum_charge'] is int? double.parse(json["minimum_charge"].toString()): json["minimum_charge"].toDouble();
    pricePerKm =  json['price_per_km'] is int? double.parse(json["price_per_km"].toString()): json["price_per_km"].toDouble();
    priceAfterDistance = json['price_after_distance'] is int? double.parse(json["price_after_distance"].toString()): json["price_after_distance"].toDouble();
    shiftSurge = json['shift_surge'] is int? double.parse(json["shift_surge"].toString()): json["shift_surge"].toDouble();
    densitySurge = json['density_surge'] is int? double.parse(json["density_surge"].toString()): json["density_surge"].toDouble();
    surgeRate = json['surge_rate'] is int? double.parse(json["surge_rate"].toString()): json["surge_rate"].toDouble();
    pricePerKmAfterSurge = json['price_per_km_after_surge'] is int? double.parse(json["price_per_km_after_surge"].toString()): json["price_per_km_after_surge"].toDouble();
    surge = json['surge'] is int? double.parse(json["surge"].toString()): json["surge"].toDouble();
    priceAfterSurge = json['price_after_surge'] is int? double.parse(json["price_after_surge"].toString()): json["price_after_surge"].toDouble();
    appChargePercent = json['app_charge_percent'] is int? double.parse(json["app_charge_percent"].toString()): json["app_charge_percent"].toDouble();
    appCharge = json['app_charge'] is int? double.parse(json["app_charge"].toString()): json["app_charge"].toDouble();
    priceAfterAppCharge = json['price_after_app_charge'] is int? double.parse(json["price_after_app_charge"].toString()): json["price_after_app_charge"].toDouble();
    pricePerMin = json['price_per_min'] is int? double.parse(json["price_per_min"].toString()): json["price_per_min"].toDouble();
    pricePerMinAfterBase = json['price_per_min_after_base'] is int? double.parse(json["price_per_min_after_base"].toString()): json["price_per_min_after_base"].toDouble();
    durationCharge = json['duration_charge'] is int? double.parse(json["duration_charge"].toString()): json["duration_charge"].toDouble();
    priceAfterDuration = json['price_after_duration'] is int? double.parse(json["price_after_duration"].toString()): json["price_after_duration"].toDouble();
    priceAfterBaseFare = json['price_after_base_fare'] is int? double.parse(json["price_after_base_fare"].toString()): json["price_after_base_fare"].toDouble();
    totalPrice = json['total_price'] is int? double.parse(json["total_price"].toString()): json["total_price"].toDouble();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['completed_trip_id'] = this.completedTripId;
    data['base_fare'] = this.baseFare;
    data['base_covered_km'] = this.baseCoveredKm;
    data['minimum_charge'] = this.minimumCharge;
    data['price_per_km'] = this.pricePerKm;
    data['price_after_distance'] = this.priceAfterDistance;
    data['shift_surge'] = this.shiftSurge;
    data['density_surge'] = this.densitySurge;
    data['surge_rate'] = this.surgeRate;
    data['price_per_km_after_surge'] = this.pricePerKmAfterSurge;
    data['surge'] = this.surge;
    data['price_after_surge'] = this.priceAfterSurge;
    data['app_charge_percent'] = this.appChargePercent;
    data['app_charge'] = this.appCharge;
    data['price_after_app_charge'] = this.priceAfterAppCharge;
    data['price_per_min'] = this.pricePerMin;
    data['price_per_min_after_base'] = this.pricePerMinAfterBase;
    data['duration_charge'] = this.durationCharge;
    data['price_after_duration'] = this.priceAfterDuration;
    data['price_after_base_fare'] = this.priceAfterBaseFare;
    data['total_price'] = this.totalPrice;
    return data;
  }
}
