class Rider {
  Rider({
    this.id,
    this.firstName,
    this.lastName,
    this.image,
    this.gender,
    this.phone,
    this.thumbnailPath,
    this.imagePath,
    this.name,
    this.riderDetails,
    this.documents,
  });

  int id;
  String firstName;
  String lastName;
  String image;
  String gender;
  String phone;
  String thumbnailPath;
  String imagePath;
  String name;
  RiderDetails riderDetails;
  List<dynamic> documents;

  factory Rider.fromJson(Map<String, dynamic> json) => Rider(
    id: json["id"],
    firstName: json["first_name"],
    lastName: json["last_name"],
    image: json["image"],
    gender: json["gender"],
    phone: json["phone"],
    thumbnailPath: json["thumbnail_path"],
    name: json["name"],
    imagePath: json["image_path"],
    riderDetails: RiderDetails.fromJson(json["rider"]),
    documents: List<dynamic>.from(json["documents"].map((x) => x)),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "first_name": firstName,
    "last_name": lastName,
    "image": image,
    "gender": gender,
    "phone": phone,
    "name": name,
    "thumbnail_path": thumbnailPath,
    "image_path": imagePath,
    "rider": riderDetails.toJson(),
  };
}

class RiderDetails {
  RiderDetails({
    this.id,
    this.userId,
    this.experience,
    this.vehicle,
  });

  int id;
  int userId;
  String experience;
  Vehicle vehicle;

  factory RiderDetails.fromJson(Map<String, dynamic> json) => RiderDetails(
    id: json["id"],
    userId: json["user_id"],
    experience: json["experience"],
    vehicle: Vehicle.fromJson(json["vehicle"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_id": userId,
    "experience": experience,
    "vehicle": vehicle.toJson(),
  };
}


class Vehicle {
  Vehicle({
    this.vehicleTypeId,
    this.vehicleNumber,
    this.image,
    this.makeYear,
    this.brand,
    this.model,
    this.thumbnailPath,
    this.imagePath,
  });

  int vehicleTypeId;
  String vehicleNumber;
  dynamic image;
  String brand;
  String model;
  String makeYear;
  String thumbnailPath;
  String imagePath;

  factory Vehicle.fromJson(Map<String, dynamic> json) => Vehicle(
    vehicleTypeId: json["vehicle_type_id"],
    vehicleNumber: json["vehicle_number"],
    image: json["image"],
    brand: json["brand"],
    model: json["model"],
    makeYear: json["make_year"],
    thumbnailPath: json["thumbnail_path"],
    imagePath: json["image_path"],
  );

  Map<String, dynamic> toJson() => {
    "vehicle_type_id": vehicleTypeId,
    "vehicle_number": vehicleNumber,
    "image": image,
    "brand": brand,
    "model": model,
    "make_year": makeYear,
    "thumbnail_path": thumbnailPath,
    "image_path": imagePath,
  };
}
