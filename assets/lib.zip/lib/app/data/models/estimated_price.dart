// class EstimatedPriceElement {
//   EstimatedPriceElement({
//     this.vehicleTypeId,
//     this.vehicleTypeName,
//     this.shift,
//     this.priceBreakdown,
//   });
//
//   int vehicleTypeId;
//   String vehicleTypeName;
//   String shift;
//   Map<String, int> priceBreakdown;
//
//   factory EstimatedPriceElement.fromJson(Map<String, dynamic> json) => EstimatedPriceElement(
//     vehicleTypeId: json["vehicle_type_id"],
//     vehicleTypeName: json["vehicle_type_name"],
//     shift: json["shift"],
//     priceBreakdown: Map.from(json["price_breakdown"]).map((k, v) => MapEntry<String, int>(k, v)),
//   );
//
//   Map<String, dynamic> toJson() => {
//     "vehicle_type_id": vehicleTypeId,
//     "vehicle_type_name": vehicleTypeName,
//     "shift": shift,
//     "price_breakdown": Map.from(priceBreakdown).map((k, v) => MapEntry<String, dynamic>(k, v)),
//   };
// }
//
//
// class EstimatedPrice {
//   EstimatedPrice({
//     this.vehicleTypeId,
//     this.vehicleTypeName,
//     this.shift,
//     this.priceBreakdown,
//   });
//
//   int vehicleTypeId;
//   String vehicleTypeName;
//   int shift;
//   PriceBreakdown priceBreakdown;
//
//   factory EstimatedPrice.fromJson(Map<String, dynamic> json) => EstimatedPrice(
//     vehicleTypeId: json["vehicle_type_id"],
//     vehicleTypeName: json["vehicle_type_name"],
//     shift: json["shift"],
//     priceBreakdown: PriceBreakdown.fromJson(json["price_breakdown"]),
//   );
//
//   Map<String, dynamic> toJson() => {
//     "vehicle_type_id": vehicleTypeId,
//     "vehicle_type_name": vehicleTypeName,
//     "shift": shift,
//     "price_breakdown": priceBreakdown.toJson(),
//   };
// }
//
// class PriceBreakdown {
//   PriceBreakdown({
//     this.baseFare,
//     this.minimumCharge,
//     this.pricePerKm,
//     this.priceAfterDistance,
//     this.surgeRate,
//     this.surge,
//     this.priceAfterSurge,
//     this.appChargePercent,
//     this.appCharge,
//     this.priceAfterAppCharge,
//     this.pricePerMin,
//     this.durationCharge,
//     this.priceAfterDuration,
//     this.totalPrice,
//   });
//
//   double baseFare;
//   double minimumCharge;
//   double pricePerKm;
//   double priceAfterDistance;
//   double surgeRate;
//   double surge;
//   double priceAfterSurge;
//   double appChargePercent;
//   double appCharge;
//   double priceAfterAppCharge;
//   double pricePerMin;
//   double durationCharge;
//   double priceAfterDuration;
//   double totalPrice;
//
//   factory PriceBreakdown.fromJson(Map<String, dynamic> json) => PriceBreakdown(
//     baseFare: json["base_fare"] is int? double.parse(json["base_fare"].toString()): json["base_fare"].toDouble(),
//     minimumCharge: json["minimum_charge"] is int? double.parse(json["minimum_charge"].toString()): json["minimum_charge"].toDouble(),
//     pricePerKm: json["price_per_km"] is int? double.parse(json["price_per_km"].toString()): json["price_per_km"].toDouble(),
//     priceAfterDistance: json["price_after_distance"] is int? double.parse(json["price_after_distance"].toString()): json["price_after_distance"].toDouble(),
//     surgeRate: json["surge_rate"] is int? double.parse(json["surge_rate"].toString()): json["surge_rate"].toDouble(),
//     surge: json["surge"] is int? double.parse(json["surge"].toString()): json["surge"].toDouble(),
//     priceAfterSurge: json["price_after_surge"] is int? double.parse(json["price_after_surge"].toString()): json["price_after_surge"].toDouble(),
//     appChargePercent: json["app_charge_percent"] is int? double.parse(json["app_charge_percent"].toString()): json["app_charge_percent"].toDouble(),
//     appCharge: json["app_charge"] is int? double.parse(json["app_charge"].toString()):json["app_charge"].toDouble(),
//     priceAfterAppCharge: json["price_after_app_charge"] is int? double.parse(json["price_after_app_charge"].toString()): json["price_after_app_charge"].toDouble(),
//     pricePerMin: json["price_per_min"] is int? double.parse(json["price_per_min"].toString()): json["price_per_min"].toDouble(),
//     durationCharge: json["duration_charge"] is int? double.parse(json["duration_charge"].toString()): json["duration_charge"].toDouble(),
//     priceAfterDuration: json["price_after_duration"] is int? double.parse(json["price_after_duration"].toString()): json["price_after_duration"].toDouble(),
//     totalPrice: json["total_price"] is int? double.parse(json["total_price"].toString()): json["total_price"].toDouble(),
//   );
//
//   Map<String, dynamic> toJson() => {
//     "base_fare": baseFare,
//     "minimum_charge": minimumCharge,
//     "price_per_km": pricePerKm,
//     "price_after_distance": priceAfterDistance,
//     "surge_rate": surgeRate,
//     "surge": surge,
//     "price_after_surge": priceAfterSurge,
//     "app_charge_percent": appChargePercent,
//     "app_charge": appCharge,
//     "price_after_app_charge": priceAfterAppCharge,
//     "price_per_min": pricePerMin,
//     "duration_charge": durationCharge,
//     "price_after_duration": priceAfterDuration,
//     "total_price": totalPrice,
//   };
// }

class EstimatedPrice {
  int vehicleTypeId;
  String vehicleTypeName;
  String shift;
  PriceBreakdown priceBreakdown;

  EstimatedPrice(
      {this.vehicleTypeId,
      this.vehicleTypeName,
      this.shift,
      this.priceBreakdown});

  EstimatedPrice.fromJson(Map<String, dynamic> json) {
    vehicleTypeId = json['vehicle_type_id'];
    vehicleTypeName = json['vehicle_type_name'];
    shift = json['shift'];
    priceBreakdown = json['price_breakdown'] != null
        ? new PriceBreakdown.fromJson(json['price_breakdown'])
        : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['vehicle_type_id'] = this.vehicleTypeId;
    data['vehicle_type_name'] = this.vehicleTypeName;
    data['shift'] = this.shift;
    if (this.priceBreakdown != null) {
      data['price_breakdown'] = this.priceBreakdown.toJson();
    }
    return data;
  }
}

class PriceBreakdown {
  double baseFare;
  double baseCoveredKm;
  double minimumCharge;
  double pricePerKm;
  double chargedKm;
  double priceAfterDistance;
  double shiftSurge;
  double densitySurge;
  double surgeRate;
  double pricePerKmAfterSurge;
  double surge;
  double priceAfterSurge;
  double appChargePercent;
  double appCharge;
  double priceAfterAppCharge;
  double pricePerMin;
  double pricePerMinAfterBase;
  double durationCharge;
  double priceAfterDuration;
  double priceAfterBaseFare;
  double totalPrice;
  int promotionVoucherId;
  double discountAmount;
  double originalPrice;

  PriceBreakdown(
      {this.baseFare,
      this.baseCoveredKm,
      this.minimumCharge,
      this.pricePerKm,
      this.chargedKm,
      this.priceAfterDistance,
      this.shiftSurge,
      this.densitySurge,
      this.surgeRate,
      this.pricePerKmAfterSurge,
      this.surge,
      this.priceAfterSurge,
      this.appChargePercent,
      this.appCharge,
      this.priceAfterAppCharge,
      this.pricePerMin,
      this.pricePerMinAfterBase,
      this.durationCharge,
      this.priceAfterDuration,
      this.priceAfterBaseFare,
      this.totalPrice,
      this.promotionVoucherId,
        this.discountAmount,
        this.originalPrice,});

  PriceBreakdown.fromJson(Map<String, dynamic> json) {
    baseFare = json["base_fare"] is int
        ? double.parse(json["base_fare"].toString())
        : json["base_fare"].toDouble();
    baseCoveredKm = json['base_covered_km'] is int
        ? double.parse(json["base_covered_km"].toString())
        : json["base_covered_km"].toDouble();
    minimumCharge = json['minimum_charge'] is int
        ? double.parse(json["minimum_charge"].toString())
        : json["minimum_charge"].toDouble();
    pricePerKm = json['price_per_km'] is int
        ? double.parse(json["price_per_km"].toString())
        : json["price_per_km"].toDouble();
    chargedKm = json['charged_km'] is int
        ? double.parse(json["charged_km"].toString())
        : json["charged_km"].toDouble();
    priceAfterDistance = json['price_after_distance'] is int
        ? double.parse(json["price_after_distance"].toString())
        : json["price_after_distance"].toDouble();
    shiftSurge = json['shift_surge'] is int
        ? double.parse(json["shift_surge"].toString())
        : json["shift_surge"].toDouble();
    densitySurge = json['density_surge'] is int
        ? double.parse(json["density_surge"].toString())
        : json["density_surge"].toDouble();
    surgeRate = json['surge_rate'] is int
        ? double.parse(json["surge_rate"].toString())
        : json["surge_rate"].toDouble();
    pricePerKmAfterSurge = json['price_per_km_after_surge'] is int
        ? double.parse(json["price_per_km_after_surge"].toString())
        : json["price_per_km_after_surge"].toDouble();
    surge = json['surge'] is int
        ? double.parse(json["surge"].toString())
        : json["surge"].toDouble();
    priceAfterSurge = json['price_after_surge'] is int
        ? double.parse(json["price_after_surge"].toString())
        : json["price_after_surge"].toDouble();
    appChargePercent = json['app_charge_percent'] is int
        ? double.parse(json["app_charge_percent"].toString())
        : json["app_charge_percent"].toDouble();
    appCharge = json['app_charge'] is int
        ? double.parse(json["app_charge"].toString())
        : json["app_charge"].toDouble();
    priceAfterAppCharge = json['price_after_app_charge'] is int
        ? double.parse(json["price_after_app_charge"].toString())
        : json["price_after_app_charge"].toDouble();
    pricePerMin = json['price_per_min'] is int
        ? double.parse(json["price_per_min"].toString())
        : json["price_per_min"].toDouble();
    pricePerMinAfterBase = json['price_per_min_after_base'] is int
        ? double.parse(json["price_per_min_after_base"].toString())
        : json["price_per_min_after_base"].toDouble();
    durationCharge = json['duration_charge'] is int
        ? double.parse(json["duration_charge"].toString())
        : json["duration_charge"].toDouble();
    priceAfterDuration = json['price_after_duration'] is int
        ? double.parse(json["price_after_duration"].toString())
        : json["price_after_duration"].toDouble();
    priceAfterBaseFare = json['price_after_base_fare'] is int
        ? double.parse(json["price_after_base_fare"].toString())
        : json["price_after_base_fare"].toDouble();
    totalPrice = json['total_price'] is int
        ? double.parse(json["total_price"].toString())
        : json["total_price"].toDouble();
    promotionVoucherId = json["promotion_voucher_id"];
    discountAmount = json["discount_amount"] is int
        ? double.parse(json["discount_amount"].toString())
        : json["discount_amount"].toDouble();
    originalPrice = json["original_price"] is int
        ? double.parse(json["original_price"].toString())
        : json["original_price"].toDouble();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['base_fare'] = this.baseFare;
    data['base_covered_km'] = this.baseCoveredKm;
    data['minimum_charge'] = this.minimumCharge;
    data['price_per_km'] = this.pricePerKm;
    data['charged_km'] = this.chargedKm;
    data['price_after_distance'] = this.priceAfterDistance;
    data['shift_surge'] = this.shiftSurge;
    data['density_surge'] = this.densitySurge;
    data['surge_rate'] = this.surgeRate;
    data['price_per_km_after_surge'] = this.pricePerKmAfterSurge;
    data['surge'] = this.surge;
    data['price_after_surge'] = this.priceAfterSurge;
    data['app_charge_percent'] = this.appChargePercent;
    data['app_charge'] = this.appCharge;
    data['price_after_app_charge'] = this.priceAfterAppCharge;
    data['price_per_min'] = this.pricePerMin;
    data['price_per_min_after_base'] = this.pricePerMinAfterBase;
    data['duration_charge'] = this.durationCharge;
    data['price_after_duration'] = this.priceAfterDuration;
    data['price_after_base_fare'] = this.priceAfterBaseFare;
    data['total_price'] = this.totalPrice;
    data["promotion_voucher_id"] = this.promotionVoucherId;
    data["discount_amount"] = this.discountAmount;
    data["original_price"] = originalPrice;
    return data;
  }
}
