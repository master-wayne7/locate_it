class CompletedTrip {
  CompletedTrip({
    this.id,
    this.userId,
    this.riderId,
    this.bookingId,
    this.location,
    this.startTime,
    this.endTime,
    this.distance,
    this.duration,
    this.passengerNumber,
    this.price,
    this.paymentType,
    this.distanceKm,
    this.durationMin,
    this.payment,
    this.booking,
    this.priceDetail,
  });

  int id;
  int userId;
  int riderId;
  int bookingId;
  Location location;
  DateTime startTime;
  DateTime endTime;
  String distance;
  String duration;
  String passengerNumber;
  int price;
  String paymentType;
  double distanceKm;
  double durationMin;
  Payment payment;
  Booking booking;
  PriceDetail priceDetail;

  factory CompletedTrip.fromJson(Map<String, dynamic> json) => CompletedTrip(
    id: json["id"],
    userId: json["user_id"],
    riderId: json["rider_id"],
    bookingId: json["booking_id"],
    location: Location.fromJson(json["location"]),
    startTime: DateTime.parse(json["start_time"]),
    endTime: DateTime.parse(json["end_time"]),
    distance: json["distance"] is int ? json["distance_km"].toString(): json["distance"],
    duration: json["duration"] is int ? json["duration"].toString(): json["duration"],
    passengerNumber: json["passenger_number"],
    price: json["price"],
    paymentType: json["payment_type"],
    distanceKm: json["distance_km"].toDouble(),
    durationMin: json["duration_min"].toDouble(),
    payment: Payment.fromJson(json["payment"]),
    booking: Booking.fromJson(json["booking"]),
    priceDetail: PriceDetail.fromJson(json["price_detail"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "user_id": userId,
    "rider_id": riderId,
    "booking_id": bookingId,
    "location": location.toJson(),
    "start_time": startTime.toIso8601String(),
    "end_time": endTime.toIso8601String(),
    "distance": distance,
    "duration": duration,
    "price": price,
    "payment_type": paymentType,
    "distance_km": distanceKm,
    "duration_min": durationMin,
    "payment": payment.toJson(),
    "booking": booking.toJson(),
    "price_detail": priceDetail.toJson(),
  };
}

class Booking {
  Booking({
    this.id,
    this.vehicleTypeId,
    this.tripId,
    this.distanceKm,
    this.durationMin,
  });

  int id;
  String tripId;
  int vehicleTypeId;
  double distanceKm;
  double durationMin;

  factory Booking.fromJson(Map<String, dynamic> json) => Booking(
    id: json["id"],
    tripId: json["trip_id"],
    vehicleTypeId: json["vehicle_type_id"],
    distanceKm: json["distance_km"] is int ? double.parse(json["distance_km"].toString())
      : json["distance_km"].toDouble(),
    durationMin: json["duration_min"] is int ? double.parse(json["duration_min"].toString())
        : json["duration_min"].toDouble(),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "trip_id": tripId,
    "vehicle_type_id": vehicleTypeId,
    "distance_km": distanceKm,
    "duration_min": durationMin,
  };
}

class Location {
  Location({
    this.origin,
    this.destination,
  });

  Destination origin;
  Destination destination;

  factory Location.fromJson(Map<String, dynamic> json) => Location(
    origin: Destination.fromJson(json["origin"]),
    destination: Destination.fromJson(json["destination"]),
  );

  Map<String, dynamic> toJson() => {
    "origin": origin.toJson(),
    "destination": destination.toJson(),
  };
}

class Destination {
  Destination({
    this.name,
    this.latitude,
    this.longitude,
  });

  String name;
  double latitude;
  double longitude;

  factory Destination.fromJson(Map<String, dynamic> json) => Destination(
    name: json["name"],
    latitude: json["latitude"].toDouble(),
    longitude: json["longitude"].toDouble(),
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "latitude": latitude,
    "longitude": longitude,
  };
}

class Payment {
  Payment({
    this.id,
    this.customerPaymentStatus,
  });

  int id;
  String customerPaymentStatus;

  factory Payment.fromJson(Map<String, dynamic> json) => Payment(
    id: json["id"],
    customerPaymentStatus: json["customer_payment_status"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "customer_payment_status": customerPaymentStatus,
  };
}

class PriceDetail {
  PriceDetail({
    this.id,
    this.baseFare,
    this.baseCoveredKm,
    this.minimumCharge,
    this.pricePerKm,
    this.chargedKm,
    this.priceAfterDistance,
    this.shiftSurge,
    this.densitySurge,
    this.surgeRate,
    this.pricePerKmAfterSurge,
    this.surge,
    this.priceAfterSurge,
    this.appChargePercent,
    this.appCharge,
    this.priceAfterAppCharge,
    this.pricePerMin,
    this.pricePerMinAfterBase,
    this.durationCharge,
    this.priceAfterDuration,
    this.priceAfterBaseFare,
    this.totalPrice,
    this.promotionVoucherId,
    this.discountAmount,
    this.originalPrice,
  });

  int id;
  double baseFare;
  double baseCoveredKm;
  double minimumCharge;
  double pricePerKm;
  double chargedKm;
  double priceAfterDistance;
  double shiftSurge;
  double densitySurge;
  double surgeRate;
  double pricePerKmAfterSurge;
  double surge;
  double priceAfterSurge;
  double appChargePercent;
  double appCharge;
  double priceAfterAppCharge;
  double pricePerMin;
  double pricePerMinAfterBase;
  double durationCharge;
  double priceAfterDuration;
  double priceAfterBaseFare;
  double totalPrice;
  int promotionVoucherId;
  double discountAmount;
  double originalPrice;

  PriceDetail.fromJson(Map<String, dynamic> json){
    id = json["id"];
    baseFare = json["base_fare"] is int
        ? double.parse(json["base_fare"].toString())
        : json["base_fare"].toDouble();
    baseCoveredKm = json['base_covered_km'] is int
        ? double.parse(json["base_covered_km"].toString())
        : json["base_covered_km"].toDouble();
    minimumCharge = json['minimum_charge'] is int
        ? double.parse(json["minimum_charge"].toString())
        : json["minimum_charge"].toDouble();
    pricePerKm = json['price_per_km'] is int
        ? double.parse(json["price_per_km"].toString())
        : json["price_per_km"].toDouble();
    chargedKm = json['charged_km'] is int
        ? double.parse(json["charged_km"].toString())
        : json["charged_km"].toDouble();
    priceAfterDistance = json['price_after_distance'] is int
        ? double.parse(json["price_after_distance"].toString())
        : json["price_after_distance"].toDouble();
    shiftSurge = json['shift_surge'] is int
        ? double.parse(json["shift_surge"].toString())
        : json["shift_surge"].toDouble();
    densitySurge = json['density_surge'] is int
        ? double.parse(json["density_surge"].toString())
        : json["density_surge"].toDouble();
    surgeRate = json['surge_rate'] is int
        ? double.parse(json["surge_rate"].toString())
        : json["surge_rate"].toDouble();
    pricePerKmAfterSurge = json['price_per_km_after_surge'] is int
        ? double.parse(json["price_per_km_after_surge"].toString())
        : json["price_per_km_after_surge"].toDouble();
    surge = json['surge'] is int
        ? double.parse(json["surge"].toString())
        : json["surge"].toDouble();
    priceAfterSurge = json['price_after_surge'] is int
        ? double.parse(json["price_after_surge"].toString())
        : json["price_after_surge"].toDouble();
    appChargePercent = json['app_charge_percent'] is int
        ? double.parse(json["app_charge_percent"].toString())
        : json["app_charge_percent"].toDouble();
    appCharge = json['app_charge'] is int
        ? double.parse(json["app_charge"].toString())
        : json["app_charge"].toDouble();
    priceAfterAppCharge = json['price_after_app_charge'] is int
        ? double.parse(json["price_after_app_charge"].toString())
        : json["price_after_app_charge"].toDouble();
    pricePerMin = json['price_per_min'] is int
        ? double.parse(json["price_per_min"].toString())
        : json["price_per_min"].toDouble();
    pricePerMinAfterBase = json['price_per_min_after_base'] is int
        ? double.parse(json["price_per_min_after_base"].toString())
        : json["price_per_min_after_base"].toDouble();
    durationCharge = json['duration_charge'] is int
        ? double.parse(json["duration_charge"].toString())
        : json["duration_charge"].toDouble();
    priceAfterDuration = json['price_after_duration'] is int
        ? double.parse(json["price_after_duration"].toString())
        : json["price_after_duration"].toDouble();
    priceAfterBaseFare = json['price_after_base_fare'] is int
        ? double.parse(json["price_after_base_fare"].toString())
        : json["price_after_base_fare"].toDouble();
    totalPrice = json['total_price'] is int
        ? double.parse(json["total_price"].toString())
        : json["total_price"].toDouble();
    promotionVoucherId = json["promotion_voucher_id"];
    discountAmount = json["discount_amount"] is int
        ? double.parse(json["discount_amount"].toString())
        : json["discount_amount"].toDouble();
    originalPrice = json["original_price"] is int
        ? double.parse(json["original_price"].toString())
        : json["original_price"].toDouble();
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['base_fare'] = this.baseFare;
    data['base_covered_km'] = this.baseCoveredKm;
    data['minimum_charge'] = this.minimumCharge;
    data['price_per_km'] = this.pricePerKm;
    data['charged_km'] = this.chargedKm;
    data['price_after_distance'] = this.priceAfterDistance;
    data['shift_surge'] = this.shiftSurge;
    data['density_surge'] = this.densitySurge;
    data['surge_rate'] = this.surgeRate;
    data['price_per_km_after_surge'] = this.pricePerKmAfterSurge;
    data['surge'] = this.surge;
    data['price_after_surge'] = this.priceAfterSurge;
    data['app_charge_percent'] = this.appChargePercent;
    data['app_charge'] = this.appCharge;
    data['price_after_app_charge'] = this.priceAfterAppCharge;
    data['price_per_min'] = this.pricePerMin;
    data['price_per_min_after_base'] = this.pricePerMinAfterBase;
    data['duration_charge'] = this.durationCharge;
    data['price_after_duration'] = this.priceAfterDuration;
    data['price_after_base_fare'] = this.priceAfterBaseFare;
    data['total_price'] = this.totalPrice;
    data["promotion_voucher_id"] = this.promotionVoucherId;
    data["discount_amount"] = this.discountAmount;
    data["original_price"] = originalPrice;
    return data;
  }
}
