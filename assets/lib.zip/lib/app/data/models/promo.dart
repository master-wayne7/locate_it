class PromotionVoucher {
  PromotionVoucher({
    this.id,
    this.image,
    this.code,
    this.name,
    this.description,
    this.type,
  });

  int id;
  String image;
  String code;
  String name;
  String description;
  String type;

  factory PromotionVoucher.fromJson(Map<String, dynamic> json) => PromotionVoucher(
    id: json["id"],
    image: json["image"] == null ? null : json["image"],
    code: json["code"],
    name: json["name"],
    description: json["description"],
    type: json["type"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "image": image == null ? null : image,
    "code": code,
    "name": name,
    "description": description,
    "type": type,
  };
}

class Promo {
  Promo({
    this.id,
    this.code,
    this.title,
    this.message,
    this.image,
    this.createdAt,
    this.imagePath,
  });

  int id;
  String code;
  String title;
  String message;
  String image;
  DateTime createdAt;
  String imagePath;

  factory Promo.fromJson(Map<String, dynamic> json) => Promo(
    id: json["id"],
    code: json["code"],
    title: json["title"],
    message: json["message"],
    image: json["image"],
    createdAt: DateTime.parse(json["created_at"]),
    imagePath: json["image_path"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "code": code,
    "title": title,
    "message": message,
    "image": image,
    "image_path": imagePath,
  };
}