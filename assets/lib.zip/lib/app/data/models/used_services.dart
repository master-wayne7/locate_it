
class UsedServices {
  UsedServices({
    this.id,
    this.name,
    this.completed,
    this.cancelled,
    this.used,
  });

  int id;
  String name;
  bool completed;
  bool cancelled;
  bool used;

  factory UsedServices.fromJson(Map<String, dynamic> json) => UsedServices(
    id: json["id"],
    name: json["name"],
    completed: json["completed"],
    cancelled: json["cancelled"],
    used: json["used"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "completed": completed,
    "cancelled": cancelled,
    "used": used,
  };
}
