class Notifications {
  Notifications({
    this.id,
    this.code,
    this.title,
    this.message,
    this.image,
    this.recipientId,
    this.recipientDeviceToken,
    this.recipientType,
    this.recipientQuantityType,
    this.notificationType,
    this.bookingId,
    this.readAt,
    this.deletedAt,
    this.createdAt,
    this.updatedAt,
    this.thumbnailPath,
    this.imagePath,
    this.fiveMinutesOld,
  });

  int id;
  String code;
  String title;
  String message;
  String image;
  dynamic recipientId;
  dynamic recipientDeviceToken;
  String recipientType;
  String recipientQuantityType;
  String notificationType;
  dynamic bookingId;
  dynamic readAt;
  dynamic deletedAt;
  DateTime createdAt;
  DateTime updatedAt;
  String thumbnailPath;
  String imagePath;
  bool fiveMinutesOld;

  factory Notifications.fromJson(Map<String, dynamic> json) => Notifications(
    id: json["id"],
    code: json["code"],
    title: json["title"],
    message: json["message"],
    image: json["image"],
    recipientId: json["recipient_id"],
    recipientDeviceToken: json["recipient_device_token"],
    recipientType: json["recipient_type"],
    recipientQuantityType: json["recipient_quantity_type"],
    notificationType: json["notification_type"],
    bookingId: json["booking_id"],
    readAt: json["read_at"],
    deletedAt: json["deleted_at"],
    createdAt: DateTime.parse(json["created_at"]),
    updatedAt: DateTime.parse(json["updated_at"]),
    thumbnailPath: json["thumbnail_path"],
    imagePath: json["image_path"],
    fiveMinutesOld: json["five_minutes_old"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "code": code,
    "title": title,
    "message": message,
    "image": image,
    "recipient_id": recipientId,
    "recipient_device_token": recipientDeviceToken,
    "recipient_type": recipientType,
    "recipient_quantity_type": recipientQuantityType,
    "notification_type": notificationType,
    "booking_id": bookingId,
    "read_at": readAt,
    "deleted_at": deletedAt,
    "created_at": createdAt.toIso8601String(),
    "updated_at": updatedAt.toIso8601String(),
    "thumbnail_path": thumbnailPath,
    "image_path": imagePath,
    "five_minutes_old": fiveMinutesOld,
  };
}