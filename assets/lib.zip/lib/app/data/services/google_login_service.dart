import 'dart:async';

import 'package:get/get.dart';
import 'package:google_sign_in/google_sign_in.dart';

class GoogleLoginService {

  GoogleLoginService._();

  static Future<dynamic> performGoogleLogin() async {
    GoogleSignIn _googleSignIn = GoogleSignIn();
    try {
      var response = await _googleSignIn.signIn();
      if(response == null) {
        return Future.error('cancelled');
      }
      return response;
    } catch (e) {
      if(e.toString().contains('network_error')) {
        return Future.error('Check Internet');
      }
      print('exception occured==== $e');
      return Future.error('${e.toString()}');
    }
  }
}
