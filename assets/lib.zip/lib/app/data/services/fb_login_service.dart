// import 'dart:convert';
//
// import 'package:flutter_facebook_login/flutter_facebook_login.dart';
// import 'package:http/http.dart' as http;
//
// class FbLoginService {
//   FbLoginService._();
//
//   static Future<dynamic> performFacebookLogin() async {
//     final facebookLogin = FacebookLogin();
//     final result = await facebookLogin.logIn(['email']);
//     switch (result.status) {
//       case FacebookLoginStatus.loggedIn:
//         var profile = await fetchUserProfile(result.accessToken.token);
//         return profile;
//         break;
//       case FacebookLoginStatus.cancelledByUser:
//         break;
//       case FacebookLoginStatus.error:
//         return Future.error(result.errorMessage);
//         break;
//     }
//   }
//
//   static Future<dynamic> fetchUserProfile(accessToken) async {
//     final graphResponse = await http.get(Uri.parse(
//         'https://graph.facebook.com/v2.12/me?fields=name,first_name,last_name,picture.width(800).height(800),email&access_token=${accessToken}'));
//     final profile = jsonDecode(graphResponse.body);
//     return profile;
//   }
// }
