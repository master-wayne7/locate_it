import 'dart:async';

import 'package:connectivity/connectivity.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

import 'package:get/get.dart';
import 'package:new_version/new_version.dart';
import 'package:overlay_support/overlay_support.dart';
import 'package:puryaideu/app/utils/language_preferences.dart';
import 'package:responsive_framework/responsive_framework.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'app/config/theme.dart';
import 'app/data/repositories/user_repository.dart';
import 'app/routes/app_pages.dart';
import 'app/utils/local_notifications_singleton.dart';
import 'app/utils/localization_services.dart';
import 'app/utils/network_connectivity.dart';
import 'app/utils/scroll_control.dart';
import 'generated/locales.g.dart';

Future<void> _firebaseMessagingBackgroundHandler(RemoteMessage message) async {
  await Firebase.initializeApp();
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle(
    systemNavigationBarColor: Color.fromRGBO(225, 89, 89, 1),
    // navigation bar color
    statusBarColor: Color.fromRGBO(225, 89, 89, 1),
    systemNavigationBarIconBrightness: Brightness.light, // tatus bar color
  ));

  await Firebase.initializeApp();
  FirebaseMessaging.onBackgroundMessage(_firebaseMessagingBackgroundHandler);

  await LocalNotificationPluginSingleton.instance.localNotificationsPlugin
      .resolvePlatformSpecificImplementation<
          AndroidFlutterLocalNotificationsPlugin>()
      ?.createNotificationChannel(
          LocalNotificationPluginSingleton.instance.channel);

  await FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
      alert: true, badge: true, sound: true);
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return OverlaySupport(
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        home: Puryaideu(),
        builder: (context, widget) => ResponsiveWrapper.builder(
          ClampingScrollWrapper.builder(context, widget),
          maxWidth: 1200,
          minWidth: 480,
          breakpoints: const [
            ResponsiveBreakpoint.resize(480, name: MOBILE),
            ResponsiveBreakpoint.autoScale(800, name: TABLET),
            ResponsiveBreakpoint.resize(1000, name: DESKTOP),
            ResponsiveBreakpoint.autoScale(2460, name: '4K'),
          ],
        ),
      ),
    );
  }
}

class Puryaideu extends StatefulWidget {
  @override
  State<Puryaideu> createState() => _PuryaideuState();
}

class _PuryaideuState extends State<Puryaideu> with WidgetsBindingObserver {
  StreamSubscription subscription;

  int index = 0;

  @override
  void initState() {
    callLanguageSettings();

    subscription =
        Connectivity().onConnectivityChanged.listen(showConnectivitySnackBar);

    // _checkVersion();
    WidgetsBinding.instance.addObserver(this);
    FirebaseMessaging.onMessage.listen((RemoteMessage message) async {
      RemoteNotification notification = message.notification;
      print(" Message data : ${message.data}");
      dynamic messageType = message.data;
      print(messageType);
      print(message.data['notifications_type']);
      if (messageType == 'garage_request') {
      } else if (messageType == 'extend') {}

      AndroidNotification android = message.notification?.android;

      AppleNotification appleNotification = message.notification?.apple;

      if (notification != null && android != null) {
        LocalNotificationPluginSingleton.instance.localNotificationsPlugin.show(
          notification.hashCode,
          notification.title,
          notification.body,
          NotificationDetails(
              android: AndroidNotificationDetails(
                  LocalNotificationPluginSingleton.instance.channel.id,
                  LocalNotificationPluginSingleton.instance.channel.name,
                  LocalNotificationPluginSingleton.instance.channel.description,
                  playSound: true,
                  icon: '@mipmap/ic_launcher')),
        );
      }
      if (notification != null && appleNotification != null) {
        print('Apple notification arrived');
        LocalNotificationPluginSingleton.instance.localNotificationsPlugin.show(
          notification.hashCode,
          notification.title,
          notification.body,
          NotificationDetails(
              iOS: IOSNotificationDetails(
                  presentSound: true, presentAlert: true, presentBadge: true)),
        );
      }
    });

    FirebaseMessaging.instance.setForegroundNotificationPresentationOptions(
        alert: true, sound: true, badge: true);

    FirebaseMessaging.onMessageOpenedApp.listen((RemoteMessage message) async {
      // UserDataRepository.instance.setTrigger(messageType);
    });
    super.initState();
  }

  void showConnectivitySnackBar(ConnectivityResult result) {
    final hasInternet = result != ConnectivityResult.none;
    final message = hasInternet
        ? 'You are connected to the internet.'
        : 'You have no internet';
    final color = hasInternet ? Colors.green : Colors.red;

    //NetworkConnectivity.showTopSnackBar(context, message, color);
  }

  @override
  void dispose() {
    subscription.cancel();

    super.dispose();
  }

  // void _checkVersion() async {
  //   final newVersion = NewVersion(
  //     androidId: "com.letitgrownepal.puryaideu",
  //   );
  //   final status = await newVersion.getVersionStatus();
  //
  //   if (status.storeVersion != status.localVersion) {
  //     newVersion.showUpdateDialog(
  //       context: context,
  //       versionStatus: status,
  //       dialogTitle: "Update Required",
  //       dismissButtonText: "Skip",
  //       allowDismissal: true,
  //       dialogText:
  //           "Please update the app to continue using Puryaideu's services.",
  //       dismissAction: () {
  //         SystemNavigator.pop();
  //       },
  //       updateButtonText: "Update now",
  //     );
  //   }
  //
  //   print("DEVICE : " + status.localVersion);
  //   print("STORE : " + status.storeVersion);
  // }

  callLanguageSettings() async {
    SharedPreferences sharedPreferences = await SharedPreferences.getInstance();
    UserRepository userRepository = UserRepository(prefs: sharedPreferences);
    index = await userRepository.getLanguageIndex();
    if (index == null) {
      index = 0;
    }
    print('index is=== $index');
    LanguagePreferences.updateLanguageSettings(index);
  }

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      builder: (context, child) {
        return ScrollConfiguration(
          behavior: MyBehavior(),
          child: child,
        );
      },
      title: "Puryaideu",
      theme: kThemeData,
      translationsKeys: AppTranslation.translations,
      translations: LocalizationService(),
      debugShowCheckedModeBanner: false,
      initialRoute: AppPages.INITIAL,
      getPages: AppPages.routes,
    );
  }
}
