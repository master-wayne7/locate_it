// DO NOT EDIT. This is code generated via package:get_cli/get_cli.dart

// ignore_for_file: lines_longer_than_80_chars
// ignore: avoid_classes_with_only_static_members
class AppTranslation {
  static Map<String, Map<String, String>> translations = {
    'en_US': Locales.en_US,
    'ne_NP': Locales.ne_NP,
  };
}

class LocaleKeys {
  LocaleKeys._();
  static const app_name = 'app_name';
  static const onboarding_heading1 = 'onboarding_heading1';
  static const onboarding_content1 = 'onboarding_content1';
  static const onboarding_heading2 = 'onboarding_heading2';
  static const onboarding_content2 = 'onboarding_content2';
  static const onboarding_heading3 = 'onboarding_heading3';
  static const onboarding_content3 = 'onboarding_content3';
  static const trip_dialogs_emergency_service =
      'trip_dialogs_emergency_service';
  static const trip_dialogs_call_nepal_police =
      'trip_dialogs_call_nepal_police';
  static const trip_dialogs_emergency_message =
      'trip_dialogs_emergency_message';
  static const trip_dialogs_enter_complain = 'trip_dialogs_enter_complain';
  static const trip_dialogs_cancel_booking = 'trip_dialogs_cancel_booking';
  static const trip_dialogs_cancel_booking_question =
      'trip_dialogs_cancel_booking_question';
  static const trip_dialogs_satisfied_with_region =
      'trip_dialogs_satisfied_with_region';
  static const trip_dialogs_yes = 'trip_dialogs_yes';
  static const trip_dialogs_no = 'trip_dialogs_no';
  static const rating_rate_customer = 'rating_rate_customer';
  static const rating_rider = 'rating_rider';
  static const rating_rate_now = 'rating_rate_now';
  static const rating_rate_later = 'rating_rate_later';
  static const auth_google = 'auth_google';
  static const auth_facebook = 'auth_facebook';
  static const home_morning = 'home_morning';
  static const home_afternoon = 'home_afternoon';
  static const home_evening = 'home_evening';
  static const home_hi = 'home_hi';
  static const home_good = 'home_good';
  static const home_online = 'home_online';
  static const home_offline = 'home_offline';
  static const home_you_are_offline = 'home_you_are_offline';
  static const home_please_go_online_to = 'home_please_go_online_to';
  static const home_duration = 'home_duration';
  static const home_distance = 'home_distance';
  static const home_price = 'home_price';
  static const notifications_CAMPAIGNS = 'notifications_CAMPAIGNS';
  static const notifications_PROMOTIONS = 'notifications_PROMOTIONS';
  static const history_bike = 'history_bike';
  static const history_car = 'history_car';
  static const history_city_safari = 'history_city_safari';
  static const history_ambulance = 'history_ambulance';
  static const history_food_delivery = 'history_food_delivery';
  static const history_courier = 'history_courier';
  static const history_show_cancelled_rides = 'history_show_cancelled_rides';
  static const history_rate_now = 'history_rate_now';
  static const history_trip_details = 'history_trip_details';
  static const history_trip_id = 'history_trip_id';
  static const history_trip_info = 'history_trip_info';
  static const history_bill_breakdown = 'history_bill_breakdown';
  static const history_minimum_fare = 'history_minimum_fare';
  static const history_base_fare = 'history_base_fare';
  static const history_kilometers = 'history_kilometers';
  static const history_minutes = 'history_minutes';
  static const history_surge = 'history_surge';
  static const history_app_charges = 'history_app_charges';
  static const history_subtotal = 'history_subtotal';
  static const history_commission = 'history_commission';
  static const history_total = 'history_total';
  static const history_trip_id_copied = 'history_trip_id_copied';
  static const history_origin = 'history_origin';
  static const history_destination = 'history_destination';
  static const history_receipt = 'history_receipt';
  static const history_per_km = 'history_per_km';
  static const history_per_min = 'history_per_min';
  static const history_discount = 'history_discount';
  static const profile_lifetime_earnings = 'profile_lifetime_earnings';
  static const profile_due_amount = 'profile_due_amount';
  static const profile_distance_travelled = 'profile_distance_travelled';
  static const profile_total_trips = 'profile_total_trips';
  static const profile_ratings = 'profile_ratings';
  static const profile_documents = 'profile_documents';
  static const profile_promotions = 'profile_promotions';
  static const profile_language = 'profile_language';
  static const profile_about_us = 'profile_about_us';
  static const profile_log_out = 'profile_log_out';
  static const profile_avg = 'profile_avg';
  static const profile_add_promo_code = 'profile_add_promo_code';
  static const profile_enter_promo_code = 'profile_enter_promo_code';
  static const profile_apply = 'profile_apply';
  static const profile_select_language = 'profile_select_language';
  static const profile_select_preferred_language =
      'profile_select_preferred_language';
  static const document_update_update_documents =
      'document_update_update_documents';
  static const document_update_license = 'document_update_license';
  static const document_update_vehicle_details =
      'document_update_vehicle_details';
  static const document_update_bluebook = 'document_update_bluebook';
  static const document_update_status = 'document_update_status';
  static const document_update_reason = 'document_update_reason';
  static const document_update_license_photo = 'document_update_license_photo';
  static const document_update_license_number =
      'document_update_license_number';
  static const document_update_issue_date = 'document_update_issue_date';
  static const document_update_expiry_date = 'document_update_expiry_date';
  static const document_update_vehicle_number =
      'document_update_vehicle_number';
  static const document_update_vehicle_document =
      'document_update_vehicle_document';
  static const document_update_make_year = 'document_update_make_year';
  static const document_update_vehicle_type = 'document_update_vehicle_type';
  static const document_update_brand_name = 'document_update_brand_name';
  static const document_update_model_name = 'document_update_model_name';
  static const document_update_vehicle_photo = 'document_update_vehicle_photo';
  static const document_update_bluebook_details =
      'document_update_bluebook_details';
  static const document_update_bluebook_first_photo =
      'document_update_bluebook_first_photo';
  static const document_update_bluebook_second_photo =
      'document_update_bluebook_second_photo';
  static const document_update_bluebook_third_photo =
      'document_update_bluebook_third_photo';
  static const document_update_bluebook_fourth_photo =
      'document_update_bluebook_fourth_photo';
  static const document_update_upload_bluebook_photo =
      'document_update_upload_bluebook_photo';
  static const document_update_bluebook_number =
      'document_update_bluebook_number';
  static const document_update_please_enter_license_number =
      'document_update_please_enter_license_number';
  static const document_update_please_enter_vehicle_number =
      'document_update_please_enter_vehicle_number';
  static const document_update_please_enter_vehicle_make_year =
      'document_update_please_enter_vehicle_make_year';
  static const document_update_please_enter_vehicle_brand_name =
      'document_update_please_enter_vehicle_brand_name';
  static const document_update_please_enter_vehicle_model =
      'document_update_please_enter_vehicle_model';
  static const document_update_pending = 'document_update_pending';
  static const document_update_approved = 'document_update_approved';
  static const bottom_navigation_items_history =
      'bottom_navigation_items_history';
  static const bottom_navigation_items_home = 'bottom_navigation_items_home';
  static const bottom_navigation_items_notifications =
      'bottom_navigation_items_notifications';
  static const bottom_navigation_items_settings =
      'bottom_navigation_items_settings';
  static const buttons_accept_trip = 'buttons_accept_trip';
  static const buttons_ambulance = 'buttons_ambulance';
  static const buttons_call = 'buttons_call';
  static const buttons_cancel_booking = 'buttons_cancel_booking';
  static const buttons_confirm_destination = 'buttons_confirm_destination';
  static const buttons_confirm_payment = 'buttons_confirm_payment';
  static const buttons_confirm_pickup = 'buttons_confirm_pickup';
  static const buttons_continue = 'buttons_continue';
  static const buttons_continue_with_phone = 'buttons_continue_with_phone';
  static const buttons_courier = 'buttons_courier';
  static const buttons_facebook = 'buttons_facebook';
  static const buttons_finish_ride = 'buttons_finish_ride';
  static const buttons_ghar_khaja = 'buttons_ghar_khaja';
  static const buttons_go_online = 'buttons_go_online';
  static const buttons_google = 'buttons_google';
  static const buttons_invite = 'buttons_invite';
  static const buttons_log_out = 'buttons_log_out';
  static const buttons_next = 'buttons_next';
  static const buttons_offline_payment = 'buttons_offline_payment';
  static const buttons_online_payment = 'buttons_online_payment';
  static const buttons_privacy_policy = 'buttons_privacy_policy';
  static const buttons_proceed = 'buttons_proceed';
  static const buttons_request_ride = 'buttons_request_ride';
  static const buttons_search_by_pin = 'buttons_search_by_pin';
  static const buttons_set_destination = 'buttons_set_destination';
  static const buttons_set_home = 'buttons_set_home';
  static const buttons_set_language = 'buttons_set_language';
  static const buttons_set_pickup = 'buttons_set_pickup';
  static const buttons_set_work = 'buttons_set_work';
  static const buttons_start_ride = 'buttons_start_ride';
  static const buttons_submit = 'buttons_submit';
  static const buttons_terms_and_condition = 'buttons_terms_and_condition';
  static const buttons_try_again = 'buttons_try_again';
  static const buttons_verify = 'buttons_verify';
  static const buttons_view_on_map = 'buttons_view_on_map';
  static const hints_search_pickup = 'hints_search_pickup';
  static const hints_search_destination = 'hints_search_destination';
  static const image_picker_items_camera = 'image_picker_items_camera';
  static const image_picker_items_photo_library =
      'image_picker_items_photo_library';
  static const labels_dob = 'labels_dob';
  static const labels_email = 'labels_email';
  static const labels_experience = 'labels_experience';
  static const labels_first_name = 'labels_first_name';
  static const labels_gender = 'labels_gender';
  static const labels_last_name = 'labels_last_name';
  static const labels_license_number = 'labels_license_number';
  static const labels_vehicle_number = 'labels_vehicle_number';
  static const labels_vehicle_type = 'labels_vehicle_type';
  static const settings_about = 'settings_about';
  static const settings_app_settings = 'settings_app_settings';
  static const settings_document = 'settings_document';
  static const settings_top_up_payment = 'settings_top_up_payment';
  static const text_add_profile = 'text_add_profile';
  static const text_and = 'text_and';
  static const text_balance = 'text_balance';
  static const text_by_tapping = 'text_by_tapping';
  static const text_change_location = 'text_change_location';
  static const text_current_location = 'text_current_location';
  static const text_distance_travelled = 'text_distance_travelled';
  static const text_enter_destination = 'text_enter_destination';
  static const text_get_discount = 'text_get_discount';
  static const text_invite_friends = 'text_invite_friends';
  static const text_location_permission_message =
      'text_location_permission_message';
  static const text_no_bookings = 'text_no_bookings';
  static const text_of_puryaideu = 'text_of_puryaideu';
  static const text_offline_message = 'text_offline_message';
  static const text_or = 'text_or';
  static const text_otp_message = 'text_otp_message';
  static const text_payment = 'text_payment';
  static const text_phone_input = 'text_phone_input';
  static const text_phone_usecase_message = 'text_phone_usecase_message';
  static const text_profile = 'text_profile';
  static const text_searching = 'text_searching';
  static const text_select_language = 'text_select_language';
  static const text_services = 'text_services';
  static const text_share_this_code = 'text_share_this_code';
  static const text_top_up_balance = 'text_top_up_balance';
  static const text_trip_finish = 'text_trip_finish';
  static const text_update_detail = 'text_update_detail';
  static const text_upload_license = 'text_upload_license';
  static const text_user = 'text_user';
  static const text_verification = 'text_verification';
  static const text_wallet = 'text_wallet';
  static const units_km = 'units_km';
  static const units_minutes = 'units_minutes';
  static const units_rs = 'units_rs';
  static const vehicle_type_bike = 'vehicle_type_bike';
  static const vehicle_type_taxi = 'vehicle_type_taxi';
  static const vehicle_type_city_safari = 'vehicle_type_city_safari';
}

class Locales {
  static const en_US = {
    'app_name': 'Puryaideu',
    'onboarding_heading1': 'Select Destination',
    'onboarding_content1': 'Taxi, Bike, Tempo, whichever you feel comfortable',
    'onboarding_heading2': 'Fast Response',
    'onboarding_content2':
        'How far is my rider? Estimated rider time and distance are displayed.',
    'onboarding_heading3': 'Enjoy The Ride',
    'onboarding_content3': '“Life is for service.” – Fred Rogers',
    'trip_dialogs_emergency_service': 'Emergency Services',
    'trip_dialogs_call_nepal_police': 'Call Nepal Police.',
    'trip_dialogs_emergency_message':
        'Send emergency message to Puryaideu team.',
    'trip_dialogs_enter_complain': 'Enter your complain.',
    'trip_dialogs_cancel_booking': 'CANCEL BOOKING',
    'trip_dialogs_cancel_booking_question':
        'Why do you want to cancel this booking?',
    'trip_dialogs_satisfied_with_region':
        'Are you satisfied with your cancel reason?',
    'trip_dialogs_yes': 'Yes',
    'trip_dialogs_no': 'No',
    'rating_rate_customer': 'Rate Customer',
    'rating_rider': 'Customer',
    'rating_rate_now': 'Rate Now',
    'rating_rate_later': 'Rate Later',
    'auth_google': 'Google',
    'auth_facebook': 'Facebook',
    'home_morning': 'Morning',
    'home_afternoon': 'Afternoon',
    'home_evening': 'Evening',
    'home_hi': 'Hi',
    'home_good': 'Good ',
    'home_online': 'Online',
    'home_offline': 'Offline',
    'home_you_are_offline': 'You are Offline',
    'home_please_go_online_to': 'Please go online to get available bookings.',
    'home_duration': 'Duration',
    'home_distance': 'Distance',
    'home_price': 'Price: ',
    'notifications_CAMPAIGNS': 'CAMPAIGNS',
    'notifications_PROMOTIONS': 'PROMOTIONS',
    'history_bike': 'BIKE',
    'history_car': 'CAR',
    'history_city_safari': 'CITY SAFARI',
    'history_ambulance': 'AMBULANCE',
    'history_food_delivery': 'FOOD DELIVERY',
    'history_courier': 'COURIER',
    'history_show_cancelled_rides': 'Show cancelled Rides',
    'history_rate_now': 'RATE NOW',
    'history_trip_details': 'Trip details',
    'history_trip_id': 'Trip ID',
    'history_trip_info': 'Trip Info',
    'history_bill_breakdown': 'Bill Breakdown',
    'history_minimum_fare': 'Minimum Fare:',
    'history_base_fare': 'Base Fare:',
    'history_kilometers': 'Kilometers',
    'history_minutes': 'Minutes:',
    'history_surge': 'Surge:',
    'history_app_charges': 'App Charges:',
    'history_subtotal': 'Subtotal:',
    'history_commission': 'Commission:',
    'history_total': 'Total:',
    'history_trip_id_copied': 'Trip ID successfully copied.',
    'history_origin': 'Origin: ',
    'history_destination': 'Dropoff: ',
    'history_receipt': 'Receipt',
    'history_per_km': 'Per KM Fare: ',
    'history_per_min': 'Per Minute Fare: ',
    'history_discount': 'Discount: ',
    'profile_lifetime_earnings': 'Lifetime Earnings: ',
    'profile_due_amount': 'Due Amount: ',
    'profile_distance_travelled': 'Distance Travelled: ',
    'profile_total_trips': 'Total Trips: ',
    'profile_ratings': 'Ratings: ',
    'profile_documents': 'Documents',
    'profile_promotions': 'Promotions',
    'profile_language': 'Language',
    'profile_about_us': 'About Us',
    'profile_log_out': 'Log Out',
    'profile_avg': 'Avg ',
    'profile_add_promo_code': 'Add Promo code:',
    'profile_enter_promo_code': 'Enter Promo code',
    'profile_apply': 'Apply',
    'profile_select_language': 'SELECT LANGAUGE',
    'profile_select_preferred_language':
        'Please select your preferred language',
    'document_update_update_documents': 'Update Documents',
    'document_update_license': 'license',
    'document_update_vehicle_details': 'Vehicle details',
    'document_update_bluebook': 'Bluebook',
    'document_update_status': 'Status',
    'document_update_reason': 'Reason',
    'document_update_license_photo': 'License Photo:',
    'document_update_license_number': 'License Number:',
    'document_update_issue_date': 'Issue Date:',
    'document_update_expiry_date': 'Expiry Date:',
    'document_update_vehicle_number': 'Vehicle Number:',
    'document_update_vehicle_document': 'Vehicle Document',
    'document_update_make_year': 'Make Year:',
    'document_update_vehicle_type': 'Vehicle Type:',
    'document_update_brand_name': 'Brand Name:',
    'document_update_model_name': 'Model Name:',
    'document_update_vehicle_photo': 'Vehicle Photo:',
    'document_update_bluebook_details': 'Bluebook Details',
    'document_update_bluebook_first_photo': 'Bluebook First Photo',
    'document_update_bluebook_second_photo': 'Bluebook Second Photo',
    'document_update_bluebook_third_photo': 'Bluebook Third Photo',
    'document_update_bluebook_fourth_photo': 'Bluebook Fourth Photo',
    'document_update_upload_bluebook_photo': 'Upload bluebook photo',
    'document_update_bluebook_number': 'Bluebook Number:',
    'document_update_please_enter_license_number':
        'Please enter license number',
    'document_update_please_enter_vehicle_number':
        'Please enter vehicle number',
    'document_update_please_enter_vehicle_make_year':
        'Please enter vehicle make year',
    'document_update_please_enter_vehicle_brand_name':
        'Please enter vehicle brand name',
    'document_update_please_enter_vehicle_model': 'Please enter vehicle model',
    'document_update_pending': 'PENDING',
    'document_update_approved': 'APPROVED',
    'bottom_navigation_items_history': 'History',
    'bottom_navigation_items_home': 'Home',
    'bottom_navigation_items_notifications': 'Notifications',
    'bottom_navigation_items_settings': 'Settings',
    'buttons_accept_trip': 'Accept Trip',
    'buttons_ambulance': 'Ambulance',
    'buttons_call': 'Call',
    'buttons_cancel_booking': 'Cancel Booking',
    'buttons_confirm_destination': 'Confirm your destination',
    'buttons_confirm_payment': 'Confirm Payment',
    'buttons_confirm_pickup': 'Confirm your pickup',
    'buttons_continue': 'Continue',
    'buttons_continue_with_phone': 'Continue with Phone Number',
    'buttons_courier': 'Courier',
    'buttons_facebook': 'Facebook',
    'buttons_finish_ride': 'Finish Ride',
    'buttons_ghar_khaja': 'Ghar Khaja',
    'buttons_go_online': 'Go Online',
    'buttons_google': 'Google',
    'buttons_invite': 'Invite',
    'buttons_log_out': 'Log Out',
    'buttons_next': 'NEXT',
    'buttons_offline_payment': 'Offline Payment',
    'buttons_online_payment': 'Online Payment',
    'buttons_privacy_policy': ' Privacy Policy ',
    'buttons_proceed': 'Proceed',
    'buttons_request_ride': 'Request Ride',
    'buttons_search_by_pin': 'Search by Pin',
    'buttons_set_destination': 'SET DESTINATION',
    'buttons_set_home': 'Set Home',
    'buttons_set_language': 'Set Language',
    'buttons_set_pickup': 'SET PICKUP',
    'buttons_set_work': 'Set Work',
    'buttons_start_ride': 'Start Ride',
    'buttons_submit': 'Submit',
    'buttons_terms_and_condition': 'Terms & Conditions ',
    'buttons_try_again': 'Try Again',
    'buttons_verify': 'Verify',
    'buttons_view_on_map': 'View On Map',
    'hints_search_pickup': 'Search Pickup',
    'hints_search_destination': 'Search Destination',
    'image_picker_items_camera': 'Camera',
    'image_picker_items_photo_library': 'Photo Library',
    'labels_dob': 'Date of Birth',
    'labels_email': 'Email',
    'labels_experience': 'Experience(in years)',
    'labels_first_name': 'First name',
    'labels_gender': 'Gender',
    'labels_last_name': 'Last name',
    'labels_license_number': 'License Number',
    'labels_vehicle_number': 'Vehicle Number',
    'labels_vehicle_type': 'Vehicle Type',
    'settings_about': 'About Us',
    'settings_app_settings': 'App Settings',
    'settings_document': 'Document',
    'settings_top_up_payment': 'Topup Payment',
    'text_add_profile': 'Add Profile',
    'text_and': 'and',
    'text_balance': 'Balance',
    'text_by_tapping': 'By tapping continue, you agree to the ',
    'text_change_location': 'Change Location',
    'text_current_location': 'Current Location',
    'text_distance_travelled': 'Distance Travelled',
    'text_enter_destination': 'Enter Destination',
    'text_get_discount': 'Get Discount',
    'text_invite_friends': 'Invite Friends & Get Discount!',
    'text_location_permission_message':
        'We require your precise location to seamlessly connnect you to nenarby service providers. Please turn on device location.',
    'text_no_bookings': 'No bookings found.',
    'text_of_puryaideu': 'of Puryaideu.',
    'text_offline_message': 'You are currently offline',
    'text_or': 'OR',
    'text_otp_message':
        'Please enter the otp that has been sent to your number.',
    'text_payment': 'Payment',
    'text_phone_input': 'Please enter your mobile number.',
    'text_phone_usecase_message':
        'This number will be used to verify your login.',
    'text_profile': 'Profile',
    'text_searching': 'Searching',
    'text_select_language': 'Select a language',
    'text_services': 'Services',
    'text_share_this_code':
        'Share this code with two of your friends and ask them to use it on their first Bike or Car ride. Both your friends will get amazing discount on their first rides while you get a discount when your friends complete their rides.',
    'text_top_up_balance': 'Topup Balance',
    'text_trip_finish': 'Your trip has finished.',
    'text_update_detail': 'Update Detail',
    'text_upload_license': 'Upload License',
    'text_user': 'User',
    'text_verification': 'Verification',
    'text_wallet': 'Wallet',
    'units_km': 'km',
    'units_minutes': 'min',
    'units_rs': 'Rs.',
    'vehicle_type_bike': 'Bike',
    'vehicle_type_taxi': 'Taxi',
    'vehicle_type_city_safari': 'City Safari',
  };
  static const ne_NP = {
    'app_name': 'पुर्याइदेउ',
    'onboarding_heading1': 'गन्तव्य चयन गर्नुहोस्',
    'onboarding_content1': 'ट्याक्सी, मोटरसाइकल, टेम्पो, जुनसुकै सहज लाग्छ',
    'onboarding_heading2': 'द्रुत प्रतिक्रिया',
    'onboarding_content2':
        'मेरो सवार कति टाढा छ? अनुमानित सवार समय र दूरी प्रदर्शित छन्।',
    'onboarding_heading3': 'सवारीको आनन्द लिनुहोस्',
    'onboarding_content3': '“जीवन सेवाको लागि हो।“, - फ्रेड रोजर्स',
    'auth_google': 'गूगल',
    'auth_facebook': 'फेसबुक',
    'home_morning': '- प्रभात',
    'home_afternoon': 'दिउँसो',
    'home_evening': 'सन्ध्या',
    'home_hi': 'नमस्ते',
    'home_good': 'शुभ ',
    'home_online': 'अनलाइन',
    'home_offline': 'अफलाइन',
    'home_you_are_offline': 'तपाईं अफलाइन हुनुहुन्छ',
    'home_please_go_online_to':
        'उपलब्ध बुकिङहरू प्राप्त गर्न कृपया अनलाइन जानुहोस्।',
    'home_duration': 'अवधि',
    'home_distance': 'दूरी',
    'home_price': 'मूल्य: ',
    'notifications_CAMPAIGNS': 'अभियानहरू',
    'notifications_PROMOTIONS': 'प्रमोशनहरू',
    'history_bike': 'बाइक',
    'history_car': 'कार',
    'history_city_safari': 'शहर सफारी',
    'history_ambulance': 'यम्बुलेन्स',
    'history_food_delivery': 'खाद्य वितरण',
    'history_courier': 'कुरियर',
    'history_show_cancelled_rides': 'रद्द गरिएका सवारीहरू देखाउनुहोस्',
    'history_rate_now': 'मूल्याङ्कन गर्नुहोस्',
    'history_trip_details': 'यात्रा विवरण',
    'history_trip_id': 'यात्रा आइडी',
    'history_trip_info': 'यात्रा जानकारी',
    'history_bill_breakdown': 'बिल ब्रेकडाउन',
    'history_minimum_fare': 'न्यूनतम भाडा:',
    'history_base_fare': 'आधार भाडा:',
    'history_kilometers': 'किलोमिटर:',
    'history_minutes': 'मिनेट:',
    'history_surge': 'वृद्धि:',
    'history_app_charges': 'एप शुल्कहरू:',
    'history_subtotal': 'उप-योग:',
    'history_commission': 'आयोग:',
    'history_total': 'कुल:',
    'history_trip_id_copied': 'यात्रा आइडी सफलतापूर्वक प्रतिलिपि गरियो।',
    'history_origin': 'उत्पत्ति: ',
    'history_destination': 'ड्रपअफ: ',
    'history_receipt': 'रसिद',
    'history_per_km': 'प्रति किमी भाडा: ',
    'history_per_min': 'प्रति मिनेट भाडा: ',
    'history_discount': 'छुट: ',
    'profile_lifetime_earnings': 'लाइफटाइम कमाई: ',
    'profile_due_amount': 'देय रकम: ',
    'profile_distance_travelled': 'दुरीको यात्रा भयो: ',
    'profile_total_trips': 'कुल यात्राहरू: ',
    'profile_ratings': 'मूल्याङ्कन: ',
    'profile_documents': 'कागजातहरू',
    'profile_promotions': 'पदोन्नतिहरू',
    'profile_language': 'भाषा',
    'profile_about_us': 'हाम्रोबारे',
    'profile_log_out': 'बाहिर निस्कनु',
    'profile_avg': 'औसत ',
    'profile_add_promo_code': 'प्रोमो कोड थप्नुहोस्:',
    'profile_enter_promo_code': 'प्रोमो कोड प्रविष्ट गर्नुहोस्',
    'profile_apply': 'निवेदन गर्नु',
    'profile_select_language': 'भाषा छनोट गर्नुस',
    'profile_select_preferred_language':
        'कृपया आफ्नो मनपर्ने भाषा चयन गर्नुहोस्',
    'document_update_update_documents': 'कागजातहरू अद्यावधिक गर्नुहोस्',
    'document_update_license': 'इजाजतपत्र',
    'document_update_vehicle_details': 'सवारी साधन विवरण',
    'document_update_bluebook': 'ब्लूबुक',
    'document_update_status': 'स्थिति',
    'document_update_reason': 'कारण',
    'document_update_license_photo': 'लाइसेन्स फोटो:',
    'document_update_license_number': 'लाइसेन्स नम्बर:',
    'document_update_issue_date': 'जारी मिति:',
    'document_update_expiry_date': 'म्याद सकिने मिति:',
    'document_update_vehicle_number': 'गाडीको नम्बर:',
    'document_update_vehicle_document': 'सवारी साधन कागजात',
    'document_update_make_year': 'वर्ष बनाउनुहोस्:',
    'document_update_vehicle_type': 'सवारी साधनको प्रकार:',
    'document_update_brand_name': 'ब्रान्ड नाम:',
    'document_update_model_name': 'मोडेलको नाम:',
    'document_update_vehicle_photo': 'गाडीको फोटो:',
    'document_update_bluebook_details': 'ब्लूबुक विवरणहरू',
    'document_update_bluebook_first_photo': 'ब्लूबुक पहिलो फोटो',
    'document_update_bluebook_second_photo': 'ब्लूबुक दोस्रो फोटो',
    'document_update_bluebook_third_photo': 'ब्लूबुक तेस्रो फोटो',
    'document_update_bluebook_fourth_photo': 'ब्लूबुक चौथो फोटो',
    'document_update_upload_bluebook_photo': 'ब्लूबुक फोटो अपलोड गर्नुहोस्',
    'document_update_bluebook_number': 'ब्लूबुक नम्बर:',
    'document_update_please_enter_license_number':
        'कृपया इजाजत पत्र नम्बर प्रविष्ट गर्नुहोस्',
    'document_update_please_enter_vehicle_number':
        'कृपया गाडीको नम्बर प्रविष्ट गर्नुहोस्',
    'document_update_please_enter_vehicle_make_year':
        'कृपया सवारी साधन निर्माण वर्ष प्रविष्ट गर्नुहोस्',
    'document_update_please_enter_vehicle_brand_name':
        'कृपया गाडीको ब्रान्ड नाम प्रविष्ट गर्नुहोस्',
    'document_update_please_enter_vehicle_model':
        'कृपया गाडीको मोडेल प्रविष्ट गर्नुहोस्',
    'document_update_pending': 'पेन्डिङ',
    'document_update_approved': 'स्वीकृत',
    'trip_dialogs_emergency_service': 'अाकस्मिक सेवाहरू',
    'trip_dialogs_call_nepal_police': 'नेपाल प्रहरीलाई फोन गर्नुहोस्।',
    'trip_dialogs_emergency_message':
        'पुर्याइदेउ टोलीलाई आपतकालीन सन्देश पठाउनुहोस्।',
    'trip_dialogs_enter_complain': 'आफ्नो गुनासो प्रविष्ट गर्नुहोस्।',
    'trip_dialogs_cancel_booking': 'बुकिङ रद्द गर्नुहोस्',
    'trip_dialogs_cancel_booking_question':
        'तपाईं किन यो बुकिङ रद्द गर्न चाहनुहुन्छ?',
    'trip_dialogs_satisfied_with_region':
        'तपाईं आफ्नो रद्द कारण संग सन्तुष्ट हुनुहुन्छ?',
    'trip_dialogs_yes': 'छु',
    'trip_dialogs_no': 'छैन',
    'rating_rate_customer': 'ग्राहकलाई मूल्याङ्कन गर्नुहोस्',
    'rating_rider': 'ग्राहक',
    'rating_rate_now': 'अहिले मूल्याङ्कन गर्नुहोस्',
    'rating_rate_later': 'पछि मूल्याङ्कन गर्नुहोस्',
    'bottom_navigation_items_history': 'इतिहास',
    'bottom_navigation_items_home': 'घर',
    'bottom_navigation_items_notifications': 'सूचनाहरू',
    'bottom_navigation_items_settings': 'सेटिङहरू',
    'buttons_accept_trip': 'यात्रा स्वीकार गर्नुहोस्',
    'buttons_ambulance': 'यम्बुलेन्स',
    'buttons_call': 'कल गर्नुहोस्',
    'buttons_cancel_booking': 'बुकिङ रद्द गर्नुहोस्',
    'buttons_confirm_destination': 'आफ्नो गन्तव्य पुष्टि गर्नुहोस्',
    'buttons_confirm_payment': 'भुक्तानी पुष्टि गर्नुहोस्',
    'buttons_confirm_pickup': 'आफ्नो पिकअप पुष्टि गर्नुहोस्',
    'buttons_continue': 'जारी राख्नुहोस्',
    'buttons_continue_with_phone': 'फोन नम्बरको साथ जारी राख्नुहोस्',
    'buttons_courier': 'कुरियर',
    'buttons_facebook': 'फेसबुक',
    'buttons_finish_ride': 'सवारी समाप्त गर्नुहोस्',
    'buttons_ghar_khaja': 'घर खाजा',
    'buttons_go_online': 'अनलाइन जानुहोस्',
    'buttons_google': 'गूगल',
    'buttons_invite': 'आमन्त्रित गर्नुहोस्',
    'buttons_log_out': 'बाहिर जानुहोस्',
    'buttons_next': 'अर्को',
    'buttons_offline_payment': 'अफलाइन तिर्नुहोस्',
    'buttons_online_payment': 'अनलाइन तिर्नुहोस्',
    'buttons_privacy_policy': ' गोपनीयता नीति ',
    'buttons_proceed': 'अगाडि बढ्नुहोस्',
    'buttons_request_ride': 'सवारी अनुरोध गर्नुहोस्',
    'buttons_search_by_pin': 'पिन द्वारा खोज्नुहोस्',
    'buttons_set_destination': 'गन्तव्य सेट गर्नुहोस्',
    'buttons_set_home': 'घर सेट गर्नुहोस्',
    'buttons_set_language': 'भाषा सेट गर्नुहोस्',
    'buttons_set_pickup': 'पिकअप सेट गर्नुहोस्',
    'buttons_set_work': 'काम सेट गर्नुहोस्',
    'buttons_start_ride': 'सवारी सुरु गर्नुहोस्',
    'buttons_submit': 'पेश गर्नुहोस्',
    'buttons_terms_and_condition': 'नियम तथा सर्त ',
    'buttons_try_again': 'फेरि प्रयास गर्नुहोस्',
    'buttons_verify': 'प्रमाणित गर्नुहोस्',
    'buttons_view_on_map': 'नक्सामा हेर्नुहोस्',
    'hints_search_pickup': 'पिकअप खोज्नुहोस्',
    'hints_search_destination': 'गन्तव्य खोज्नुहोस्',
    'image_picker_items_camera': 'क्यामेरा',
    'image_picker_items_photo_library': 'फोटो लाइब्रेरी',
    'labels_dob': 'जन्म मिति',
    'labels_email': 'इमेल',
    'labels_experience': 'अनुभव (वर्षमा)',
    'labels_first_name': 'पहिलो नाम',
    'labels_gender': 'लिङ्ग',
    'labels_last_name': 'थर',
    'labels_license_number': 'लाइसेन्स नम्बर',
    'labels_vehicle_number': 'गाडीको नम्बर',
    'labels_vehicle_type': 'सवारी साधनको प्रकार',
    'settings_about': 'हाम्रो बारे',
    'settings_app_settings': 'एप सेटिङहरू',
    'settings_document': 'कागजात',
    'settings_top_up_payment': 'टपअप भुक्तानी',
    'text_add_profile': 'प्रोफाइल थप्नुहोस्',
    'text_and': 'र',
    'text_balance': 'भाडा',
    'text_by_tapping': 'जारी ट्याप गरेर, तपाईं पुर्याइदेउको',
    'text_change_location': 'स्थान परिवर्तन गर्नुहोस्',
    'text_current_location': 'वर्तमान स्थान',
    'text_distance_travelled': 'यात्रा गरिएको दूरी',
    'text_enter_destination': 'गन्तव्य प्रविष्ट गर्नुहोस्',
    'text_get_discount': 'छुट पाउनुहोस्',
    'text_invite_friends': 'साथीहरूलाई आमन्त्रित गर्नुहोस् र छुट पाउनुहोस्!',
    'text_location_permission_message':
        'हामीलाई नजिकैका सेवा प्रदायकहरूसँग सहज रूपमा जडान गर्न तपाईंको सटीक स्थान चाहिन्छ। कृपया जीपीएस स्थान सक्रिय गर्नुहोस्।',
    'text_no_bookings': 'कुनै बुकिङ भेटिएन।',
    'text_of_puryaideu': 'सहमत हुनुहुन्छ',
    'text_offline_message': 'तपाईं हाल अफलाइन हुनुहुन्छ',
    'text_or': 'वा',
    'text_otp_message':
        'कृपया तपाईको नम्बरमा पठाइएको ओटीपी प्रविष्ट गर्नुहोस्।',
    'text_payment': 'भुक्तानी',
    'text_phone_input': 'कृपया आफ्नो मोबाइल नम्बर प्रविष्ट गर्नुहोस्।',
    'text_phone_usecase_message':
        'यो नम्बर तपाईको लगइन प्रमाणित गर्न प्रयोग गरिनेछ।',
    'text_profile': 'प्रोफाइल',
    'text_searching': 'खोज्दै',
    'text_select_language': 'भाषा चयन गर्नुहोस्',
    'text_services': 'सेवाहरू',
    'text_share_this_code':
        'यो कोड आफ्ना दुई साथीहरूसँग साझा गर्नुहोस् र तिनीहरूलाई उनीहरूको पहिलो बाइक वा कार सवारीमा प्रयोग गर्न भन्नुहोस्। तपाईंका दुवै साथीहरूले तिनीहरूको पहिलो सवारीमा अचम्मको छुट पाउनेछन् जबकि तपाईंका साथीहरूले तिनीहरूको सवारी पूरा गर्दा छुट पाउनुहुन्छ।',
    'text_top_up_balance': 'टपअप ब्यालेन्स',
    'text_trip_finish': 'तपाईंको यात्रा समाप्त भयो।',
    'text_update_detail': 'अपडेट विवरण',
    'text_upload_license': 'लाइसेन्स अपलोड गर्नुहोस्',
    'text_user': 'प्रयोगकर्ता',
    'text_verification': 'प्रमाणीकरण',
    'text_wallet': 'वालेट',
    'units_km': 'कि.मी.',
    'units_minutes': 'मिनेट',
    'units_rs': 'रु.',
    'vehicle_type_bike': 'बाइक',
    'vehicle_type_taxi': 'ट्याक्सी',
    'vehicle_type_city_safari': 'शहर सफारी',
  };
}
